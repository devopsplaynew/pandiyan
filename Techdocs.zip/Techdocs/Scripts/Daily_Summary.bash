#! /usr/bin/env ksh

date=`date --date='-1 day' "+%m%d%Y"`
draft=`date --date='-1 day' "+%m%d%y"`
date_1=`date --date='-2 day' "+%m%d%Y"`
ews_date=`date --date='-1 day' "+%Y%m%d"`
zelle_date=`date --date='-1 day' "+%y%m%d"`
dis_date=`date --date='-1 day' "+%d%b%Y"`
dis_date_1=`date --date='-2 day' "+%d%m%y"`
juldate=`date "+%Y%j"`
ocs_date=`date --date='-1 day' "+%b %_d"`
masdate=`date "+%y%j"`


#masfiles_count
ms_cnt=`ls -lrt /data/MAS/Outbound/ARC | grep $masdate |wc -l`
ocs_cnt=`ls -lrt /data/OCS/Outbound/ARC | grep $masdate |wc -l`
draft_cnt1=`ls -lrt /data/TSYS/Inbound/D256/ICBA/ARC | grep $draft |wc -l`
draft_cnt2=`ls -lrt /data/TSYS/Inbound/D256/ARC | grep $draft | grep -v 'Source' | grep -v 'FIS_STMT' |wc -l`
draft_cnt3=`ls -lrt /data/TSYS/Inbound/D256/ARC | grep $draft | grep -v 'Source' | grep -v 'FTP00' |wc -l`
draft_cnt=`expr  $draft_cnt1 + $draft_cnt2 + draft_cnt3`
zero_draft=`ls -lrt /data/TSYS/Inbound/D256/zero_draft | grep $draft |wc -l`
cdf_cnt=`ls -lrt /data/TSYS/Inbound/CDF/ARC | grep "$ocs_date" | grep -v '.FAIL' |wc -l`
gcf_cnt=`ls -lrt /data/GlobalPayments/Inbound/GCF/GCF_ARC | grep $ews_date |grep -v '.FAIL' |wc -l`

echo -e "MAS Exported Count $ms_cnt"
echo -e "OCS Exported Count $ocs_cnt"
echo -e "Draft ICBA Imported Count $draft_cnt1"
echo -e "Draft Imported Count $draft_cnt"
echo -e "Letter check files Count $draft_cnt2"
echo -e "Statement check files Count $draft_cnt3"
echo -e "Zero Draft Count $zero_draft"
echo -e "CDF Imported Count $cdf_cnt"
echo -e "GCF Imported Count $gcf_cnt\n"

echo "OCS CBK"
ls -lrt /data/OCS/Inbound/ARC |grep "$ocs_date"|grep 'chrgbakocs.19' |grep -v 'FAIL'| grep -v 'Error' |awk '{print $9}'

sleep 1
echo "--------------------------------------------------------------------------------------------------"
echo "Outgoing - Amex NON-ICBA"
ls -lrth /data/AMEX/Outbound/OPTBLUE/SUB_SETTLEMENT/ARC |grep $zelle_date|awk '{print $9"    "$8"    "$5}'|sed 's/.DONE_Valid//g'

amx_cnt1=`ls -lrth /data/AMEX/Outbound/OPTBLUE/SUB_SETTLEMENT/ARC |grep $zelle_date| wc -l`

ls -lrth /data/AMEX/Outbound/OPTBLUE/SUB_SETTLEMENT_ICBA/ARC |grep $zelle_date|awk '{print $9"    "$8"    "$5}'|sed 's/.DONE_Valid//g'

amx_cnt2=`ls -lrth /data/AMEX/Outbound/OPTBLUE/SUB_SETTLEMENT_ICBA/ARC |grep $zelle_date| wc -l`

amx_out=`expr  $amx_cnt2 + $amx_cnt1`

sleep 1
echo "--------------------------------------------------------------------------------------------------"
echo -e "Outgoing - DISCOVER\n"
ls -lrth /data/Discover/Outbound/ARC |grep $juldate|awk '{print $9"    "$8"    "$5}'|sed 's/.DONE//g'

dis_out=`ls -lrth /data/Discover/Outbound/ARC |grep $juldate |wc -l`

sleep 1
echo "--------------------------------------------------------------------------------------------------"
echo -e "Outgoing - MC:\n"
ls -lrth /data/MC/Outbound/ARC |grep $zelle_date|awk '{print $9"    "$8"    "$5}'|sed 's/.DONE.Val//g'

mc_out=`ls -lrth /data/MC/Outbound/ARC |grep $zelle_date|wc -l`

sleep 1
echo "--------------------------------------------------------------------------------------------------"
echo "Outgoing - VISA:\n"
#echo " "
ls -lrth /data/VISA/Outbound/ARC |grep $zelle_date|awk '{print $9"    "$8"    "$5}'|sed 's/.DONE//g'
visa_out=`ls -lrth /data/VISA/Outbound/ARC |grep $zelle_date |wc -l`
echo " "
ls -lrth /data/VISA_PREEDIT/Outbound |grep $zelle_date|awk '{print $9}'

echo "--------------------------------------------------------------------------------------------------"
echo -e "Card Brand Output:\n"
echo -e "• $amx_out Opt blue file Sent to Amex\n"
echo -e "• $dis_out Sales Draft files sent to Discover\n"
echo -e "• $mc_out IPM files sent to Master Card\n"
echo -e "• $visa_out BASE2 files sent to Visa\n"

echo "--------------------------------------------------------------------------------------------------"
echo -e "Incoming - EWS\n"
ls -lrt /data/EWS/Inbound/Zelle/ARC |grep MPS.MPSPROD.$ews_date|awk '{print $9}'|sed 's/.DONE//g'

sleep 1

echo -e "Incoming - MC Zelle:\n"
ls -lrt /data/MC/Inbound/ZELLE |grep MPS.MPSPROD.*$zelle_date| grep -v 'TBV6'| grep -v 'TBN6' |awk '{print $9}'
echo " "

echo -e "------------------Incoming - Reports and Files Shared-------------------------------------------\n"
echo "BASE2.CHARGEBACK.$date.CTF.S0000.EPIN03"
echo "BASE2.FEESFUNDS.$date.CTF.S0000.EPIN04"
echo "BASE2.INC_ALL.$date.CTF.S0000.EPIN"
echo "BASE2.RECLASS.$date.CTF.S0000.EPIN02"
echo "BASE2.SMSRAWDATA.$date.CTF.S0000.EPIN05"
echo -e "--------------------------------------------------------------------------------------------------\n"
sleep 1

ls /data/MC/Inbound/ARC/MC_Inbound_$date* |grep -v '/data/MC/Inbound/ARC/'|grep -v 'TN70' |grep -v 'TBV6'| grep -v 'TBV8' |grep -v '.txt'|sort -k9

echo -e "--------------------------------------------------------------------------------------------------\n"
sleep 1

ls -lrt /data/Discover/Inbound/ARC/Inbound_DIS_$dis_date*|grep -v '/data/Discover/Inbound/ARC/' |grep -v '.txt'|grep -v $dis_date_1 |awk '{print $9}'
