#!/bin/bash

#####################################################################################################################
#  Script: This script is sending alert mail for taking monthly backup of prod DN		                            #
#  Developed by :Kiran Krishnan                                                                                     #
#  Version: 1.0                                                                                                     #
#  Creation:12/06/2017                                                                                              #
#####################################################################################################################


#SCRIPT VARIABLES

Date=`date --date='-1 month' "+%B"`
Current_Time=`date "+%y-%m-%d %H:%M:%S"`
timestamp=`date +%H%M%S`
PROCESS_PATH=/apps/clearing/util
Send_From=Mail_IN_MPS_Operations_Support@fisglobal.com
Send_To=Mail_IN_MPS_Operations_Support@fisglobal.com
#Send_To=kiran.krishnan@fisglobal.com
Send_CC1=Babrak.K.Sharwani@fisglobal.com
Send_CC2=Mail_IN_MPS_Appl_Support@fisglobal.com
Alert_Message_debug=/apps/clearing/util/Alert_Message.debug


echo -e "Hi Team,\n" >>$PROCESS_PATH/Alert_Message.txt
echo "Please perform $Date month Backup activity in Prod DN server" >>$PROCESS_PATH/Alert_Message.txt
echo -e "\nRegards" >>$PROCESS_PATH/Alert_Message.txt
echo "MPS Operations" >>$PROCESS_PATH/Alert_Message.txt

#MAIL BODY

echo -e "\n\nAlert for $Date Month DN Backup" >>$Alert_Message_debug

(cat $PROCESS_PATH/Alert_Message.txt)|mailx -s "Alert for $Date Month DN Backup" -S smtp=Smtprelay.messageprovider.com -c "$Send_CC1","$Send_CC2" -r "$Send_From" "$Send_To"  | tee -a $Alert_Message_debug

Status=`echo $?`

if [ $Status -eq 0 ]
then
	REMOVE=`rm $PROCESS_PATH/Alert_Message.txt`
	echo "Mail sent for $Date Month DN Backup" >>$Alert_Message_debug
else
	echo "Mailx is not working please check" >>$PROCESS_PATH/Alert_Message.debug
fi
