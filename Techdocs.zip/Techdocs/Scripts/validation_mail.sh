#!/bin/bash
PROCESS_PATH=/tmp/test
Send_From=pandiyan.kuppan@fisglobal.com
Send_To=pandiyan.kuppan@fisglobal.com
Send_To_Internal=pandiyan.kuppan@fisglobal.com

util=/apps/conv/clearing/util
Date=`date "+%m/%d"`
echo "==============================================================================="

#echo "Checking Pre-edit 10.236.134.164 connection"

preedit_sftp=`/apps/clearing/sshpass -p 'fvGnpaGKkCFjPh' sftp sftpedit@10.236.134.164 <<EOF
bye
EOF`

status=`echo $?`

if [ $status -eq 0 ]
then
		echo -e "SFTP Clearing to Pre-edit server Validation is Success\n" >$PROCESS_PATH/Validation_alert.txt 
else
				echo -e "\e[1;31m"" SFTP Clearing to Preedit 10.236.134.164 is Failed""\e[0m" >>$PROCESS_PATH/Validation_alert.txt
fi

sleep 3

#echo "Checking Clearing tskcmd services"

status=`tskcmd |wc -l`

if [ $status -eq 15 ]
then
		echo -e "All tasks are running fine in Prod Clearing server \n" >>$PROCESS_PATH/Validation_alert.txt
else
		echo -e "\e[1;31m"" Only $status services running in Clearing, expecting 15 Services.. Please check""\e[0m \n" >>$PROCESS_PATH/Validation_alert.txt
fi

sleep 3

#echo "==============================================================================="

#echo "Checking GUI services"

status1=`ps -ef | grep "oassrv -b" | grep clrconv | grep -v "grep oassrv -b" |wc -l`

if [ $status1 -eq 1 ]
then
		echo -e "oassrv -b GUI service running in Conv2 Clearing \n"
else
		echo -e "\e[1;31m"" oassrv -b GUI service not running in Conv2 Clearing.. Please check""\e[0m \n"

fi

sleep 3

status2=`ps -ef | grep "oentsrv -b" | grep clrconv | grep -v "grep oentsrv -b" |wc -l`

if [ $status2 -eq 1 ]
then
		echo -e "oentsrv -b GUI service running in Conv2 Clearing \n"
else
				echo -e "\e[1;31m"" oentsrv -b GUI service not running in Conv2 Clearing.. Please check""\e[0m \n"
fi

sleep 3

if [ $status1 -eq 1 ] && [ $status2 -eq 1 ] 
then
echo -e "GUI's Services running as expected on Prod Clearing \n" >>$PROCESS_PATH/Validation_alert.txt
else
echo -e "GUI's Services not running as expected on Prod Clearing \n" >>$PROCESS_PATH/Validation_alert.txt
fi
#echo "==============================================================================="

		disk_space=`df -h /apps/|tail -1 |awk '{print "Used--->"$4,"Available--->"$3}'`

		echo "Disk space $disk_space"

		used_disk=`df -h /apps/|tail -1 |awk '{print $4}' | sed "s/[^0-9]//g"`

if [ $used_disk -lt 85 ]
then
		echo -e "Used Disk space is $used_disk % "
		echo -e "Clearing Disk Space is well in tresheld \n" >>$PROCESS_PATH/Validation_alert.txt
else
				echo -e "\e[1;31m"" Warning: Used Disk Space is Critical $used_disk... Please clear old logs.""\e[0m \n"
fi

sleep 3

#echo "==============================================================================="

#echo "Checking FN connection"

 numFMConn=`mbportcmd list | grep -A1 FMFormatter | grep -v FMFormatter | grep connected | wc -l`
		if [ $numFMConn -eq 1 ]
		then
				echo "TCPIP Connected to Fraud Navigator - Result $numFMConn"
				echo -e "FN Connectivity to Clearing is success \n" >>$PROCESS_PATH/Validation_alert.txt
		else
				echo -e "ERROR: No TCPIP Connectio to FN - Result $numFMConn \n" >>$PROCESS_PATH/Validation_alert.txt
		fi
sleep 3

echo "==============================================================================="

				(cat $PROCESS_PATH/Validation_alert.txt)|mailx -s "Weekend LTR Validation on $Date" -S smtp=Smtprelay.messageprovider.com -r "$Send_From" "$Send_To_Internal"
