#! /usr/bin/env bash

TC57_Path=/data/TC57/Inbound/ARC
TC57_Aperia_transfer=/data/TC57/Inbound/ARC/ApreiaTransfer
debug=/apps/clearing/util/TC57_filetransfer.debug
Aperia_path=/I022604/BP1198_FIS_MPS_Processing/upload/
args=$#
date=`date +%Y%m%d`
aperia_date=`date +%Y%m%d%H%M%S`
currtime=`date "+%y-%m-%d %H:%M:%S"`

cd $TC57_Path

date=`date +%Y%m%d`

if [ $args -eq 1 ]
then
file_date=$1
else
file_date=$date
echo $currtime "Proceeding with today date since no arguments passed" $file_date
fi

tc57_file_check=`ls -lrt | grep $file_date |wc -l`

tc57_file=`ls -lrt | grep $file_date|awk '{print $9}'`
echo "tc57 file is $tc57_file"

if [ $tc57_file_check -eq 1 ]
then
echo "TC57 file is Available to transfer" >>$debug

cp $tc57_file $TC57_Aperia_transfer

cd $TC57_Aperia_transfer

mv $tc57_file FIS_FIS_TC57_Capture_C01_$aperia_date
mv_res=$?

if [ $mv_res -eq 0 ]
then

aperia_file=`ls -lrt |grep 'FIS_FIS_TC57_Capture_C01_' |grep $aperia_date |awk '{print $9}'`
echo $currtime 'TC57 file renamed successfully' $aperia_file>>$debug
echo "aperia_file is" $aperia_file

else
echo $currtime 'TC57 file rename failed '$aperia_file>>$debug
exit 2
fi

#   tc57_sftp=`sftp -i /apps/clearing/mpstomoveit i022604@10.102.242.16 <<EOF
#   cd $Aperia_path
#   put $aperia_file
#   bye
#   EOF`

echo $currtime: 'TC57 file transfering' $tc57_sftp>>$debug
sleep 4

tc57_sftp='0'

if [ $tc57_sftp -eq 0 ]
then
echo "TC57 file transfer Success"
mv $aperia_file $aperia_file.DONE
echo $currtime 'TC57 file transfering  to DX is success'>>$debug
exit 2
else
echo "TC57 file transfer Failed"
mv $aperia_file $aperia_file.FAIL
echo $currtime 'TC57 file transfering to DX is failed '>>$debug
exit 2
fi

else
echo "Today TC57 file is not Available to transfer in Path"
echo $currtime "Today TC57 file is not Available to transfer in Path.. Please check">>$debug
exit
fi
