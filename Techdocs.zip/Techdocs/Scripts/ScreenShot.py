import pyautogui
import keyboard
import pymsgbox
import shutil
import pyautogui
import os.path
import os,stat,sys
from tkinter import *
import tkinter as Tk
from tkinter.filedialog import askdirectory
import time
from datetime import datetime
import ctypes
from ctypes import wintypes
from pynput.keyboard import Key, Listener
from pynput.keyboard import KeyCode
from docx import Document
from docx.shared import Inches
from tkinter import messagebox
from array import array



timestr = datetime.now().strftime("%Y%m%d-%H%M%S")#To get the Current Date and time
list_dir=[]#Array initializsation 

is_exit = False

def textbox():#Create box
    
    master = Tk.Tk()
    e = Entry(master)
    e.pack()
    e.focus_set()

    def callback(): # File validation 
        global c
        c = e.get() # Store the Folder name
        if c.strip(): #Checking file already exists or not#
            file_check=os.path.exists(folder+'/'+c)
            
            if file_check== True:
                pymsgbox.alert("Folder name already exists, do you want to save your result in this existing folder, then close the window and take your snaps. otherwise give new folder name","Warning")
                
                    
            else:
                os.mkdir(folder+'/'+c)
                list_dir.append(folder+'/'+c)
                pymsgbox.alert("You Created the folder successfully. please close the window and take your snap","Greetings")
                
        else:
            pymsgbox.alert("Folder name not valid","Error")

    b = Button(master, text = "Create Folder", width = 10, command = callback,fg="black",bg="Pale Green")
    b.pack()
    mainloop()

    
def CreateFolder():
    global Result_location
    
    textbox()
    print("Sucess 4")
    Result_location=folder+'/'+c
    


def snap():#taking snap and store the result
    timestr = datetime.now().strftime("%Y%m%d-%H%M%S%f")
    pic= pyautogui.screenshot()
    pic.save(Result_location+'\\'+c+timestr+'`.png')


def on_release(key):#Key press handling
    print('--->{0}'.format(key))
    global is_exit
    try:             
        if key == Key.shift:
            print('Shif key is pressed')
        elif key == Key.esc:
            snap()
        elif key == KeyCode.from_char(char='`'):
            snap()
            pyautogui.press('pagedown')# PageDown key press will happen
        elif key == KeyCode.from_char(char='!'):
            return False;
        elif key == KeyCode.from_char(char='^'):
            is_exit = True
            return False;
        else:
            print("None Pressed")
    except:
        print("Please enter valid Button")
        
def browse_file(): # To choose the desination to store our result
    global folder
    folder = askdirectory()
    print(folder)
    if folder =='':
        mainloop()
    else:
        quit()
        
    

def quit():#quit tkinter window
    global root
    root.destroy()
    #CreateFolder()
    
def snapease():#to save the current folder and create new folder
    CreateFolder()
    
def word_doc():#word Document conversion.

    filelist=os.listdir(Result_location)
    document = Document()
    for Snaps in filelist:
        
        if Snaps.endswith(".png"):
            #print(fichier)
            document.add_picture(Result_location+'\\'+Snaps, width=Inches(6.5))
    document.save(folder +'\\'+c+'.docx')
    file_path=os.path.dirname(Result_location+'\\'+Snaps)
    print("Sathishconvert"+str(file_path))


    
def endscript(): # Stop the Script
    pymsgbox.alert("SnapEz script sucessfully stopped, find your results in "+folder,"ThankYou")
    filedelete_list = os.listdir(folder)
    
    for i in range(len(list_dir)):
        del_file=list_dir[i]
        print("Machi"+str(list_dir[i]))
        shutil.rmtree(del_file)
        
         
       
    sys.exit()
  
    

#Program will start from here

pymsgbox.alert('Hi,\n 1. Use \'Esc\' ' 'key to take the snap of current page. \n 2. Use \'`\' ' 'key to take snap of current page and scroll down to next page automatically. \n 3. Use \'!\' ' ' To Save the Current file and Create new file.\n 4. Use \'^\' ' 'To stop the execution \n Press \'Ok\' to start your script' ,"Welcome to SnapEz")
root = Tk.Tk()
root.wm_title("Browsers")
broButton = Tk.Button(master = root, text = 'Browse', width = 10,bg="salmon1", fg="white", command=browse_file)
broButton.pack(side=Tk.LEFT, padx = 2, pady=2)



Tk.mainloop()

while True:#Key press is handling
    print("Sucess 5")
    CreateFolder()
    
    with Listener(
        on_press=None,
        on_release=on_release) as listener:
           listener.join()
    word_doc()#calling word document conversion.

    
    if is_exit == True:
        endscript()
    
print("*****************endscript***********************")
    

