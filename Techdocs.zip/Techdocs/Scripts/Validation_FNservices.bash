#!/bin/bash

#########################################################################################
# Created by: Pandiyan Kuppan                                                           #
# Created on: 02 June 2019                                                              #
# Subject: Prod FN Services and Connection Establish Validation                         #
#########################################################################################
Send_From=Pandiyan.kuppan@fisglobal.com
Send_To=Pandiyan.kuppan@fisglobal.com
Send_cc=Pandiyan.kuppan@fisglobal.com
Send_To_Int=Pandiyan.kuppan@fisglobal.com

fn_home=/webdocs/cert2/apps/fm
Debug=/webdocs/cert2/apps/fm/fn_val.text
fmail=/webdocs/cert2/apps/fm/fn_mail.text
currtime=`date "+%y-%m-%d %H:%M:%S"`
mail_date=`date +%m/%d`


echo -e "$currtime: Validating All 5 FN Services"|tee -a $Debug

echo -e "Hi Team,\n" >$PROCESS_PATH/tc57_transfer.txt
echo "Please find the connectivity status of Conversion FN server to Conversion Clearing server on $mail_date.\n" >>$PROCESS_PATH/tc57_transfer.txt


cd $fn_home
ps -ef| grep -i 'DLOGNAME' |awk '{print $9,$10}' >tsk.txt

filename='mantatory.txt'
var=0
while read line; do

line="${line}"
#echo -e $line
grep -w "\\$line" tsk.txt
ret1=$?
if [ $ret1 -ne 0 ]
then
        echo -e " * $line service is not runnig on Conv FN Server. \n"|tee -a $Debug $fmail
        var=`expr $var + 1`
        fi

        done < $filename
        if [ $var -eq 0 ]
        then
        echo -e " * All services up in Conv FN Server. \n"|tee -a $Debug $fmail
        fi

sleep 1


echo -e "$currtime: Validating Connection Establish to Conv Clearing."|tee -a $Debug


netstat -an | grep 10002 |awk '{print $6}' >fn_clr.txt

filename='connfn.txt'
var=0
while read line; do

line="${line}"
#echo -e $line
grep -wF "$line" fn_clr.txt
ret1=$?
if [ $ret1 -ne 0 ]
then
        echo -e " * Conv FN Server $line is not active state. Please Check.\n"|tee -a $Debug $fmail
        var=`expr $var + 1`
        fi

        done < $filename
        if [ $var -eq 0 ]
        then
        echo -e " * Connection Establieshed from Conv FN server to Conv Clearing sevrer. \n"|tee -a $Debug $fmail
        fi

sleep 1

echo "$currtime:======================================================================="|tee -a $Debug

(cat $fn_home/fn_mail.text)|mailx -s "Conversoin FN Connectivity Status on $mail_date" -S smtp=Smtprelay.messageprovider.com -r "$Send_From" "$Send_To_Internal"
