#!/bin/bash

while true
do
        echo -e "\nIs All GUI Verified successfully (Y/N)" | tee -a
        read Input
        echo "$Input "
        if [ "$Input" = "Y" ] || [ "$Input" = "y" ]
        then
		echo -e "All the GUI validated successfully \n"
                sleep 1
                break;
        elif [ "$Input" = "N" ] || [ "$Input" = "n" ]
        then
                        echo "Please Specific Failed GUI's Name:"
                        echo "*Conv1-Clearing    *Conv1-MAS   *Conv1-MASFLEX"
                        echo "*Conv2-Clearing    *Conv2-MAS   *Conv2-MASFLEX   *Conv2-MMS"
						
					while :; do
						read GUI
						GUI="${GUI}"
					case "$GUI" in
						Conv1-Clearing|Conv1-MAS|Conv1-MASFLEX|Conv2-Clearing|Conv2-MAS|Conv2-MASFLEX|Conv2-MMS)
						echo -e "$GUI GUI Validation has been failed\n">$PROCESS_PATH/Validation_alert.txt; break;;
						*)
						echo "$GUI GUI Validation has been failed\n">$PROCESS_PATH/Validation_alert.txt; break;;
					esac
					done
		exit 2;
		fi
sleep 1
done