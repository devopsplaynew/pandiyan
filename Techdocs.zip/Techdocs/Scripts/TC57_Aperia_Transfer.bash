#! /usr/bin/env bash

TC57_Path=/data/TC57/Inbound/ARC
TC57_Aperia_transfer=/data/TC57/Inbound/ARC/ApreiaTransfer
debug=/apps/clearing/util/TC57_filetransfer.debug
Aperia_path=/I022604/BP1198_FIS_MPS_Processing/upload/

date=`date +%Y%m%d`
aperia_date=`date +%Y%m%d%H%M%S`
currtime=`date "+%y-%m-%d %H:%M:%S"`

cd $TC57_Path

tc57_file_check=`ls -lrt | grep $date |wc -l`

tc57_file=`ls -lrt | grep $date`

if [[ -z "$tc57_file_check" ]]
then
echo "TC57 file is Available to transfer" >>$debug

cp tc57_file $TC57_Aperia_transfer

cd $TC57_Aperia_transfer

aperia_file=mv $tc57_file FIS_FIS_TC57_Capture_C01_$aperia_date >>$debug

mv_res=$?

if [ $mv_res -eq 0 ]
then
echo $currtime 'TC57 file renamed successfully' $aperia_file>>$debug
return 1
else
echo $currtime 'TC57 file rename failed '$aperia_file>>$debug
exit 2
fi

#   tc57_sftp=`sftp -i /apps/clearing/mpstomoveit i022604@10.102.242.16 <<EOF
#   cd $Aperia_path
#   put $aperia_file
#   bye
#   EOF`

echo $currtime: 'TC57 file transfering' $tc57_sftp>>$debug
sleep 4

sftp_res=$?

if [ $sftp_res -eq 0 ]
then
echo "TC57 file transfer Success"
echo $currtime 'TC57 file transfering  to DX is success'>>$debug
return 1
else
echo "TC57 file transfer Failed"
echo $currtime 'TC57 file transfering to DX is failed '>>$debug
exit 2
fi

else
echo "Today TC57 file is not Available to transfer in Path"
echo $currtime "Today TC57 file is not Available to transfer in Path.. Please check">>$debug
exit
fi
