#!/bin/bash

function checkprepaid()
{
emp=`ps -eaf | grep "sftp mpsmoveit@10.76.164.52" | grep -v "grep sftp mpsmoveit@10.76.164.52" | awk '{print $6}'`
logtime=`ps -eaf | grep "sftp mpsmoveit@10.76.164.52" | grep -v "grep sftp mpsmoveit@10.76.164.52" | awk '{print $5}'`
userid=`ps -eaf | grep "sftp mpsmoveit@10.76.164.52" | grep -v "grep sftp mpsmoveit@10.76.164.52" | awk '{print $2}'`
arrtime=($logtime)
#arruserid=($userid)
}

i=0
checkprepaid

function userterminate()
{
echo -e "\nDo you want to terminate the existing Users connection (Y/N) ?"
read choice

if [ "$choice" = Y ] || [ "$choice" = y ]
then
	echo -e "\nTerminationg User connection to Prepaid. Please Wait."
        for uid in $userid
        do
                kill -9 $uid >>/dev/null
		sleep 5
        done

        userid=`ps -eaf | grep "sftp mpsmoveit@10.76.164.52" | grep -v "grep sftp mpsmoveit@10.76.164.52" | awk '{print $2}'`

        if [ -z "$userid" ]
        then
                echo -e "\nAll connections to prepaid are terminated\n"
                exit
	else
		echo -e "\nBelow User connection could be terminated."
		checkprepaid
		userdisp
		exit	
        fi
elif [ "$choice" = N ] || [  "$choice" = n ]
then
        echo -e "\n"
	exit
else
        echo -e "\nWrong choice. Please enter (Y/N). "
fi
}

function userdisp()
{
if [ -z "$emp" ]
then
	echo -e "\nNo user currently logged to Prepaid Server\n"
	exit
else
	echo -e "\nUsers logged in to Prepaid are: \n\n  User      LOGIN@\n--------    ------"
	num=`echo $emp | wc -l`
	for ei in $emp
	do
		users=`who | grep $ei | awk '{print $1}'`
		echo -e "$users    ${arrtime[$i]} ET"
		i=`expr $i + 1`
	done
userterminate
fi
}

userdisp
checkprepaid
i=0
userdisp
