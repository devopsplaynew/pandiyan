#!/bin/bash

user=`who am i |awk '{print $1}'`

echo -e "Hi $user,\n"
echo -e "Please Enter Your Choice : "

input_val="Please Enter Your Choice : "

Val=("stop_clearing" "stop_guiservice" "start_clearing" "start_guiservice" "Exit")


select opt in "${Val[@]}"

do
case $opt in
stop_clearing)
echo "--------------"
echo "You have selected stop_clearing."
echo "--------------"
;;
stop_guiservice)
echo "--------------"
echo "You have selected stop_guiservice."
echo "--------------"
;;
start_clearing)
echo "--------------"
echo "You have selected start_clearing."
echo "--------------"
;;
start_guiservice)
echo "--------------"
echo "You have selected start_guiservice."
echo "--------------"
;;
Exit)
echo "--------------"
echo "You have selected exit from script."
echo "--------------"
exit 2
;;
*)
echo "Error: Please Enter Valid input"
;;
esac
done