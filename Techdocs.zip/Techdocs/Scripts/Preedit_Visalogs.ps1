#For Copy name of Visa Incoming files/Reports shared for the day from preedit.

$visa_path="\\Lrk1wmpsnppap01\D$\EP40\C472611\INCOMING"
$rpt_date=(Get-Date).AddDays(-1).ToString('yyMMdd')
$logs="\\Lrk1wmpsnppap01\D$\SFTP_ROOT\preedit_summary.log"

function Incoming_rpts
{
$incrpts=Get-ChildItem $visa_path -Recurse | Where-Object{(($_.Name -match "$rpt_date") )} | select name
if(!$incrpts)
    {
        Write-Host VISA Incoming reports not found
        Add-Content $logs "VISA Incoming reports not found for $rpt_date "
    }
else

		Get-ChildItem $visa_path -Recurse | Where-Object{(($_.Name -match "$rpt_date") )} | select name >preedit_info.txt
		Write-Host $incrpts
		Add-Content $logs "VISA Incoming report Names copied for $rpt_date"
}

Incoming_rpts