#! /usr/bin/env bash
#########################################################################################
# Created by: Pandiyan Kuppan                                                           #
# Created on: 02 June 2019                                                               #
# Subject: Reports Count Check                                                #
#########################################################################################


Date=`date "+%m-%d-%Y"`
mail_date=`date "+%m/%d"`
currtime=`date "+%y-%m-%d %H:%M:%S"`
Reports_Path="/apps/clearing/pdir20190516/ositeroot/data/mps_daily_reports"
csv_temp="/apps/clearing/pdir20190516/ositeroot/data/mps_daily_reports/temp_csv"

Debug=/apps/clearing/util/reports_clr.txt

process_path=/apps/clearing/util
rpt_mail=/apps/clearing/util/rpt_mail.txt


Send_From=Pandiyan.kuppan@fisglobal.com
Send_To=Pandiyan.kuppan@fisglobal.com
Send_cc=Pandiyan.kuppan@fisglobal.com
Send_To_Int=Pandiyan.kuppan@fisglobal.com

report_val()
{
cd $Reports_Path
Clr_Reports_cnt=`ls -lrt MPS_DailyReports_CLR*$Date* | grep -v "\.Val\|\.csv" |wc -l`

if [ $Clr_Reports_cnt -eq 5 ]
then
echo -e $currtime: "All 5 Clearing Reports Avaialbale for $Date" |tee -a $Debug
else
echo -e $currtime: "Clearing Reports not available for $Date"|tee -a $Debug
exit 2
fi
}

csv_conversion()
{
Clr_Reports=`ls -lrt MPS_DailyReports_CLR*$Date* | grep -v "\.Val\|\.csv" |awk '{print $9}'`

echo -e "$Clr_Reports | tr [:space:] '\n'" |tee -a $Debug

for i in $Clr_Reports

do

before_csv=`echo $i |sed 's/\.xlsx//'`

python /apps/clearing/util/Testing_Scripts/conv_excel2csv.py $before_csv
mv MPS_DailyReports_CLR*$Date*.csv $csv_temp
done
}

count_check()
{
cd $csv_temp
csv_reports=`ls -lrt MPS_DailyReports_CLR*$Date*.csv |awk '{print $9}'`
for i in $csv_reports

do
rpt_name=$(echo $i | awk -F'[_]' '{print $3}'|sed 's/'$Date'//g'|sed 's/CLR//g')
row_count=`wc -l $i |awk '{print $1}'`

echo -e "Hi All\n" |tee -a $debug
echo -e "Please find the Clearing Morning cycle Activity Reports for $mail_date. All Reports will be shared through file link.\n" |tee -a $debug
echo -e "Count Of" $rpt_name "Report - " $row_count |tee -a $debug

if [[ "$rpt_name" = "Suspend" ]] && [[ $row_count -ge 200 ]]
then
echo -e "\nClearing Suspended report count $row_count is high . Please Check With Business Team." |tee -a $debug
#else
#echo ""
fi
mv $i $i.done
done
}

remov_csv_rpts()
{
echo -e $currtime: "removing csv Converted files from temp path"|tee -a $debug
cd $csv_temp
rm MPS_DailyReports_CLR*$Date*.csv.done
result=$?
echo $result
if [ $result -eq 0 ]
then
echo -e $currtime: "csv file successfully removed from temp path" |tee -a $debug
else
echo -e $currtime: "csv file failed to remove from temp path" |tee -a $debug
fi
exit 2
}

report_val
csv_conversion
count_check
remov_csv_rpts