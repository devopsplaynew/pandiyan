#!/bin/bash
FRUIT="kiwi"
case "$FRUIT" in "apple") 
echo "Apple pie is quite tasty." ;;
	"banana") 
echo "I like banana nut bread." ;; 
	"kiwi")
echo "New Zealand is famous for kiwi." ;; 
esac


=================================================================
#! /bin/bash
a=0
while [ $a -lt 10 ]
do
b=$a;
while [ $b -ge 0 ] 
do
echo -n "$b"
b=`expr $b - 1`
done
echo
a=`expr $a + 1`
done

0
10
210
3210
43210
543210
6543210
76543210
876543210
9876543210

====================================================================
#!/bin/sh 
NUMS="1 2 3 4 5 6 7" 
for NUM in $NUMS 
do 
Q=`expr $NUM % 2`
if [ $Q -eq 0 ] 
then 
echo "$NUM is an even number!!" 
continue 
fi
echo "$NUM odd number" 
done

1 odd number
2 is an even number!!
3 odd number
4 is an even number!!
5 odd number
6 is an even number!!
7 odd number
===================================================================
