#! /usr/bin/env bash
#########################################################################################
# Created by: Pandiyan Kuppan                                                           #
# Created on: 02 June 2019                                                               #
# Subject: Reports Count Check                                                #
#########################################################################################

Date=`date "+%m-%d-%Y"`
mail_date=`date "+%m/%d"`
currtime=`date "+%y-%m-%d %H:%M:%S"`
Reports_Path="/apps/clearing/pdir20190516/ositeroot/data/mps_daily_reports"
csv_temp="/apps/clearing/pdir20190516/ositeroot/data/mps_daily_reports/temp_csv"


csv_conversion()
{
cd $Reports_Path
Clr_Reports=`ls -lrt MPS_DailyReports_CLR*$Date* | grep -v "\.Val\|\.csv" |grep -v 'CLRReject' | grep -v 'CLRReclass' |awk '{print $9}'`

echo -e "$Clr_Reports | tr [:space:] '\n'"
for i in $Clr_Reports
do
before_csv=`echo $i |sed 's/\.xlsx//'`

python /apps/clearing/util/Testing_Scripts/conv_excel2csv.py $before_csv
mv MPS_DailyReports_CLR*$Date*.csv $csv_temp
done
}

get_clrrpt_count()
{
cd $csv_temp
csv_reports=`ls -lrt MPS_DailyReports_CLR*$Date*.csv |awk '{print $9}'`

for files in $csv_reports
do
rpt_name=$(echo $files | awk -F'[_]' '{print $3}'|sed 's/'$Date'//g'|sed 's/CLR//g')
row_count=`wc -l $files |awk '{print $1}'`

if [[ "$rpt_name" = "Suspend" ]]
then
awk -F , '{a[$13]++;}END{for (i in a)print i, a[i];}' $files
echo -e $rpt_name "-" $row_count
else
row_count=`wc -l $files |awk '{print $1}'`
echo -e $rpt_name "-" $row_count
fi
done
}

csv_conversion
get_clrrpt_count

