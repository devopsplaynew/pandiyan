#! /usr/bin/env ksh
#date=`date "+%m%d%Y"`
date=`date --date='-1 day' "+%m%d%Y"`
ews_date=`date --date='-1 day' "+%Y%m%d"`
zelle_date=`date --date='-1 day' "+%y%m%d"`
dis_date=`date --date='-1 day' "+%d%b%Y"`
juldate=`date "+%Y%j"`
ocs_date=`date --date='-1 day' "+%b %_d"`

echo "OCS CBK"
ls -lrt /data/OCS/Inbound/ARC |grep $ocs_date|grep 'chrgbakocs.19'|awk '{print $9}'

sleep 1
echo "--------------------------------------------------------------------------------------------------"
echo "Outgoing - Amex NON-ICBA"
ls -lrt /data/AMEX/Outbound/OPTBLUE/SUB_SETTLEMENT/ARC |grep $zelle_date|awk '{print $9"    "$8}'

ls -lrt /data/AMEX/Outbound/OPTBLUE/SUB_SETTLEMENT_ICBA/ARC |grep $zelle_date|awk '{print $9"    "$8}'

sleep 1
echo " "
echo "--------------------------------------------------------------------------------------------------"
echo "Outgoing - DISCOVER"
echo " "
ls -lrt /data/Discover/Outbound/ARC |grep $juldate|awk '{print $9"    "$8}'

sleep 1
echo "--------------------------------------------------------------------------------------------------"
echo "Outgoing - MC"
echo " "
ls -lrt /data/MC/Outbound/ARC |grep $zelle_date|awk '{print $9"    "$8}'

sleep 1
echo "--------------------------------------------------------------------------------------------------"
echo "Outgoing - VISA"
echo " "
ls -lrt /data/VISA/Outbound/ARC |grep $zelle_date|awk '{print $9"    "$8}'

sleep 1
echo "--------------------------------------------------------------------------------------------------"
echo "Incoming - EWS"
echo " "
ls -lrt /data/EWS/Inbound/Zelle/ARC |grep MPS.MPSPROD.$ews_date*|awk '{print $9}'

sleep 1

echo "Incoming - MC Zelle"
echo " "
ls -lrt /data/MC/Inbound/ZELLE |grep MPS.MPSPROD.*$zelle_date|awk '{print $9}'
echo " "
sleep 1

echo "------------------Incoming - Reports and Files Shared--------------------------------------------"
echo " "
echo "BASE2.CHARGEBACK.$date.CTF.S0000.EPIN03"
echo "BASE2.FEESFUNDS.$date.CTF.S0000.EPIN04"
echo "BASE2.INC_ALL.$date.CTF.S0000.EPIN"
echo "BASE2.RECLASS.$date.CTF.S0000.EPIN02"
echo "BASE2.SMSRAWDATA.$date.CTF.S0000.EPIN05"
echo "--------------------------------------------------------------------------------------------------"
echo " "
sleep 1

ls /data/MC/Inbound/ARC/MC_Inbound_$date* |grep -v '/data/MC/Inbound/ARC/'|grep -v '.txt'|sort -k9

#echo $mc_inbound
echo "--------------------------------------------------------------------------------------------------"
echo " "
sleep 1

ls -lrt /data/Discover/Inbound/ARC/Inbound_DIS_$dis_date*|grep -v '/data/Discover/Inbound/ARC/' |grep -v '.txt'|awk '{print $9}'

#echo $dis_inbound
