#!/bin/bash
PROCESS_PATH=/tmp/test
Send_From=pandiyan.kuppan@fisglobal.com
Send_To=pandiyan.kuppan@fisglobal.com
Send_To_Internal=pandiyan.kuppan@fisglobal.com

util=/apps/conv/clearing/util
Date=`date "+%m/%d"`
echo "==============================================================================="

###Gui_check

while true
do
        echo -e "\nIs All GUI Verified successfully (Y/N)" | tee -a
        read Input
        echo "$Input "
        if [ "$Input" = "Y" ] || [ "$Input" = "y" ]
        then
                echo -e "All the Conversion GUI's validated successfully \n" >$PROCESS_PATH/Validation_alert.txt
                sleep 1
                break;
        elif [ "$Input" = "N" ] || [ "$Input" = "n" ]
        then
                        echo "Please Specific Failed GUI's Name:"
                        echo "*Conv1-Clearing    *Conv1-MAS   *Conv1-MASFLEX"
                        echo "*Conv2-Clearing    *Conv2-MAS   *Conv2-MASFLEX   *Conv2-MMS"

                                        while :; do
                                                read GUI
                                                GUI="${GUI}"
                                        case "$GUI" in
                                                Conv1-Clearing|Conv1-MAS|Conv1-MASFLEX|Conv2-Clearing|Conv2-MAS|Conv2-MASFLEX|Conv2-MMS)
                                                echo -e "$GUI GUI Validation has been failed\n">$PROCESS_PATH/Validation_alert.txt; break;;
                                                *)
                                                echo "Please Enter Correct GUI Name as above specified\n">$PROCESS_PATH/Validation_alert.txt; break;;
                                        esac
                                        done
                exit 2;
                fi
sleep 1
done

#echo "Checking Pre-edit 10.236.134.164 connection"

preedit_sftp=`/apps/clearing/sshpass -p 'fvGnpaGKkCFjPh' sftp sftpedit@10.236.134.164 <<EOF
bye
EOF`

status=`echo $?`

if [ $status -eq 0 ]
then
                echo -e "SFTP Conv2-Clearing to Pre-edit server Validation is Success\n" >>$PROCESS_PATH/Validation_alert.txt
else
                echo -e "SFTP Conv2-Clearing to Preedit 10.236.134.164 is Failed\n">>$PROCESS_PATH/Validation_alert.txt
fi

sleep 3

#echo "Checking Clearing tskcmd services"

status=`tskcmd |wc -l`

if [ $status -eq 15 ]
then
                echo -e "All tasks are running fine in Conv2-Clearing server\n" >>$PROCESS_PATH/Validation_alert.txt
else
                echo -e "Only $status services running in Conv2-Clearing, expecting 15 Services.. Please check\n" >>$PROCESS_PATH/Validation_alert.txt
fi

sleep 3

#echo "==============================================================================="

#echo "Checking GUI services"

status1=`ps -ef | grep "oassrv -b" | grep clrconv | grep -v "grep oassrv -b" |wc -l`

if [ $status1 -eq 1 ]
then
                echo -e "oassrv -b GUI service running in Conv2 Clearing\n"
else
                echo -e "oassrv -b GUI service not running in Conv2 Clearing.. Please check"

fi

sleep 3

status2=`ps -ef | grep "oentsrv -b" | grep clrconv | grep -v "grep oentsrv -b" |wc -l`

if [ $status2 -eq 1 ]
then
                echo -e "oentsrv -b GUI service running in Conv2 Clearing\n"
else
                echo -e " oentsrv -b GUI service not running in Conv2 Clearing.. Please check"
fi

sleep 3

if [ $status1 -eq 1 ] && [ $status2 -eq 1 ]
then
echo -e "GUI's Services running as expected on Conv2-Clearing\n" >>$PROCESS_PATH/Validation_alert.txt
else
echo -e "GUI's Services not running as expected on Conv2-Clearing\n" >>$PROCESS_PATH/Validation_alert.txt
fi
#echo "==============================================================================="

                disk_space=`df -h /apps/|tail -1 |awk '{print "Used--->"$4,"Available--->"$3}'`

                echo "Disk space $disk_space"

                used_disk=`df -h /apps/|tail -1 |awk '{print $4}' | sed "s/[^0-9]//g"`

if [ $used_disk -lt 85 ]
then
                echo -e "Used Disk space is $used_disk % "
                echo -e "Conversion Disk Space is well in tresheld \n" >>$PROCESS_PATH/Validation_alert.txt
else
                                echo -e "Warning: Used Disk Space is Critical $used_disk... Please clear old logs\n"
fi

sleep 3

#echo "==============================================================================="

#echo "Checking FN connection"

 numFMConn=`mbportcmd list | grep -A1 FMFormatter | grep -v FMFormatter | grep connected | wc -l`
                if [ $numFMConn -eq 1 ]
                then
                                echo "TCPIP Connected to Fraud Navigator - Result $numFMConn"
                                echo -e "FN Connectivity to Conv2-Clearing is success\n" >>$PROCESS_PATH/Validation_alert.txt
                else
                                echo -e "ERROR: No TCPIP Connectio to FN - Result $numFMConn\n" >>$PROCESS_PATH/Validation_alert.txt
                fi
sleep 3
echo "===============================================================================\n">>$PROCESS_PATH/Validation_alert.txt
cd /apps/conv/mas/util/Testing_Scripts
./Validation_MAS.bash

(cat $PROCESS_PATH/Validation_alert.txt)|mailx -s "Weekend LTR Validation on $Date" -S smtp=Smtprelay.messageprovider.com -r "$Send_From" "$Send_To_Internal"
