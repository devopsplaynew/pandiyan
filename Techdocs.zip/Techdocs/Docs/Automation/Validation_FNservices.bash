#!/bin/bash

#########################################################################################
# Created by: Pandiyan Kuppan                                                           #
# Created on: 02 June 2019                                                              #
# Subject: Prod FN Services and Connection Establish Validation                         #
#########################################################################################

fn_home=/home/fnadm
Debug=/home/fnadm/fn_val.text
currtime=`date "+%y-%m-%d %H:%M:%S"`

echo -e "$currtime: Validating All 5 FN Services"|tee -a $Debug

cd $fn_home
ps -ef| grep -i 'DLOGNAME' |awk '{print $9,$10}' >tsk.txt

filename='mantatory.txt'
var=0
while read line; do

line="${line}"

grep -w $line tsk.txt
ret1=$?
if [ $ret1 -ne 0 ]
then
        echo -e " * $line service is not runnig on Prod FN Server. \n"|tee -a $Debug
        var=`expr $var + 1`
        fi

        done < $filename
        if [ $var -eq 0 ]
        then
        echo -e " * All services up in Prod FN Server. \n"|tee -a $Debug
        fi

sleep 1


echo -e "$currtime: Validating Connection Establish to prod Clearing."|tee -a $Debug


netstat -an | grep 10005 |awk '{print $5,$6}' >fn_clr.txt

filename='connfn.txt'
var=0
while read line; do

line="${line}"

grep -w $line fn_clr.txt
ret1=$?
if [ $ret1 -ne 0 ]
then
        echo -e " * Prod FN Server $line is not active state. Please Check.\n"|tee -a $Debug
        var=`expr $var + 1`
        fi

        done < $filename
        if [ $var -eq 0 ]
        then
        echo -e " * Connection Establieshed from Prod FN server to Prod Clearing sevrer. \n"|tee -a $Debug
        fi

sleep 1

echo "$currtime:======================================================================="|tee -a $Debug