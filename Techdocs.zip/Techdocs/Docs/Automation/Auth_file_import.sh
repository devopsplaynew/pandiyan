#! /usr/bin/env bash

execution_path=/apps/clearing/pdir20190220/ositeroot/data/in/mpsfee
standing_path=/data/TC57/Inbound
ARC_Path=/data/TC57/Inbound/ARC
date=`date +%m%d%Y`
currtime=`date "+%y-%m-%d %H:%M:%S"`
mail_date=`date +%m/%d`
jul_date=`date "+%j"`

standing_file_check()
{
cd $standing_path

authfile_check=`ls -lrt |grep 'Auth_File' | grep $date |wc -l`

if [ $authfile_check -eq 1 ]
then
Auth_File=`ls -lrt |grep 'Auth_File' | grep $date |awk '{print $9}'`

echo "Auth file is availble to process"

authfile_size=`stat -c%s $Auth_File`
if [ $authfile_size -eq 0 ]
then
echo "Standing Auth_File size is zero"
exit 2
else
echo "Standing Auth_File size is correct"
fi		
else
echo "Auth file is not availe to process $date or morethan one file available in standing path, file count is $authfile_check"
exit 2
fi
}

mps_command_check()
{
mpscmd=`ps -eaf | grep mps_schcmd | grep -v "tail\|grep mps_schcmd" | head -1`

if [[ -z "$mpscmd" ]]
then
echo "mps command check is completed"
else
echo "mps_schcmd commands are running in background.. Exiting"
exit 2
fi
}

copy_authfile_exec()
{
cd $execution_path

exec_file_check=`ls -lrt |grep 'mpsfee'|wc -l`

if [ $exec_file_check -ge 1 ]
then
echo "Auth file is already availble in $execution_path ,please check execution path"
exit 2

else
cd $standing_path
cp $Auth_File $execution_path
res=$?
if [ $res -eq 0 ]
then
echo "Auth File copied successfully to execute path"
else
echo "Auth File Copy to execute path failed"
exit 2
fi
fi
}


rename_exec_filename()
{
cd $execution_path
mv $Auth_File mpsfee.$jul_date
res=$?
if [ $res -eq 0 ]
then
echo "Auth File renamed successfully in execute path"
exec_auth_file_name=`ls -lrt |grep 'mpsfee'| grep $jul_date |awk '{print $9}'`
else
echo "Auth File rename to failed in execute path"
exit 2
fi
}


mps_schcmd()
{
#auth_schcmd="mps_schcmd -aCLR  -pimport -t161 -f$exec_auth_file_name"
#echo "mps_schcmd to execute:" $auth_schcmd
#$auth_schcmd
#impres=$?
impres=0
if [ $impres -eq 0 -o $impres -eq 12 ] 
then
echo "Auth file processed successfully into clearing $impres"
cd $standing_path
mv $Auth_File $ARC_Path/$Auth_File.DONE
zena_res=1
return 0
else
echo "Auth file import failed with return code $impres"
cd $standing_path
mv $Auth_File $ARC_Path/$Auth_File.FAIL
zena_res=$impres
return 2
fi
}

#CALLING FUNCTIONS
standing_file_check
mps_command_check
copy_authfile_exec
rename_exec_filename
mps_schcmd
