#!/bin/bash

cd /data/OCS/Inbound
sftp=`sftp e3028647@10.236.134.63 <<EOF
cd /data/OCS/Inbound
get chrgbakocs*	
bye
EOF`
