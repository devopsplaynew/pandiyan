#! /usr/bin/env ksh

currtime=`date "+%y-%m-%d %H:%M:%S"`

mccbk_date2=`date --date='yesterday' "+%y%m%d"`
mcrej_date=`date "+%y%m%d"`
disccbk_date=`date --date='yesterday' "+%d%m%y"`
visacbk_date=`date --date='yesterday' "+%m%d%Y"`
visrej_date=`date "+%m%d%Y"`
mccbk_path=/data/MC/Inbound/CHARGEBACK/ARC
visacbk_path=/data/VISA/Inbound/CHARGEBACK/ARC
discbk_path=/data/Discover/Inbound/CHARGEBACK/ARC
mc_rec_path=/data/MC/Inbound/RECLASS/ARC
visa_rec_path=/data/VISA/Inbound/RECLASS/ARC
mc_rej_path=/data/MC/Inbound/REJECT/ARC
visa_rej_path=/data/VISA/Inbound/REJECT/ARC
debug=/tmp/test/morning_rrrfiles.txt

echo -e "_____________________________________________________________________________\n" |tee -a $debug

cd $mc_rej_path
mc_rej_file_cnt=`ls -l|grep "\.T113\." | grep "D$mcrej_date" | wc -l`
if [ $mc_rej_file_cnt -ge 1 ]
then
for file in MPS.MCPROD.T113.MCACKNOWLEDGMENT.D$mcrej_date.*
do
file1=$(echo $file |sed 's/.DONE//g')
echo -e $file1 |tee -a  $debug
done
else
echo -e "No MC reject file for $mcrej_date , count of MC reject fie is $mc_rej_file_cnt" |tee -a $debug
fi


cd $visa_rej_path
visa_rej_file_cnt=`ls -l|grep "REJECT.TRANS.$visrej_date" | wc -l`
if [ $visa_rej_file_cnt -ge 1 ]
then

for file in REJECT.TRANS.$visrej_date.*
do
file1=$(echo $file |sed 's/.DONE//g')
echo -e $file1 |tee -a  $debug
done
else
echo -e "No Visa reject file for $visrej_date , count of Visa reject fie is $visa_rej_file_cnt" |tee -a $debug
fi


echo -e "_____________________________________________________________________________\n" |tee -a $debug


#Check MC cbk file Count
cd $mccbk_path
mc_cbk_file_cnt=`ls -l|grep "\.T112\." | grep "D$mccbk_date2" | wc -l`
if [ $mc_cbk_file_cnt -eq 6 ]
then
#echo -e "_____________________________________________________________________________\n" |tee -a $debug

for file in MPS.MCPROD.T112.MCCLEARINGCYCLE.D$mccbk_date2.*
do
file1=$(echo $file |sed 's/.DONE//g')
echo -e $file1 |tee -a  $debug
done
else
echo -e "MC CBK file Count is not matching for $mccbk_date2 , count is $mc_cbk_file_cnt" |tee -a $debug
fi


#Check VISA cbk file Count
cd $visacbk_path
visa_cbk_file_cnt=`ls -l | grep "BASE2.CHARGEBACK" | grep "$visacbk_date" | wc -l`

if [ $visa_cbk_file_cnt -eq 1 ]
then
#echo -e "_____________________________________________________________________________\n" |tee -a $debug

for file in BASE2.CHARGEBACK.$visacbk_date.*
do
file1=$(echo $file |sed 's/.DONE//g')
echo -e $file1 |tee -a  $debug
done
else
echo -e "Visa CBK file Count is not matching for $visacbk_date , count is $mc_cbk_file_cnt" |tee -a $debug
fi


#Check DISC cbk file Count
cd $discbk_path
disc_cbk_file_cnt=`ls -l | grep "PRD.MPS.DFS.DISPRSPN" | grep "$disccbk_date" | wc -l`

if [ $disc_cbk_file_cnt -eq 1 ]
then
#echo -e "_____________________________________________________________________________\n" |tee -a $debug
for file in PRD.MPS.DFS.DISPRSPN.$disccbk_date.*
do
file1=$(echo $file |sed 's/.DONE//g')
echo -e $file1 |tee -a  $debug
done
else
echo -e "Discover CBK file Count is not matching for $visacbk_date , count is $mc_cbk_file_cnt" |tee -a $debug
fi

echo -e "_____________________________________________________________________________\n" |tee -a $debug

cd $mc_rec_path
mc_rec_file_cnt=`ls -l|grep "\.T884\." | grep "D$mccbk_date2" | wc -l`
if [ $mc_rec_file_cnt -eq 1 ]
then
for file in MPS.MPSPROD.T884.MCICACQDETAILADJ.D$mcrej_date.*
do
file1=$(echo $file |sed 's/.DONE//g')
echo -e $file1 |tee -a  $debug
done
else
echo -e "No MC Reclass file for $mcrej_date , count of MC reclass fie is $mc_rec_file_cnt" |tee -a $debug
fi


cd $visa_rec_path
visa_rec_file_cnt=`ls -l|grep "RECLASS.$visacbk_date" | wc -l`
if [ $visa_rec_file_cnt -ge 1 ]
then
for file in BASE2.RECLASS.$visacbk_date.*
do
file1=$(echo $file |sed 's/.DONE//g')
echo -e $file1 |tee -a  $debug
done
else
echo -e "No Visa Reclass file for $visacbk_date , count of Visa reject fie is $visa_rec_file_cnt" |tee -a $debug
fi
echo -e "_____________________________________________________________________________\n" |tee -a $debug
