#!/bin/bash

util=/apps/mas/util

echo "==============================================================================="

#echo "Checking Pre-edit 10.236.134.164 connection"

preedit_sftp=`/apps/mas/sshpass -p 'fvGnpaGKkCFjPh' sftp sftpedit@10.236.134.164 <<EOF
bye
EOF`

status=`echo $?`

if [ $status -eq 0 ]
then
        echo "SFTP MAS to Pre-edit 10.236.134.164 server Validation is Success"
else
		echo -e "\e[1;31m"" SFTP MAS to Preedit 10.236.134.164 is Failed""\e[0m"
fi

sleep 3


#echo "==============================================================================="
#echo "Checking Prod DN 10.236.134.71 connection"

dn_sftp=`/apps/mas/sshpass -p 'LeV7SWPMygtGw2' sftp sftpdn@10.236.134.71 <<EOF
bye
EOF`

status=`echo $?`

if [ $status -eq 0 ] 
then
	echo "SFTP MAS to Prod DN 10.236.134.71 server Validation is Success"
else
	echo -e "\e[1;31m"" SFTP MAS to Prod DN is Failed""\e[0m"

fi

sleep 3

#echo "==============================================================================="

#echo "Checking MAS tskcmd services"

status=`tskcmd |wc -l`

if [ $status -eq 33 ] 
then
	echo "All $status Services are up in MAS"
else
	echo -e "\e[1;31m"" Only $status services running in MAS, expecting 33 Services.. Please check""\e[0m"
fi

sleep 3

#echo "==============================================================================="

#echo "Checking GUI services"

status=`ps -ef | grep "oassrv -b" | grep masprod | grep -v "grep oassrv -b" |wc -l`

if [ $status -eq 1 ] 
then
	echo "oassrv -b GUI service running in prod MAS"
else
	echo -e "\e[1;31m"" oassrv -b GUI service not running in prod MAS.. Please check""\e[0m"

fi

sleep 3

status=`ps -ef | grep "oentsrv -b" | grep masprod | grep -v "grep oentsrv -b" |wc -l`

if [ $status -eq 1 ] 
then
	echo "oentsrv -b GUI service running in prod MAS"
else
		echo -e "\e[1;31m"" oentsrv -b GUI service not running in prod MAS.. Please check""\e[0m"
fi

sleep 3

#echo "==============================================================================="

#echo "Checking DX Connection"

DX_sftp=`sftp -i /apps/mas/mpstomoveit i022604@10.102.242.16 <<EOF
bye
EOF`

status=`echo $?`

if [ $status -eq 0 ]
then
        echo "SFTP MAS to DX 10.102.242.16 server is Success"
else
		echo -e "\e[1;31m"" SFTP MAS to DX 10.102.242.16 is Failed""\e[0m"
fi

sleep 3

#echo "==============================================================================="

#echo "Checking Disk Usage for /Apps"

	disk_space=`df -h /apps/|tail -1 |awk '{print "Used--->"$4,"Available--->"$3}'`
	
	echo "Disk space $disk_space"
	
	used_disk=`df -h /apps/|tail -1 |awk '{print $4}' | sed "s/[^0-9]//g"`
	
if [ $used_disk -lt 85 ]
then
        echo "Used space is $used_disk -- Disk space is Available"
else
		echo -e "\e[1;31m"" Warning: Used Disk Space is Critical $used_disk... Please clear old logs.""\e[0m"
fi

sleep 3

#echo "==============================================================================="

echo "Checking Database Connection"

cd $util
	./check_gldate.ksh
	 
	 err_file=`grep 'db_err_file' check_input.txt | grep -v '^#' | awk -F= '{print $2};'`
	 err_file_size=`stat -c%s $err_file`

	    if [ $err_file_size -eq 0 ]
        then
            echo "No errors in DB connection "
        else
            echo "Warning: Errors in DB connection... Please check"
        fi
sleep 3

#echo "==============================================================================="
