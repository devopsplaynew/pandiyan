#!/bin/bash

util=/apps/mas/util
PROCESS_PATH=/tmp/test
Send_From=pandiyan.kuppan@fisglobal.com
Send_To=pandiyan.kuppan@fisglobal.com
Send_To_Internal=pandiyan.kuppan@fisglobal.com

echo "==============================================================================="

#echo "Checking Pre-edit 10.236.134.164 connection"

preedit_sftp=`/apps/mas/sshpass -p 'fvGnpaGKkCFjPh' sftp sftpedit@10.236.134.164 <<EOF
bye
EOF`

status=`echo $?`

if [ $status -eq 0 ]
then
        echo -e " * SFTP Prod MAS to Pre-edit server Validation is Success\n">>$PROCESS_PATH/Validation_alert.txt
else
        echo -e " * FAILED - SFTP Prod MAS to Pre-edit server Validation failed\n">>$PROCESS_PATH/Validation_alert.txt
fi

sleep 2



#echo "==============================================================================="
#echo "Checking Prod DN 10.236.134.71 connection"

dn_sftp=`/apps/mas/sshpass -p 'LeV7SWPMygtGw2' sftp sftpdn@10.236.134.71 <<EOF
bye
EOF`

status=`echo $?`

if [ $status -eq 0 ]
then
        echo -e " * SFTP MAS to Prod DN server Validation is Success\n">>$PROCESS_PATH/Validation_alert.txt
else
        echo -e " * FAILED - SFTP MAS to Prod DN server Validation is failed\n">>$PROCESS_PATH/Validation_alert.txt

fi

sleep 3

#echo "==============================================================================="

#echo "Checking MAS tskcmd services"

status=`tskcmd |wc -l`

if [ $status -eq 33 ]
then
        echo -e " * All Services are up in MAS\n">>$PROCESS_PATH/Validation_alert.txt
else
        echo -e " * Warning - Only $status services running in Prod MAS, expecting 33 Services.. Please check\n">>$PROCESS_PATH/Validation_alert.txt
fi

sleep 3

#echo "==============================================================================="

#echo "Checking GUI services"

status1=`ps -ef | grep "oassrv -b" | grep masprod | grep -v "grep oassrv -b" |wc -l`

sleep 1

status2=`ps -ef | grep "oentsrv -b" | grep masprod | grep -v "grep oentsrv -b" |wc -l`

if [ $status1 -eq 1 ] && [ $status2 -eq 1 ]
then
echo -e " * All GUI's Services running as expected on Prod MAS Server\n" >>$PROCESS_PATH/Validation_alert.txt
else
echo -e " * All GUI's Services not running as expected on Prod MAS Server\n" >>$PROCESS_PATH/Validation_alert.txt
fi
sleep 2


#echo "==============================================================================="

#echo "Checking DX Connection"

DX_sftp=`sftp -i /apps/mas/mpstomoveit i022604@10.102.242.16 <<EOF
bye
EOF`

status=`echo $?`

if [ $status -eq 0 ]
then
        echo -e " * SFTP Prod MAS to DX server is Success.\n">>$PROCESS_PATH/Validation_alert.txt
else
		echo -e " * FAILED - SFTP Prod MAS to DX server is failed.\n">>$PROCESS_PATH/Validation_alert.txt
fi

sleep 3

#echo "==============================================================================="

#echo "Checking Disk Usage for /Apps"

        disk_space=`df -h /apps/|tail -1 |awk '{print "Used--->"$4,"Available--->"$3}'`

        echo "Disk space $disk_space"

        used_disk=`df -h /apps/|tail -1 |awk '{print $4}' | sed "s/[^0-9]//g"`

if [ $used_disk -lt 85 ]
then
        echo -e " * Prod MAS Disk Space is well in threshold.\n">>$PROCESS_PATH/Validation_alert.txt
else
		echo -e " * Warning: MAS Used Disk Space is Critical $used_disk... Please clear old logs.\n">>$PROCESS_PATH/Validation_alert.txt
fi

sleep 3

#echo "==============================================================================="

#echo "Checking Database Connection"

cd $util
       ./check_gldate.ksh

        err_file=`grep 'db_err_file' check_input.txt | grep -v '^#' | awk -F= '{print $2};'`
        err_file_size=`stat -c%s $err_file`

          if [ $err_file_size -eq 0 ]
        then
            echo -e " * Prod MAS Database connectivity Verifited successfully.\n">>$PROCESS_PATH/Validation_alert.txt
        else
            echo -e " * Warning: Errors in Prod MAS DB connection... Please check.\n">>$PROCESS_PATH/Validation_alert.txt
        fi
sleep 3

echo "==============================================================================="

Date=`date "+%m/%d"`
###Gui_check

while :
do
        echo -e "\nIs All GUI's Verified successfully (Y/N)" | tee -a
        read Input
        echo "$Input "
        if [ "$Input" = "Y" ] || [ "$Input" = "y" ]
        then
                echo -e " * All the Production GUI's validated successfully \n" >>$PROCESS_PATH/Validation_alert.txt
                sleep 1
                break;
        elif [ "$Input" = "N" ] || [ "$Input" = "n" ]
        then
                        while true ; do

                        echo -e "\e[1;32m""Please Specific Failed GUI's Name:""\e[0m"
                        echo -e "\e[1;31m""*Prod-Clearing    *Prod-MAS   *Prod-MMS""\e[0m"
                                read GUI
                        #               while true ; do
                                        #       read GUI
                                                GUI="${GUI}"
                                        case "$GUI" in
                                                Prod-Clearing|Prod-MAS|Prod-MMS)
                                                echo -e " * $GUI GUI Validation has been failed\n">>$PROCESS_PATH/Validation_alert.txt
                                                ;;
                                                *)
                                                echo -e "Please Enter Correct GUI Name as above specified\n"
                                         ;;
                                        esac
                        echo -e "Any other GUI's Failed : (Y/N)"
                                read user
                [ "$user" = "N" ] && break || [ "$user" = "n" ] && break

                                        done
                                        break;
        #       exit 2;
        else
                echo "Please enter Valid Input"
                fi
sleep 1
done



        echo -e "\n\nRegards" >>$PROCESS_PATH/Validation_alert.txt
        echo "MPS Operations Support" >>$PROCESS_PATH/Validation_alert.txt

(cat $PROCESS_PATH/Validation_alert.txt)|mailx -s "Weekend Prod LTR Validation on $Date" -S smtp=Smtprelay.messageprovider.com -r "$Send_From" "$Send_To_Internal"
