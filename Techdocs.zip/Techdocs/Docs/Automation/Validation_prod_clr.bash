#!/bin/bash

util=/apps/clearing/util
PROCESS_PATH=/tmp/test

Date=`date "+%m/%d"`
echo -e "Hi Team, \n" >$PROCESS_PATH/Validation_alert.txt
echo -e "Please find the Production LTR servers Validation on $Date. \n" >>$PROCESS_PATH/Validation_alert.txt


#echo "Checking Pre-edit 10.236.134.164 connection"

preedit_sftp=`/apps/clearing/sshpass -p 'fvGnpaGKkCFjPh' sftp sftpedit@10.236.134.164 <<EOF
bye
EOF`

status=`echo $?`

if [ $status -eq 0 ]
then
        echo -e " * SFTP Prod Clearing to Pre-edit server Validation is Success\n">>$PROCESS_PATH/Validation_alert.txt
else
        echo -e " * FAILED - SFTP Prod Clearing to Pre-edit server Validation failed\n">>$PROCESS_PATH/Validation_alert.txt
fi

sleep 2


#echo "==============================================================================="
#echo "Checking Prod DN 10.236.134.71 connection"

dn_sftp=`/apps/clearing/sshpass -p 'LeV7SWPMygtGw2' sftp sftpdn@10.236.134.71 <<EOF
bye
EOF`

status=`echo $?`

if [ $status -eq 0 ]
then
        echo -e " * SFTP Clearing to Prod DN server Validation is Success\n">>$PROCESS_PATH/Validation_alert.txt
else
        echo -e " * FAILED - SFTP Clearing to Prod DN server Validation is failed\n">>$PROCESS_PATH/Validation_alert.txt

fi

sleep 3

#echo "==============================================================================="

#echo "Checking Clearing tskcmd services"

status=`tskcmd |wc -l`

if [ $status -eq 15 ]
then
        echo -e " * All $status Services are up in Clearing\n">>$PROCESS_PATH/Validation_alert.txt
else
        echo -e " * Warning - Only $status services running in Prod Clearing, expecting 15 Services.. Please check\n">>$PROCESS_PATH/Validation_alert.txt
fi

sleep 3

#echo "==============================================================================="

#echo "Checking GUI services"

status1=`ps -ef | grep "oassrv -b" | grep clrprod | grep -v "grep oassrv -b" |wc -l`

sleep 1

status2=`ps -ef | grep "oentsrv -b" | grep clrprod | grep -v "grep oentsrv -b" |wc -l`

if [ $status1 -eq 1 ] && [ $status2 -eq 1 ]
then
echo -e " * All GUI's Services running as expected on Prod Clearing Server\n" >>$PROCESS_PATH/Validation_alert.txt
else
echo -e " * All GUI's Services not running as expected on Prod Clearing Server\n" >>$PROCESS_PATH/Validation_alert.txt
fi
sleep 2

#echo "==============================================================================="

#echo "Checking Prepaid Connection"

cd $util

./checkprepaid_wotrmtn.bash

status=`echo $?`

if [ $status -eq 1 ]
then
sftp_conn=`sftp mpsmoveit@10.76.164.52 <<EOF
bye
EOF`

status1=`echo $?`
        if [ $status1 -eq 0 ]
        then
               echo -e " * Prepaid Server Connectivity Validated successfully\n">>$PROCESS_PATH/Validation_alert.txt
        else
               echo -e " * FAILED - Prepaid Server Connectivity Validation failed\n">>$PROCESS_PATH/Validation_alert.txt
        fi
else
                echo -e "\e[1;31m"" Some Other Users Logged in Prepaid.. Please Check ""\e[0m"
fi

#echo "==============================================================================="

#echo "Checking DX Connection"

DX_sftp=`sftp -i /apps/clearing/mpstomoveit i022604@10.102.242.16 <<EOF
bye
EOF`

status=`echo $?`

if [ $status -eq 0 ]
then
        echo -e " * SFTP Prod Clearing to DX server is Success.\n">>$PROCESS_PATH/Validation_alert.txt
else
		echo -e " * FAILED - SFTP Prod Clearing to DX server is failed.\n">>$PROCESS_PATH/Validation_alert.txt
fi

sleep 2

#echo "==============================================================================="

#echo "Checking Disk Usage for /Apps"

        disk_space=`df -h /apps/|tail -1 |awk '{print "Used--->"$4,"Available--->"$3}'`

        echo "Disk space $disk_space"

        used_disk=`df -h /apps/|tail -1 |awk '{print $4}' | sed "s/[^0-9]//g"`

if [ $used_disk -lt 85 ]
then
        echo -e " * Prod Clearing Disk Space is well in threshold.\n">>$PROCESS_PATH/Validation_alert.txt
else
		echo -e " * Warning: Clearing Used Disk Space is Critical $used_disk... Please clear old logs.\n">>$PROCESS_PATH/Validation_alert.txt
fi

sleep 2

#echo "==============================================================================="

#echo "Checking Database Connection"

cd $util
        ./check_bus_day.ksh

         err_file=`grep 'db_err_file' check_input.txt | grep -v '^#' | awk -F= '{print $2};'`
         err_file_size=`stat -c%s $err_file`

            if [ $err_file_size -eq 0 ]
        then
            echo -e " * Prod Clearing Database connectivity Verifited successfully.\n">>$PROCESS_PATH/Validation_alert.txt
        else
            echo -e " * Warning: Errors in Prod Clearing DB connection... Please check.\n">>$PROCESS_PATH/Validation_alert.txt
        fi
sleep 2

#echo "==============================================================================="

#echo "Checking FN connection"

 numFMConn=`mbportcmd list | grep -A1 FMFormatter | grep -v FMFormatter | grep connected | wc -l`
        if [ $numFMConn -eq 1 ]
        then
                echo -e " * FN Connecitvity Verified Successfully in Prod Clearing.\n">>$PROCESS_PATH/Validation_alert.txt
        else
                echo -e " * ERROR: No TCPIP Connection to FN from Prod Clearing- Result $numFMConn.\n">>$PROCESS_PATH/Validation_alert.txt
        fi
sleep 2

echo "==============================================================================="
#echo "Checking Prod Amex-OB 10.89.55.114 connection"

amexob_sftp=`/apps/clearing/sshpass -p 'Summer!25' sftp FISGLOBALPRD@10.89.55.114 <<EOF
bye
EOF`

status=`echo $?`

if [ $status -eq 0 ]
then
        echo -e " * SFTP Clearing to Prod Amex-OB server Successfully Validated.\n">>$PROCESS_PATH/Validation_alert.txt
else
        echo -e " * FAILED - SFTP Clearing to Prod Amex-OB Validation is Failed.\n">>$PROCESS_PATH/Validation_alert.txt

fi

sleep 2

echo "==============================================================================="

#echo "Checking Prod Amex-NOB 10.89.55.114 connection"

amexnob_sftp=`sftp -i /apps/clearing/mpssftpprod FISMPSPRD@10.89.55.114 <<EOF
bye
EOF`

status=`echo $?`

if [ $status -eq 0 ]
then
        echo -e " * SFTP Clearing to Prod Amex-NOB server Successfully Validated.\n">>$PROCESS_PATH/Validation_alert.txt
else
        echo -e " * FAILED - SFTP Clearing to Prod Amex-NOB Validation is Failed.\n">>$PROCESS_PATH/Validation_alert.txt

fi

sleep 2