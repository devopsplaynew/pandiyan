#!/bin/bash

scrub_path=/apps/clearing/STAGE_DIR/PCI/2-Jan-2019/data_scrub

args=$#

if [ $args -eq 1 ]
then
filename=$1
else
echo "please pass valid parameter"
exit 2
fi
echo $filename

file_check=`ls -lrt |grep $filename |wc -l`
if [ file_check == 1 ]
then
config=$(echo $filename | cut -c1-4)
echo $config
else
echo "no files or morethan one files in filename $filename"
exit 2
fi


if [ $config == TC57 ]
then
python dataScrubbingUtility.pyc dsconfig.txt tc57 $filename $filename.scrubbed
echo "python dataScrubbingUtility.pyc dsconfig.txt tc57 $filename $filename.scrubbed"
result=$?
if [ $result -eq 0 ]
then
echo "tc57 file $filename successfully scrubbed"
else
echo "tc57 file $filename failed to scrub"
fi

elif [ $config == FIS0 ]
then
python dataScrubbingUtility.pyc dsconfig.txt cdf $filename $filename.scrubbed
result=$?
if [ $result -eq 0 ]
then
echo "cdf file $filename successfully scrubbed"
else
echo "cdf file $filename failed to scrub"
fi

elif  [ $config == FISG ]
then
python dataScrubbingUtility.pyc dsconfig.txt gcf $filename $filename.scrubbed
echo "python dataScrubbingUtility.pyc dsconfig.txt gcf $filename $filename.scrubbed"
result=$?
if [ $result -eq 0 ]
then
echo "GCF file $filename successfully scrubbed"
else
echo "GCF file $filename failed to scrub"
fi

elif  [ $config == FIS_ ] || [ $config == FTP0 ] || [ $config == Mark ]
then 
python dataScrubbingUtility.pyc dsconfig.txt d256 $filename $filename.scrubbed
echo "python dataScrubbingUtility.pyc dsconfig.txt d256 $filename $filename.scrubbed"
result=$?
if [ $result -eq 0 ]
then
echo "D256 file $filename successfully scrubbed"
else
echo "D256 file $filename failed to scrub"
fi
else
echo "Please pass valid file name to scrub"
fi
