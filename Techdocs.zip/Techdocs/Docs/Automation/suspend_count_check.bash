#! /usr/bin/env bash
#########################################################################################
# Created by: Pandiyan Kuppan                                                           #
# Created on: 02 June 2019                                                               #
# Subject: Reports Count Check                                                #
#########################################################################################

Date=`date "+%m-%d-%Y"`
mail_date=`date "+%m/%d"`
currtime=`date "+%y-%m-%d %H:%M:%S"`
Reports_Path="$OSITE_ROOT/data/mps_daily_reports"
csv_temp="$OSITE_ROOT/data/mps_daily_reports/temp_csv"
Debug=/apps/clearing/util/suspend_check.log

report_val()
{
cd $Reports_Path
Clr_Reports_cnt=`ls -lrt MPS_DailyReports_CLR*$Date* | grep -v "\.Val\|\.csv" |grep -v 'CLRReject' | grep -v 'CLRReclass'|wc -l`

if [ $Clr_Reports_cnt -eq 3 ]
then
echo -e $currtime: "All 3 Clearing Reports Avaialbale for $Date" |tee -a $Debug
echo -e $currtime: "Starting CSV conversion" |tee -a $Debug

else
echo -e $currtime: "Clearing Reports not available for $Date"|tee -a $Debug
exit 2
fi
}

csv_conversion()
{
Clr_Reports=`ls -lrt MPS_DailyReports_CLR*$Date* | grep -v "\.Val\|\.csv" |grep -v 'CLRReject' | grep -v 'CLRReclass' |awk '{print $9}'`

echo -e "$Clr_Reports | tr [:space:] '\n'"
for i in $Clr_Reports
do
before_csv=`echo $i |sed 's/\.xlsx//'`

python /apps/clearing/util/Testing_Scripts/conv_excel2csv.py $before_csv
echo -e "Successfully converted csv file for $before_csv"
mv MPS_DailyReports_CLR*$Date*.csv $csv_temp
done
}

get_clrrpt_count()
{
cd $csv_temp
csv_reports=`ls -lrt MPS_DailyReports_CLR*$Date*.csv |awk '{print $9}'`
#csv_reports=`sed -i '1d' $csv_reports`
for files in $csv_reports
do
sed -i '1d' $files
rpt_name=$(echo $files | awk -F'[_]' '{print $3}'|sed 's/'$Date'//g'|sed 's/CLR//g')
row_count=`wc -l $files |awk '{print $1}'`
row_count=`expr $row_count - 1`
if [[ "$rpt_name" = "Suspend" ]]
then
echo -e $rpt_name "-" $row_count
awk -F , '{a[$13]++;}END{for (i in a)print i, a[i];}' $files
else
row_count=`wc -l $files |awk '{print $1}'`
row_count=`expr $row_count - 1`
echo -e $rpt_name "-" $row_count
fi
done
}

remov_csv_rpts()
{
echo -e $currtime: "removing csv Converted files from temp path"|tee -a $debug
cd $csv_temp
rm MPS_DailyReports_CLR*$Date*.csv
result=$?
echo $result
if [ $result -eq 0 ]
then
echo -e $currtime: "csv file successfully removed from temp path" |tee -a $debug
else
echo -e $currtime: "csv file failed to remove from temp path" |tee -a $debug
fi
exit 2
}


report_val
csv_conversion
get_clrrpt_count
remov_csv_rpts
