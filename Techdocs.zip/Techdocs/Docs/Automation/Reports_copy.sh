#! /usr/bin/env ksh

date="09-28-2018"
report_path=/apps/clearing/pdir20180927/ositeroot/data/mps_daily_reports
Zipped_reports=/apps/clearing/pdir20180927/ositeroot/data/mps_daily_reports/Zipped_reports


cd $report_path

Reports_count=`ls -lrt | grep -v ^d | grep "MPS_DailyReports_CLR" |grep $date |wc -l`                        
	=`ls -lrt | grep -v ^d | grep "MPS_DailyReports_CLR" |grep $date |tail -5`
				
echo "reports count is $Reports_count"
				
if [ $Reports_count -ge 5 ]
then
	cd $Zipped_reports
	mkdir DAR_Reports_$date

	cd $report_path
	cp $today_reports $Zipped_reports/DAR_Reports_$date
	cd $Zipped_reports
	zip -r DAR_Reports_$date.zip DAR_Reports_$date
	return 2
else
	echo "Report generation not completed"
	return 1
fi

