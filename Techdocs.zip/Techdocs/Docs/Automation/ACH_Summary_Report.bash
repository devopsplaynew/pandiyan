#! /usr/bin/env ksh
report_path=$OSITE_ROOT/data/jasper_reports/
date=`date +%d-%^b-%Y`
currtime=`date "+%y-%m-%d %H:%M:%S"`
dbug_file="/apps/mas/util/ACH_Summary.debug"
echo $currtime >>$dbug_file

echo "checking for mps_schcmd commands in background" >>$dbug_file

mpscmd=`ps -eaf | grep mps_schcmd | grep -v "tail\|grep mps_schcmd" | head -1`

if [[ -z "$mpscmd" ]]
then
echo "mps command check is completed" >>$dbug_file
else
echo "mps_schcmd commands are running in background.. Exiting">>$dbug_file
exit
fi


echo "Started ACH Summary Report" >>$dbug_file

mps_schcmd -aMAS -pexport -t407 -cNA

status=$?

if [ $status -eq 0 ]
then
cd $report_path
report_count=`ls -lrt |grep 'MPS_ACH_DailyDeposit' |grep $date |wc -l`
	if [ $report_count -ge 1 ]
	then
	echo "ACH Summary Report successfully generated in $report_path/" >>$dbug_file
	else
	echo "ACH Summary Report not generated in $report_path/">>$dbug_file
	exit 2
else
echo "ACH Summary Report failed to generated" $status>>$dbug_file
exit 2
fi

zena_result=$status
echo "$currtime $zena_result">>$dbug_file
exit $zena_result