#! /usr/bin/env ksh

Date=`date "+%m/%d"`
PROCESS_PATH=/tmp/test
date_today=`date "+%y%m%d"`
dis_date=`date "+%Y"%j`
MC_ARC="/data/MC/Outbound/ARC"

cd $MC_ARC
mc_out=`ls -lrth MPS.MCPROD.R111.C.E0084969.170331*|awk ' {print $9 " " $8 " " $5}'`

visa_out=`ls -lrth PRODMPS.VSOUT.472611.$date_today*|awk ' {print $9 " " $8 " " $5}'`

Dis_out=`ls -lrth PRD.FIS*.2018067*|awk ' {print $9 " " $8 " " $5}'`

