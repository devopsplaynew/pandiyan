#! /usr/bin/env bash
#########################################################################################
# Created by: Pandiyan Kuppan                                                           #
# Created on: 02 June 2019                                                               #
# Subject: Visa Confirmation Amount Mail                                                #
#########################################################################################

Date=`date "+%m/%d"`
Send_From=Pandiyan.Kuppan@fisglobal.com
Send_To=Pandiyan.Kuppan@fisglobal.com


Visa_Arc=/data/VISA/Outbound/ARC

Visa_date=`date "+%y%m%d"`
currtime=`date "+%y-%m-%d %H:%M:%S"`
util=/apps/clearing/util/
debug=/apps/clearing/util/visa_amount.txt
visa_mail=/apps/clearing/util/visa_mail.txt
tmp_path=/data/VISA/Outbound/ARC/temp_ascii/

Visa_files_Check()
{
cd $Visa_Arc
Visa_count=`ls -lrt PRODMPS.VSOUT.472611.$Visa_date*|wc -l`

if [ $Visa_count -ge 1 ]
then
echo -e "Hi Visa,\n" >/apps/clearing/util/visa_mail.txt
echo -e "FIS Sent below files to Visa On $Date.\n" >>/apps/clearing/util/visa_mail.txt
echo -e "BIN: 472611\n">>/apps/clearing/util/visa_mail.txt
echo $currtime: "Visa Outgoing files available for $Visa_date." |tee -a $debug
else
echo $currtime: "No Visa files avaiable for $Visa_date in $Visa_Arc path." |tee -a $debug
exit 2
fi
}

Visa_files_get()
{
cd $Visa_Arc
Visa_Files=`ls -lrt PRODMPS.VSOUT.472611.$Visa_date* |grep -v 'ascii' |awk '{print $9}'`
res=$?
echo $res
if [ $res -eq 0 ]
then
echo -e "$Visa_Files"| tr [:space:] '\n'
echo -e $currtime: "Visa Outgoing files are coverting to ASCII format." |tee -a $debug
else
echo -e $currtime: "No Visa files avaiable for $Visa_date in $Visa_Arc path." |tee -a $debug
exit 2
fi
}

Get_Visa_Fileid()
{
echo $currtime: "Checking Visa File ID." |tee -a $debug

for i in $Visa_Files

do
ascii_conv=`e2a $Visa_Arc/$i`
res1=$?
echo $res1
if [ $res1 -eq 0 ]
then
echo -e $currtime: "Visa File successfully Converted to ascii" |tee -a $debug
else
echo -e $currtime: "Found issue while conevert Visa file $i"|tee -a $debug
exit 2
fi

asci_file=`ls -lrt $i.ascii |awk '{print $9}'`

fileid=`cat $asci_file|cut -c79-101`

res=$?
echo $res
if [ $res -eq 0 ]
then
mv $asci_file $tmp_path
echo -e "File Name: $i " |tee -a /apps/clearing/util/visa_mail.txt
echo -e "File ID: $fileid \n" |tee -a /apps/clearing/util/visa_mail.txt

else
echo -e "error while Getting file ID for $i"
exit 2
fi
done

echo -e "\nCould  you please confirm the file from FIS/MPS are received and processed at Visa and Confirm the dollar amount of files processed?">>/apps/clearing/util/visa_mail.txt

echo -e "\n\nThanks & Regards" >>/apps/clearing/util/visa_mail.txt
echo -e "MPS Production Support" >>/apps/clearing/util/visa_mail.txt

(cat /apps/clearing/util/visa_mail.txt)|mailx -s "VISA Export Confirmation for $Date" -S smtp=Smtprelay.messageprovider.com -r "$Send_From" "$Send_To"
}

remov_visa_ascii()
{
echo -e "removing Visa Converted Ascii files from temp path"|tee -a $debug
cd $tmp_path
rm PRODMPS.VSOUT.472611.$Visa_date*.ascii
result=$?
echo $result

}
Visa_files_Check
Visa_files_get
Get_Visa_Fileid
remov_visa_ascii
