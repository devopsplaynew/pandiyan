#! /usr/bin/env ksh

PROCESS_PATH=/tmp/test
Send_From=pandiyan.kuppan@fisglobal.com
Send_To=pandiyan.kuppan@fisglobal.com
Send_To_Internal=pandiyan.kuppan@fisglobal.com
Date=`date -d '1 day ago' "+%m/%d"`
Visa_ARC="/data/VISA/Inbound/CHARGEBACK/ARC"
MC_ARC="/data/MC/Inbound/CHARGEBACK/ARC"
Dis_ARC="/data/Discover/Inbound/CHARGEBACK/ARC"
OCS_ARC="/apps/conv/clearing/pdir20180403/ositeroot/data/out/ocs/ARC"
visa_today=`date -d '1 day ago' "+%m%d%Y"`
mc_today=`date -d '1 day ago' "+%y%m%d"`
dis_today=`date -d '1 day ago' "+%d%m%y"`
ocs_today=`date "+%b %_d"`

cd $MC_ARC

inbmccbk_file_cnt=`ls -lrt | grep "\.T112\." | grep "$mc_today" | wc -l`

if [ $inbmccbk_file_cnt -ge 1 ]
then
                zenmc=1
else
                zenmc=0
fi

cd $Visa_ARC
inbvisacbk_file_cnt=`ls -lrt | grep "CHARGEBACK" | grep "$visa_today" | wc -l`

if [ $inbvisacbk_file_cnt -ge 1 ]
then
                zenvisa=1
else
                zenvisa=0
fi

cd $Dis_ARC
inbdiscbk_file_cnt=`ls -lrt | grep "DISPRSPN" | grep "$dis_today"  | wc -l`

if [ $inbdiscbk_file_cnt -ge 1 ]
then
                zendis=1
else
                zendis=0
fi

final_return="$zenmc$zenvisa$zendis"

cd $OCS_ARC

ocs_latest_file=`ls -lrt |grep "$ocs_today" |grep "ocs.DRC" |awk '{ print $5" " $6" " $7" " $8" " $9}'`
res=$?

if [ $res -eq 0 ] 
then

if [ $final_return -eq 111 ]

then
        echo -e "Hi Team,\n" >$PROCESS_PATH/cbk_Mesage.txt
        echo -e "Please find the below details for MC, Discover and VISA OCS Combined files created by MPS/Clearing for $Date\n" >>$PROCESS_PATH/cbk_Mesage.txt
        echo -e $ocs_latest_file >>$PROCESS_PATH/cbk_Mesage.txt
        echo -e "\n" >>$PROCESS_PATH/cbk_Mesage.txt
        echo -e "\nRegards" >>$PROCESS_PATH/cbk_Mesage.txt
        echo "MPS Operations Support" >>$PROCESS_PATH/cbk_Mesage.txt
                (cat $PROCESS_PATH/cbk_Mesage.txt)|mailx -s "MPS Chargeback activity: MC ,Visa and Discover Chargeback Combined OCS file for $Date" -S smtp=Smtprelay.messageprovider.com -r "$Send_From" "$Send_To"

elif [ $final_return -eq 110 ]
then

        echo -e "Hi Team,\n" >$PROCESS_PATH/cbk_Mesage.txt
        echo -e "Please find the below details for MC and VISA OCS Combined files created by MPS/Clearing for $Date\n" >>$PROCESS_PATH/cbk_Mesage.txt
        echo -e $ocs_latest_file >>$PROCESS_PATH/cbk_Mesage.txt
        echo -e "\n" >>$PROCESS_PATH/cbk_Mesage.txt
        echo -e "\nRegards" >>$PROCESS_PATH/cbk_Mesage.txt
        echo "MPS Operations Support" >>$PROCESS_PATH/cbk_Mesage.txt
                (cat $PROCESS_PATH/cbk_Mesage.txt)|mailx -s "MPS Chargeback activity: Visa and MC Chargeback Combined OCS file for $Date" -S smtp=Smtprelay.messageprovider.com -r "$Send_From" "$Send_To"

elif [ $final_return -eq 011 ]
then

        echo -e "Hi Team,\n" >$PROCESS_PATH/cbk_Mesage.txt
        echo -e "Please find the below details for Discover and VISA OCS Combined files created by MPS/Clearing for $Date\n" >>$PROCESS_PATH/cbk_Mesage.txt
        echo -e $ocs_latest_file >>$PROCESS_PATH/cbk_Mesage.txt
        echo -e "\n" >>$PROCESS_PATH/cbk_Mesage.txt
        echo -e "\nRegards" >>$PROCESS_PATH/cbk_Mesage.txt
        echo "MPS Operations Support" >>$PROCESS_PATH/cbk_Mesage.txt
        (cat $PROCESS_PATH/cbk_Mesage.txt)|mailx -s "MPS Chargeback activity: Visa and Discover Chargeback Combined OCS file for $Date" -S smtp=Smtprelay.messageprovider.com -r "$Send_From" "$Send_To"

elif [ $final_return -eq 000 ]
then

        echo -e "Hi Team,\n" >$PROCESS_PATH/cbk_Mesage.txt
        echo -e "No CBK files available in Chargeback processing Path for $Date\n" >>$PROCESS_PATH/cbk_Mesage.txt
                echo -e "Please Check Chargeback File processing path" >>$PROCESS_PATH/cbk_Mesage.txt
        echo -e "\n\nRegards" >>$PROCESS_PATH/cbk_Mesage.txt
        echo "MPS Operations Support" >>$PROCESS_PATH/cbk_Mesage.txt

      (cat $PROCESS_PATH/cbk_Mesage.txt)|mailx -s "No Chargeback files Available in Clearing Process path for $Date" -S smtp=Smtprelay.messageprovider.com -r "$Send_From" "$Send_To_Internal"

else
        echo -e "Hi Team,\n" >$PROCESS_PATH/cbk_Mesage.txt
        echo -e "CBK files Imports something went wrong in claring for $Date\n" >>$PROCESS_PATH/cbk_Mesage.txt
                echo -e "Please Check." >>$PROCESS_PATH/cbk_Mesage.txt
        echo -e "\n\nRegards" >>$PROCESS_PATH/cbk_Mesage.txt
        echo "MPS Operations Support" >>$PROCESS_PATH/cbk_Mesage.txt

                (cat $PROCESS_PATH/cbk_Mesage.txt)|mailx -s "Chargeback files import Failed for $Date" -S smtp=Smtprelay.messageprovider.com -r "$Send_From" "$Send_To_Internal"
fi

else
	echo -e "getting ocs file name failed"
fi