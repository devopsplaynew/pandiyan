#!/bin/ksh
#Explains read command

echo "What is your name?"
read NAME
echo "Hello ${NAME}"
