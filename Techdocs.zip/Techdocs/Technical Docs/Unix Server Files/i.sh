#!/bin/ksh
#explains Wildcards

for FILE in $@
do
	echo "current file: ${FILE}"
done
