#!/bin/ksh
#explains  Logging using flags


if [ $DEBUG ]
then
	set -x 
	echo "some thing"
	echo "something else"
	set +x
else
	echo "some thing"
	echo "something else"
fi
