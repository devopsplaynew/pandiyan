#!/bin/ksh
#Explain for loops


for COLOR in *
do
	echo "Current color is: ${COLOR}"
done

