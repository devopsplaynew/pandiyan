#!/bin/ksh
# Explains functions

print_hello(){
echo "Hello ${1}"
print_date
return 1
}

print_hello Vish
echo $?

print_date(){
echo "Today is the $(date +%dth)"
}

print_hello Akshay
echo $?
