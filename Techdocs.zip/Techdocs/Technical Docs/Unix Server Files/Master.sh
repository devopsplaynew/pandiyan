#! /bin/ksh 
#Script to explain the working of almost all the concepts we discussed.

TOTAL=$(cat EmployeeData.txt | wc -l)
touch EmployeeData.txt
chmod 777 EmployeeData.txt

start(){
clear
echo "==========================================="
echo "  Employee Database     HOME     Count=${TOTAL} "
echo "==========================================="
echo "   Choose your option: [1-5]               "
echo "   1. Add employee details                 "
echo "   2. View all employee details            "
echo "   3. View particular employee details.    "
echo "   4. Delete an employee from record.      "
echo "   5. Exit                                 "
echo "==========================================="
read CHOICE
controller
}

add_employee(){
clear
echo "==========================================="
echo "  Employee Database               Add Emp. "
echo "==========================================="
echo "   Enter name of Employee:             "
read EMPNAME
echo "   Enter employee ID:                  "
read EMPID
echo "   Enter age of Employee:              "
read EMPAGE
echo "   Enter salary (in INR):              "
read EMPSAL
echo "   Happy with details entered? [y or n]"
read DECISION

if [[ ${DECISION} = [yY] ]]
then
	CHECK=$(cat EmployeeData.txt |tr -s ' ' | cut -d' ' -f3 | grep -w ${EMPID})
	if [[ "${CHECK}" = "" ]]
	then
		echo "Processing employee details."
	else
		echo "Employee ID already exists."; sleep 3; add_employee
	fi
	echo " ${EMPNAME}  ${EMPID}     ${EMPAGE}      ${EMPSAL}" >> EmployeeData.txt
	sleep 1
	((TOTAL++))
	echo "Employee ${EMPNAME} added."
	sleep 2
	start
else
	echo "Enter b to go to home screen or n to enter to details again: [b or n]"
	read OPTION
	if [[ "${OPTION}" = [nN] ]]
	then
		add_employee
	elif [[ "${OPTION}" = [bB] ]]
	then
		start
	else
		echo "Invalid option. Going back to home screen..."
		sleep 3
		start
	fi
fi
}

view_all(){
clear
echo "==========================================="
echo "   Employee Database              View All "
echo "==========================================="
echo "  NAME    ID     AGE      SALARY         "
cat EmployeeData.txt
echo "Press any key to go back to home screen..." 
read DUMMY
start
}

view_single(){
clear
FOUND=0
echo "==========================================="
echo "   Employee Database            View Emp.  "
echo "==========================================="
while [[ ${FOUND} -eq 0 ]]
do
	echo "Enter the Emp ID you're looking for:" 
	read EMPNO
 	if [[ ${EMPNO} -lt 1000 || ${EMPNO} -gt 9999 ]]
	then
		echo "Please enter 4 digit Emp ID:"
		sleep 3
		view_single
	elif [[ "$(cat EmployeeData.txt |tr -s ' '| cut -d' ' -f3 | grep -w ${EMPNO})" != "" ]]
	then
		FOUND=1
		echo
		echo "Details for Emp with ID: ${EMPNO}"
		echo
		echo "  NAME    ID     AGE      SALARY         "
		cat EmployeeData.txt | grep -w ${EMPNO}
	else
		echo "Emp with ID ${EMPNO} does not exist."
		break
	fi
done
echo "Press any key to go back to home screen..." 
read DUMMY
start
}

remove_employee(){
clear
FOUND=0
echo "==========================================="
echo "   Employee Database          Remove Emp.  "
echo "==========================================="
while [[ ${FOUND} -eq 0 ]]
do
	echo "Enter the Emp ID you want to remove:" 
	read EMPNO
 	if [[ ${EMPNO} -lt 1000 || ${EMPNO} -gt 9999 ]]
	then
		echo "Please enter 4 digit Emp ID. Press any key to retry..."
		read DUMMY
		remove_employee
	elif [[ "$(cat EmployeeData.txt | tr -s ' ' | cut -d' ' -f3 | grep -w ${EMPNO})" != "" ]]
	then
		FOUND=1
		echo
		echo "Details for Emp with ID: ${EMPNO}"
		echo
		echo "  NAME    ID     AGE      SALARY         "
		cat EmployeeData.txt | grep -w ${EMPNO}
		echo
		echo "Press any key to remove emp..." 
		read DUMMY
		LINE=$(cat EmployeeData.txt | tr -s ' ' | cut -d' ' -f3 | grep -wn ${EMPNO} |cut -d':' -f1)
		sed ${LINE}d EmployeeData.txt > NewEmp.txt
		if [ $? -eq 0 ]
		then
			cp EmployeeData.txt EmployeeData_bkp.txt
			mv NewEmp.txt EmployeeData.txt
			chmod 777 EmployeeData.txt
		fi
	else
		echo "Emp with ID ${EMPNO} does not exist."
		break
	fi
done
echo "Press any key to go back to home screen..." 
read DUMMY
start
}

exit_prompt(){
echo "Are you sure you want to exit? [y or n]:"
read CONFIRM
if [[ ${CONFIRM} = [yY] || "${CONFIRM}" = [yY][eE][sS] ]]
then
	echo "Thank you.. Bye!"
	sleep 5
	exit 0
else
	start
fi
}

controller(){
case ${CHOICE} in
1) add_employee
   ;;
2) view_all
   ;;
3) view_single
   ;;
4) remove_employee
   ;;
5) exit_prompt
   ;;
*) start
   ;;
esac
}

start
