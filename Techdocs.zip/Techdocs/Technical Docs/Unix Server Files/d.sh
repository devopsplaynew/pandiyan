#!/bin/ksh
#This script explains elif

a=3

if [ $a -eq 2 ]
then
	echo Value is 2.
elif [ $a -eq 3 ]
then
	echo Value is 3.
else
	echo Value is not 2 or 3.
fi
