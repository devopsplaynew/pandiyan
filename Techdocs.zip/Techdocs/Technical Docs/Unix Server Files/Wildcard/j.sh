#!/bin/ksh
#explains while

i=1
while read A B C
do
	echo "${i}:${A}"
	((i++))
done < ../Master.sh
