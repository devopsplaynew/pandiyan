#!/bin/ksh
#Explains arguments

for ARG in $@
do
	echo ${ARG}
done
exit 22
