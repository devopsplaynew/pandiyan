#! /bin/ksh
#This script explains ps

sleep 90 &

