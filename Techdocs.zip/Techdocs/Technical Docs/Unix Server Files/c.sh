#! /bin/ksh -xv
#This script explains ps

echo "value of a is ${a}"
