#! /bin/ksh
#This script explains local scope of variable

print(){
echo "this is a sample function."
a="abc"
local b=2
}

print

echo "Value of a is ${a}"
echo "Value of b is ${b}"
