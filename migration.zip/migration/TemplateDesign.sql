create or replace package TemplateDesignPkg as

	TYPE C_CUR is REF CURSOR;
	
	
	procedure pGetTemplateDetails(transrec in out txnrec,RetCur out C_CUR);
	procedure pGetTemplateApproval(transrec in out txnrec,RetCur out C_CUR);	
	procedure pGetLetterViewMgt(transrec in out txnrec,RetCur out C_CUR);
	procedure pGetLetterManageProd(transrec in out txnrec,RetCur out C_CUR);	
	procedure pGetLetterManageTemp(transrec in out txnrec,RetCur out C_CUR);
	procedure pGetLetterManageTempType(transrec in out txnrec,RetCur out C_CUR);	
	procedure pGetProductsEffect(transrec in out txnrec,RetCur out C_CUR);

	procedure pGetTemplateRD(transrec in out txnrec,RetCur out C_CUR);
	
	procedure getTemplateReplaceData(v_Product in varchar2,v_Cin in varchar2,v_tempid in varchar2,RetCur out C_CUR);	
	
end TemplateDesignPkg;
/

create or replace package body TemplateDesignPkg as


	
	
	 procedure pGetTemplateDetails(transrec in out txnrec, RetCur out C_CUR) is
              
		i_retval				number:=0;
		i_Cnt					number:=0;
		FnFlag 				number:=0;
		FLDERR					exception;
		ErrRec 				ErrorStatus%rowtype;
		ErrorMsg				varchar2(4000):=null;

		v_CardNo             	       varchar2(4000):=null;
		v_CardType				varchar2(4000):=null;
		v_CardStatus				varchar2(4000):=null;
		v_CardStatus1				varchar2(4000):=null;
		v_CardStatus2				varchar2(4000):=null;
		v_producttype					varchar2(4000):=null;

		v_TransCode				varchar2(4000):=null;
		v_maker_id				varchar2(4000):=null;
		v_Count				number:=0;

              v_BrnEntity                varchar2(4000):=null;  
              v_BrnUser_type             varchar2(4000):=null;
			  v_maxcrlt        varchar2(4000):=null;
			  v_mincrlt        varchar2(4000):=null;
			  v_maxcalt         varchar2(4000):=null;
			   v_mincalt        varchar2(4000):=null;
			  v_maxtelt        varchar2(4000):=null;
			  v_mintelt         varchar2(4000):=null;
			   v_pcrlt        varchar2(4000):=null;
			  v_pcalt        varchar2(4000):=null;
			  v_ptelt         varchar2(4000):=null;
			  v_LimitUsageCode    varchar2(4000):=null;
			  
			  v_templateid   varchar2(4000):=null;
			  v_Desc   varchar2(4000):=null;
			  v_prd  varchar2(4000):=null;
			  v_temptype  varchar2(4000):=null;

	begin
		-- Parsing the string
		transrec.ErrorData := 'Before parsing....';
		transrec.TRANS_CODE:=CreditUtilPkg.GetStrField(transrec.InOutData,'TRANS_CODE',i_retval);
		transrec.DATETIME:=CreditUtilPkg.GetStrField(transrec.InOutData,'DATETIME',i_retval);
		transrec.NET_ID:=CreditUtilPkg.GetStrField(transrec.InOutData,'NET_ID',i_retval);
		transrec.IDCT_ID:=CreditUtilPkg.GetStrField(transrec.InOutData,'IDCT_ID',i_retval);
		
		ErrRec.TransCode:=transrec.TRANS_CODE;
		ErrRec.IdctTime:=transrec.DATETIME;
		ErrRec.NetId:=transrec.NET_ID;
		ErrRec.IdctId:=transrec.IDCT_ID;
	
		transrec.IDCT_ERR_CODE :='20';
		transrec.IDCT_MESSAGE_TYPE:='02';
		transrec.ErrorData:='Removing header ........';
		transrec.InOutData:=substr(transrec.InOutData,instr(transrec.InOutData,'IDCT_MESSAGE_TYPE')+22);
		transrec.ErrorData := 'preparing data.....';
              v_TransCode:=transrec.TRANS_CODE;
		v_maker_id:=transrec.NET_ID;

				if(v_TransCode='TEMPDE') then
	             			v_templateid:=UPPER(CreditUtilPkg.GetStrField(transrec.InOutData,'F8001',i_retval)); 
				 	v_Desc:=UPPER(CreditUtilPkg.GetStrField(transrec.InOutData,'F8002',i_retval));
					v_prd:=UPPER(CreditUtilPkg.GetStrField(transrec.InOutData,'F8003',i_retval)); 
				 	v_temptype:=UPPER(CreditUtilPkg.GetStrField(transrec.InOutData,'F8004',i_retval)); 				 
				 
				 select count(*) into i_Cnt from LETTER_TEMPLETE_MASTER  where TEMPLETE_ID=v_templateid and REC_STATUS in('I','P');

				if(i_Cnt!=0) then
					transrec.ErrorData:='Template ID already exists';
       	     	       			transrec.IDCT_ERR_CODE:='TEMEXT';
              	     			raise FLDERR; 
				end if;
				 
	           
			   
				Open RetCur for  select  'F8001'||lpad(nvl(length(v_templateid),0),3,'0')||v_templateid||
						'F8002'||lpad(nvl(length(v_Desc),0),3,'0')||v_Desc||
						'F8003'||lpad(nvl(length(v_prd),0),3,'0')||v_prd||
						'F8004'||lpad(nvl(length(v_temptype),0),3,'0')||v_temptype||
						'F8005'||lpad(nvl(length(PARAMETER_KEY),0),3,'0')||PARAMETER_KEY
						FROM LETTER_PARAMETER where temp_id=substr(v_temptype,0,instr(v_temptype,'-')-1) and DISP_FIELD='D' order by PARAMETER_KEY; 
				end if;	

				if(v_TransCode='TEMPGN') then
	            			v_templateid:=UPPER(CreditUtilPkg.GetStrField(transrec.InOutData,'F8001',i_retval)); 
				 	v_Desc:=UPPER(CreditUtilPkg.GetStrField(transrec.InOutData,'F8002',i_retval));
					v_prd:=UPPER(CreditUtilPkg.GetStrField(transrec.InOutData,'F8003',i_retval)); 
				 	v_temptype:=UPPER(CreditUtilPkg.GetStrField(transrec.InOutData,'F8004',i_retval)); 		
	           
				Open RetCur for  select  'F8001'||lpad(nvl(length(v_templateid),0),3,'0')||v_templateid||
						'F8002'||lpad(nvl(length(v_Desc),0),3,'0')||v_Desc||
						'F8003'||lpad(nvl(length(v_prd),0),3,'0')||v_prd||
						'F8004'||lpad(nvl(length(v_temptype),0),3,'0')||v_temptype
						FROM DUAL; 
					
				insert into LETTER_TEMPLETE_MASTER(TEMPLETE_ID,DESCRIPTION,FILE_FORMAT,REC_STATUS,PRD_CODE,TEMPLETE_TYPE,MAKER_ID,MAKER_DTTM) values(v_templateid,v_Desc,'pdf','P',substr(v_prd,0,instr(v_prd,'-')-1),substr(v_temptype,0,instr(v_temptype,'-')-1),v_maker_id,sysdate);commit;
				end if;	


			if(v_TransCode='TEMPVW') then
	             		v_templateid:=UPPER(CreditUtilPkg.GetStrField(transrec.InOutData,'F8001',i_retval)); 
				 v_Desc:=UPPER(CreditUtilPkg.GetStrField(transrec.InOutData,'F8002',i_retval)); 
				 
	           
				Open RetCur for  select  'F8001'||lpad(nvl(length(v_templateid),0),3,'0')||v_templateid||
						'F8002'||lpad(nvl(length(v_Desc),0),3,'0')||v_Desc
						FROM DUAL; 
						
					end if;	
			if(v_TransCode='TEMPAU') then
	             		v_templateid:=UPPER(CreditUtilPkg.GetStrField(transrec.InOutData,'F8001',i_retval)); 
				v_Desc:=UPPER(CreditUtilPkg.GetStrField(transrec.InOutData,'F8002',i_retval)); 
				 
	           
				Open RetCur for  select  'F8001'||lpad(nvl(length(v_templateid),0),3,'0')||v_templateid||
						'F8002'||lpad(nvl(length(v_Desc),0),3,'0')||v_Desc
						FROM DUAL; 
						
					end if;		
			if(v_TransCode='TEMPAA') then
	             		v_templateid:=UPPER(CreditUtilPkg.GetStrField(transrec.InOutData,'F8001',i_retval)); 
				v_Desc:=UPPER(CreditUtilPkg.GetStrField(transrec.InOutData,'F8002',i_retval)); 
				 
	           
				Open RetCur for  select  'F8001'||lpad(nvl(length(v_templateid),0),3,'0')||v_templateid||
						'F8002'||lpad(nvl(length(v_Desc),0),3,'0')||v_Desc
						FROM DUAL; 
						
				update LETTER_TEMPLETE_MASTER set REC_STATUS=v_Desc where TEMPLETE_ID=v_templateid;commit;
						
					end if;								
				

        
		transrec.ErrorData:='Success';
		transrec.InOutData:='|3|IDCT_STATUS=XML_PROCESSED|IDCT_ERR_CODE=NO_DATA|IDCT_MESSAGE_TYPE=02|';
		transrec.InOutCode:=0;
		return;
               
		exception
		when FLDERR then
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-1;
			transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE='||transrec.IDCT_ERR_CODE||'|IDCT_MESSAGE_TYPE=02|';
			return;
		when NO_DATA_FOUND then
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-2;
			transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE='||transrec.IDCT_ERR_CODE||'|IDCT_MESSAGE_TYPE=02|';
			return;
		when others then
			transrec.IDCT_ERR_CODE:='03';
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-3;
                        transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE=03|IDCT_MESSAGE_TYPE=02|';
			return;

	end pGetTemplateDetails;

procedure pGetTemplateApproval(transrec in out txnrec, RetCur out C_CUR) is
              
		i_retval				number:=0;
		i_Cnt					number:=0;
		FnFlag 				number:=0;
		FLDERR					exception;
		ErrRec 				ErrorStatus%rowtype;
		ErrorMsg				varchar2(4000):=null;
 
		v_TemplateID                    varchar2(4000):=null;
		v_Description					varchar2(4000):=null;

	begin
		-- Parsing the string
		transrec.ErrorData := 'Before parsing....';
		transrec.TRANS_CODE:=CreditUtilPkg.GetStrField(transrec.InOutData,'TRANS_CODE',i_retval);
		transrec.DATETIME:=CreditUtilPkg.GetStrField(transrec.InOutData,'DATETIME',i_retval);
		transrec.NET_ID:=CreditUtilPkg.GetStrField(transrec.InOutData,'NET_ID',i_retval);
		transrec.IDCT_ID:=CreditUtilPkg.GetStrField(transrec.InOutData,'IDCT_ID',i_retval);
		
		ErrRec.TransCode:=transrec.TRANS_CODE;
		ErrRec.IdctTime:=transrec.DATETIME;
		ErrRec.NetId:=transrec.NET_ID;
		ErrRec.IdctId:=transrec.IDCT_ID;
	
		transrec.IDCT_ERR_CODE :='20';
		transrec.IDCT_MESSAGE_TYPE:='02';
		transrec.ErrorData:='Removing header ........';
		transrec.InOutData:=substr(transrec.InOutData,instr(transrec.InOutData,'IDCT_MESSAGE_TYPE')+22);
		transrec.ErrorData := 'preparing data.....';
    
		 v_TemplateID:=CreditUtilPkg.GetStrField(transrec.InOutData,'F0001',i_retval); 
	     v_Description:=CreditUtilPkg.GetStrField(transrec.InOutData,'F0002',i_retval); 
		 
		 
		 select count(*) into i_Cnt from LETTER_TEMPLETE_MASTER where REC_STATUS='P';
		 
		 if(i_Cnt=0) then
				transrec.ErrorData:='No Records Found';
       	     	       transrec.IDCT_ERR_CODE:='INA';
              	     	raise FLDERR; 
		end if;
		               			
			Open RetCur for select 		
					'F0001'||lpad(nvl(length(ltm.TEMPLETE_ID),0),3,'0')||ltm.TEMPLETE_ID||
					'F0002'||lpad(nvl(length(ltm.DESCRIPTION),0),3,'0')||ltm.DESCRIPTION||
					'F0005'||lpad(nvl(length((select pm.PRD_NAME from PRODUCT_MASTER pm where pm.PRD_CODE=ltm.PRD_CODE)),0),3,'0')||(select pm.PRD_NAME from PRODUCT_MASTER pm where pm.PRD_CODE=ltm.PRD_CODE)||
					'F0006'||lpad(nvl(length((select TEMP_NAME from LETTER_MASTER where TEMP_ID=ltm.TEMPLETE_TYPE)),0),3,'0')||(select TEMP_NAME from LETTER_MASTER where TEMP_ID=ltm.TEMPLETE_TYPE)
	
from LETTER_TEMPLETE_MASTER ltm where ltm.REC_STATUS='P'; 
				
		transrec.ErrorData:='Success';
		transrec.InOutData:='|3|IDCT_STATUS=XML_PROCESSED|IDCT_ERR_CODE=NO_DATA|IDCT_MESSAGE_TYPE=02|';
		transrec.InOutCode:=0;
		return;
               
		exception
		when FLDERR then
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-1;
			transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE='||transrec.IDCT_ERR_CODE||'|IDCT_MESSAGE_TYPE=02|';
			return;
		when NO_DATA_FOUND then
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-2;
			transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE='||transrec.IDCT_ERR_CODE||'|IDCT_MESSAGE_TYPE=02|';
			return;
		when others then
			transrec.IDCT_ERR_CODE:='03';
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-3;
                        transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE=03|IDCT_MESSAGE_TYPE=02|';
			return;

	end pGetTemplateApproval;
	
	 procedure pGetLetterViewMgt(transrec in out txnrec, RetCur out C_CUR) is
              
		i_retval				number:=0;
		i_Cnt					number:=0;
		FnFlag 				number:=0;
		FLDERR					exception;
		ErrRec 				ErrorStatus%rowtype;
		ErrorMsg				varchar2(4000):=null;
 
		v_TemplateID                    varchar2(4000):=null;
	begin
		-- Parsing the string
		transrec.ErrorData := 'Before parsing....';
		transrec.TRANS_CODE:=CreditUtilPkg.GetStrField(transrec.InOutData,'TRANS_CODE',i_retval);
		transrec.DATETIME:=CreditUtilPkg.GetStrField(transrec.InOutData,'DATETIME',i_retval);
		transrec.NET_ID:=CreditUtilPkg.GetStrField(transrec.InOutData,'NET_ID',i_retval);
		transrec.IDCT_ID:=CreditUtilPkg.GetStrField(transrec.InOutData,'IDCT_ID',i_retval);
		
		ErrRec.TransCode:=transrec.TRANS_CODE;
		ErrRec.IdctTime:=transrec.DATETIME;
		ErrRec.NetId:=transrec.NET_ID;
		ErrRec.IdctId:=transrec.IDCT_ID;
	
		transrec.IDCT_ERR_CODE :='20';
		transrec.IDCT_MESSAGE_TYPE:='02';
		transrec.ErrorData:='Removing header ........';
		transrec.InOutData:=substr(transrec.InOutData,instr(transrec.InOutData,'IDCT_MESSAGE_TYPE')+22);
		transrec.ErrorData := 'preparing data.....';
    
		 v_TemplateID:=CreditUtilPkg.GetStrField(transrec.InOutData,'F0001',i_retval);  
		 
		 select count(*) into i_Cnt from LETTER_TEMPLETE_MASTER where REC_STATUS='I';
		 
		 if(i_Cnt=0) then
				transrec.ErrorData:='No Records Found';
       	     	       transrec.IDCT_ERR_CODE:='INA';
              	     	raise FLDERR; 
		end if;

		
		               			
			Open RetCur for select 
								'F0001'||lpad(nvl(length(TEMPLETE_ID||'-'||DESCRIPTION),0),3,'0')||TEMPLETE_ID||'-'||DESCRIPTION from LETTER_TEMPLETE_MASTER  where REC_STATUS='I'; 
		transrec.ErrorData:='Success';
		transrec.InOutData:='|3|IDCT_STATUS=XML_PROCESSED|IDCT_ERR_CODE=NO_DATA|IDCT_MESSAGE_TYPE=02|';
		transrec.InOutCode:=0;
		return;
               
		exception
		when FLDERR then
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-1;
			transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE='||transrec.IDCT_ERR_CODE||'|IDCT_MESSAGE_TYPE=02|';
			return;
		when NO_DATA_FOUND then
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-2;
			transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE='||transrec.IDCT_ERR_CODE||'|IDCT_MESSAGE_TYPE=02|';
			return;
		when others then
			transrec.IDCT_ERR_CODE:='03';
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-3;
                        transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE=03|IDCT_MESSAGE_TYPE=02|';
			return;

	end pGetLetterViewMgt;
	
	
	procedure pGetLetterManageProd(transrec in out txnrec, RetCur out C_CUR) is
              
		i_retval				number:=0;
		i_Cnt					number:=0;
		FnFlag 				    number:=0;
		FLDERR					exception;
		ErrRec 				ErrorStatus%rowtype;
		ErrorMsg				varchar2(4000):=null;
 
		v_productname                   varchar2(4000):=null;
		v_Templateid					varchar2(4000):=null;
        v_PRD_CODE                      varchar2(4000):=null;
	begin
		-- Parsing the string
		transrec.ErrorData := 'Before parsing....';
		transrec.TRANS_CODE:=CreditUtilPkg.GetStrField(transrec.InOutData,'TRANS_CODE',i_retval);
		transrec.DATETIME:=CreditUtilPkg.GetStrField(transrec.InOutData,'DATETIME',i_retval);
		transrec.NET_ID:=CreditUtilPkg.GetStrField(transrec.InOutData,'NET_ID',i_retval);
		transrec.IDCT_ID:=CreditUtilPkg.GetStrField(transrec.InOutData,'IDCT_ID',i_retval);
		
		ErrRec.TransCode:=transrec.TRANS_CODE;
		ErrRec.IdctTime:=transrec.DATETIME;
		ErrRec.NetId:=transrec.NET_ID;
		ErrRec.IdctId:=transrec.IDCT_ID;
	
		transrec.IDCT_ERR_CODE :='20';
		transrec.IDCT_MESSAGE_TYPE:='02';
		transrec.ErrorData:='Removing header ........';
		transrec.InOutData:=substr(transrec.InOutData,instr(transrec.InOutData,'IDCT_MESSAGE_TYPE')+22);
		transrec.ErrorData := 'preparing data.....';
    
		    v_productname:=CreditUtilPkg.GetStrField(transrec.InOutData,'F0001',i_retval); 
			v_PRD_CODE:=CreditUtilPkg.GetStrField(transrec.InOutData,'F0001',i_retval);
			v_Templateid:=CreditUtilPkg.GetStrField(transrec.InOutData,'F0002',i_retval); 
		               			
								
			Open RetCur for select 	
								  'F0001'||lpad(nvl(length(PRD_CODE||'-'||PRD_NAME),0),3,'0')||PRD_CODE||'-'||PRD_NAME from PRODUCT_MASTER order by PRD_CODE; 
		                       -- ||lpad(nvl(length(PRD_CODE),0),3,'0')||PRD_CODE from PRODUCT_MASTER;   
		    	
		transrec.ErrorData:='Success';
		transrec.InOutData:='|3|IDCT_STATUS=XML_PROCESSED|IDCT_ERR_CODE=NO_DATA|IDCT_MESSAGE_TYPE=02|';
		transrec.InOutCode:=0;
		return;
               
		exception
		when FLDERR then
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-1;
			transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE='||transrec.IDCT_ERR_CODE||'|IDCT_MESSAGE_TYPE=02|';
			return;
		when NO_DATA_FOUND then
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-2;
			transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE='||transrec.IDCT_ERR_CODE||'|IDCT_MESSAGE_TYPE=02|';
			return;
		when others then
			transrec.IDCT_ERR_CODE:='03';
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-3;
                        transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE=03|IDCT_MESSAGE_TYPE=02|';
			return;

	end pGetLetterManageProd;
	
procedure pGetLetterManageTemp(transrec in out txnrec, RetCur out C_CUR) is
              
		i_retval				number:=0;
		i_Cnt					number:=0;
		FnFlag 				    number:=0;
		FLDERR					exception;
		ErrRec 				ErrorStatus%rowtype;
		ErrorMsg				varchar2(4000):=null;
 
		v_productname                   varchar2(4000):=null;
		v_Templateid					varchar2(4000):=null;

	begin
		-- Parsing the string
		transrec.ErrorData := 'Before parsing....';
		transrec.TRANS_CODE:=CreditUtilPkg.GetStrField(transrec.InOutData,'TRANS_CODE',i_retval);
		transrec.DATETIME:=CreditUtilPkg.GetStrField(transrec.InOutData,'DATETIME',i_retval);
		transrec.NET_ID:=CreditUtilPkg.GetStrField(transrec.InOutData,'NET_ID',i_retval);
		transrec.IDCT_ID:=CreditUtilPkg.GetStrField(transrec.InOutData,'IDCT_ID',i_retval);
		
		ErrRec.TransCode:=transrec.TRANS_CODE;
		ErrRec.IdctTime:=transrec.DATETIME;
		ErrRec.NetId:=transrec.NET_ID;
		ErrRec.IdctId:=transrec.IDCT_ID;
	
		transrec.IDCT_ERR_CODE :='20';
		transrec.IDCT_MESSAGE_TYPE:='02';
		transrec.ErrorData:='Removing header ........';
		transrec.InOutData:=substr(transrec.InOutData,instr(transrec.InOutData,'IDCT_MESSAGE_TYPE')+22);
		transrec.ErrorData := 'preparing data.....';
    
		 v_productname:=CreditUtilPkg.GetStrField(transrec.InOutData,'F0001',i_retval); 
			v_Templateid:=CreditUtilPkg.GetStrField(transrec.InOutData,'F0002',i_retval); 
		               			
			
			select count(*) into i_Cnt from LETTER_TEMPLETE_MASTER where REC_STATUS='I';
		 
			if(i_Cnt=0) then
				transrec.ErrorData:='No Records Found';
       	     	       transrec.IDCT_ERR_CODE:='INA';
              	     	raise FLDERR; 
			end if;
			
		    Open RetCur for select 		
								  'F0002'||lpad(nvl(length(TEMPLETE_ID),0),3,'0')||TEMPLETE_ID from LETTER_TEMPLETE_MASTER where REC_STATUS='I'; 
				
		transrec.ErrorData:='Success';
		transrec.InOutData:='|3|IDCT_STATUS=XML_PROCESSED|IDCT_ERR_CODE=NO_DATA|IDCT_MESSAGE_TYPE=02|';
		transrec.InOutCode:=0;
		return;
               
		exception
		when FLDERR then
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-1;
			transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE='||transrec.IDCT_ERR_CODE||'|IDCT_MESSAGE_TYPE=02|';
			return;
		when NO_DATA_FOUND then
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-2;
			transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE='||transrec.IDCT_ERR_CODE||'|IDCT_MESSAGE_TYPE=02|';
			return;
		when others then
			transrec.IDCT_ERR_CODE:='03';
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-3;
                        transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE=03|IDCT_MESSAGE_TYPE=02|';
			return;

	end pGetLetterManageTemp;
	
	
	
procedure pGetLetterManageTempType(transrec in out txnrec, RetCur out C_CUR) is
              
		i_retval				number:=0;
		i_Cnt					number:=0;
		FnFlag 				    number:=0;
		FLDERR					exception;
		ErrRec 				ErrorStatus%rowtype;
		ErrorMsg				varchar2(4000):=null;
 
		v_productname                   varchar2(4000):=null;
		v_Templateid					varchar2(4000):=null;

	begin
		-- Parsing the string
		transrec.ErrorData := 'Before parsing....';
		transrec.TRANS_CODE:=CreditUtilPkg.GetStrField(transrec.InOutData,'TRANS_CODE',i_retval);
		transrec.DATETIME:=CreditUtilPkg.GetStrField(transrec.InOutData,'DATETIME',i_retval);
		transrec.NET_ID:=CreditUtilPkg.GetStrField(transrec.InOutData,'NET_ID',i_retval);
		transrec.IDCT_ID:=CreditUtilPkg.GetStrField(transrec.InOutData,'IDCT_ID',i_retval);
		
		ErrRec.TransCode:=transrec.TRANS_CODE;
		ErrRec.IdctTime:=transrec.DATETIME;
		ErrRec.NetId:=transrec.NET_ID;
		ErrRec.IdctId:=transrec.IDCT_ID;
	
		transrec.IDCT_ERR_CODE :='20';
		transrec.IDCT_MESSAGE_TYPE:='02';
		transrec.ErrorData:='Removing header ........';
		transrec.InOutData:=substr(transrec.InOutData,instr(transrec.InOutData,'IDCT_MESSAGE_TYPE')+22);
		transrec.ErrorData := 'preparing data.....';
    
		 v_productname:=CreditUtilPkg.GetStrField(transrec.InOutData,'F0001',i_retval); 
			v_Templateid:=CreditUtilPkg.GetStrField(transrec.InOutData,'F0002',i_retval); 
		               			
			
			select count(*) into i_Cnt from LETTER_MASTER;
		 
			if(i_Cnt=0) then
				transrec.ErrorData:='No Records Found';
       	     	       transrec.IDCT_ERR_CODE:='INA';
              	     	raise FLDERR; 
			end if;
			if transrec.TRANS_CODE='TEMPL0' then
			 Open RetCur for select 		
								  'F0001'||lpad(nvl(length(TEMP_ID||'-'||TEMP_NAME),0),3,'0')||TEMP_ID||'-'||TEMP_NAME from LETTER_MASTER where DISP_FIELD='D' order by TEMP_ID; 
			else
		    Open RetCur for select 		
								  'F0002'||lpad(nvl(length(TEMP_ID||'-'||TEMP_NAME),0),3,'0')||TEMP_ID||'-'||TEMP_NAME from LETTER_MASTER where DISP_FIELD='D' order by TEMP_ID; 
			end if;
				
		transrec.ErrorData:='Success';
		transrec.InOutData:='|3|IDCT_STATUS=XML_PROCESSED|IDCT_ERR_CODE=NO_DATA|IDCT_MESSAGE_TYPE=02|';
		transrec.InOutCode:=0;
		return;
               
		exception
		when FLDERR then
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-1;
			transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE='||transrec.IDCT_ERR_CODE||'|IDCT_MESSAGE_TYPE=02|';
			return;
		when NO_DATA_FOUND then
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-2;
			transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE='||transrec.IDCT_ERR_CODE||'|IDCT_MESSAGE_TYPE=02|';
			return;
		when others then
			transrec.IDCT_ERR_CODE:='03';
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-3;
                        transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE=03|IDCT_MESSAGE_TYPE=02|';
			return;

	end pGetLetterManageTempType;	
	
	
	procedure pGetProductsEffect(transrec in out txnrec,RetCur out C_CUR) is

		blockStatus             number(2):=0;
		FnFlag                  number(2):=0;
		FLDERR                  EXCEPTION;
		ErrRec                  ErrorStatus%rowtype;

		-- variables for transactions
		v_trans_code            varchar2(50):=null;
		v_maker_id              varchar2(50):=null;
		v_user_id               varchar2(50):=null;
		v_prd_code              varchar2(50):=null;

		i_cnt                   number(5):=0;
		i_count		     	number:=0;
		i_retval	     	number:=0;

		--variables
		v_TemplateType		varchar2(4000):=null;
		v_prdcode		varchar2(4000):=null;
		
		v_frdate		varchar2(4000):=null;
		v_todate		varchar2(4000):=null;
		v_reqtype		varchar2(40):=null;	
		v_req			varchar2(40):=null;	
	begin

                -- Parsing the String
                transrec.ErrorData:='Before parsing ....';
                transrec.TRANS_CODE:=CreditUtilPkg.GetStrField(transrec.InOutData,'TRANS_CODE',blockStatus);
                transrec.DATETIME:=CreditUtilPkg.GetStrField(transrec.InOutData,'DATETIME',blockStatus);
                transrec.NET_ID:=CreditUtilPkg.GetStrField(transrec.InOutData,'NET_ID',blockStatus);
                transrec.IDCT_ID:=CreditUtilPkg.GetStrField(transrec.InOutData,'IDCT_ID',blockStatus);

                ErrRec.TransCode:=transrec.TRANS_CODE;
                ErrRec.IdctTime:=transrec.DATETIME;
                ErrRec.NetId:=transrec.NET_ID;
                ErrRec.IdctId:=transrec.IDCT_ID;

                transrec.IDCT_ERR_CODE:='20';
                transrec.IDCT_MESSAGE_TYPE:='02';

		  transrec.ErrorData:='removing header ....';
                transrec.InOutData:=substr(transrec.InOutData,instr(transrec.InOutData,'IDCT_MESSAGE_TYPE')+22);

                v_trans_code:=''||transrec.TRANS_CODE||'';
                v_maker_id:=''||transrec.NET_ID||'';
		if transrec.TRANS_CODE='TEMPLG' then 
		v_TemplateType:=upper(CreditUtilPkg.GetStrField(transrec.InOutData,'F0001',i_retval)); 
		v_prdcode:=CreditUtilPkg.GetStrField(transrec.InOutData,'F0002',i_retval); 
		v_reqtype:=upper(CreditUtilPkg.GetStrField(transrec.InOutData,'F0003',i_retval)); 
		v_frdate:=CreditUtilPkg.GetStrField(transrec.InOutData,'F0004',i_retval); 
		v_todate:=CreditUtilPkg.GetStrField(transrec.InOutData,'F0005',i_retval); 
		
				
				if v_TemplateType='100-CARDISSUANCE' then 
					if(v_reqtype='GENERATE') then
						SELECT count(*) into i_count  FROM  CUSTOMER_MASTER cust,CARD_MASTER cm,CARD_ACCOUNT_MASTER cam,CARDACCT_CARD_LINK cl
								WHERE cust.CIN=cm.CIN and
								cm.CARD_NO=cl.CARD_NO and
								cl.CARD_ACCT=cam.CARD_ACCT AND										
								cust.FILE_ID=v_prdcode and cm.CARD_STATUS='I' and cust.LETTER_GEN_FLG is null; 

						
							if i_count=0 then
								transrec.ErrorData:='No Records available';
								transrec.IDCT_ERR_CODE:='17';
								raise FLDERR;
							end if;
						
						
						open RetCur for SELECT 
						'F1001'||lpad(nvl(length(replace((cust.F_NAME||' '||cust.m_name||' '||cust.l_name),'  ',' ')),0),3,'0')||replace((cust.F_NAME||' '||cust.m_name||' '||cust.l_name),'  ',' ')||
						'F1002'||lpad(nvl(length(cm.CARD_NO),0),3,'0')||cm.CARD_NO||
						'F1003'||lpad(nvl(length(cust.DOB),0),3,'0')||cust.DOB||
						'F1004'||lpad(nvl(length(cm.cin),0),3,'0')||cm.cin||
						'F1005'||lpad(nvl(length(decode(cam.noh,'1','P','A')),0),3,'0')||decode(cam.noh,'1','P','A')||
						'F1006'||lpad(nvl(length(decode(cm.product_type,'PLTCST','CUSTOMER','PLTSTF','STAFF','GLDCST','CUSTOMER','GLDSTF','STAFF','CLACST','CUSTOMER','CLASTF','STAFF','CLABHA','CUSTOMER','VISCRD','CORPORATE','CUSTOMER')),0),3,'0')||decode(cm.product_type,'PLTCST','CUSTOMER','PLTSTF','STAFF','GLDCST','CUSTOMER','GLDSTF','STAFF','CLACST','CUSTOMER','CLASTF','STAFF','CLABHA','CUSTOMER','VISCRD','CORPORATE','CUSTOMER')
						FROM  CUSTOMER_MASTER cust,CARD_MASTER cm,CARD_ACCOUNT_MASTER cam,CARDACCT_CARD_LINK cl
												WHERE cust.CIN=cm.CIN and
												cm.CARD_NO=cl.CARD_NO and
												cl.CARD_ACCT=cam.CARD_ACCT AND
												cust.FILE_ID=v_prdcode and cm.CARD_STATUS='I' and cust.LETTER_GEN_FLG is null;								
				 else								
						SELECT count(*) into i_count  FROM  CUSTOMER_MASTER cust,CARD_MASTER cm,CARD_ACCOUNT_MASTER cam,CARDACCT_CARD_LINK cl
								WHERE cust.CIN=cm.CIN and
								cm.CARD_NO=cl.CARD_NO and
								cl.CARD_ACCT=cam.CARD_ACCT AND										
								cust.FILE_ID=v_prdcode and cm.CARD_STATUS='I'; 

						
							if i_count=0 then
								transrec.ErrorData:='No Records available';
								transrec.IDCT_ERR_CODE:='17';
								raise FLDERR;
							end if;
						
						
						open RetCur for SELECT 
						'F1001'||lpad(nvl(length(replace((cust.F_NAME||' '||cust.m_name||' '||cust.l_name),'  ',' ')),0),3,'0')||replace((cust.F_NAME||' '||cust.m_name||' '||cust.l_name),'  ',' ')||
						'F1002'||lpad(nvl(length(cm.CARD_NO),0),3,'0')||cm.CARD_NO||
						'F1003'||lpad(nvl(length(cust.DOB),0),3,'0')||cust.DOB||
						'F1004'||lpad(nvl(length(cm.cin),0),3,'0')||cm.cin||
						'F1005'||lpad(nvl(length(decode(cam.noh,'1','P','A')),0),3,'0')||decode(cam.noh,'1','P','A')||
						'F1006'||lpad(nvl(length(decode(cm.product_type,'PLTCST','CUSTOMER','PLTSTF','STAFF','GLDCST','CUSTOMER','GLDSTF','STAFF','CLACST','CUSTOMER','CLASTF','STAFF','CLABHA','CUSTOMER','VISCRD','CORPORATE','CUSTOMER')),0),3,'0')||decode(cm.product_type,'PLTCST','CUSTOMER','PLTSTF','STAFF','GLDCST','CUSTOMER','GLDSTF','STAFF','CLACST','CUSTOMER','CLASTF','STAFF','CLABHA','CUSTOMER','VISCRD','CORPORATE','CUSTOMER')
						FROM  CUSTOMER_MASTER cust,CARD_MASTER cm,CARD_ACCOUNT_MASTER cam,CARDACCT_CARD_LINK cl
												WHERE cust.CIN=cm.CIN and
												cm.CARD_NO=cl.CARD_NO and
												cl.CARD_ACCT=cam.CARD_ACCT AND
												cust.FILE_ID=v_prdcode and cm.CARD_STATUS='I';								
				end if;								
			end if;							
		else
			
		v_TemplateType:=CreditUtilPkg.GetStrField(transrec.InOutData,'F0008',i_retval); 
               
			if v_TemplateType='99-DEFAULTWELCOME' then
			
				open RetCur for 
					SELECT distinct 'F0180'||lpad(nvl(length(PRD_CODE||'-'||PRD_NAME),0),3,'0')||PRD_CODE||'-'||PRD_NAME
					FROM PRODUCT_MASTER;
			
			else
			
				--SELECT count(*) into i_count  FROM LETTER_TEMPLETE_MASTER where TEMPLETE_TYPE=substr(v_TemplateType,0,instr(v_TemplateType,'-')-1);
				  select count(*) into i_count from product_master;	
					--select count(*) into i_count from customer_master_wk where FILE_ID is not null;
					if i_count=0 then
						transrec.ErrorData:='No Records available';
						transrec.IDCT_ERR_CODE:='17';
						raise FLDERR;
					end if;

				open RetCur for 
				SELECT distinct 'F0180'||lpad(nvl(length((prd_code||'-'||prd_name)),0),3,'0')||(prd_code||'-'||prd_name)
				FROM product_master order by prd_code;
				
				/*open RetCur for 
				SELECT distinct 'F0180'||lpad(nvl(length(FILE_ID),0),3,'0')||FILE_ID
				FROM CUSTOMER_MASTER_WK WHERE FILE_ID IS NOT NULL;*/
				
		    end if;   
       
	    end if;      


                transrec.ErrorData:='Success';
                transrec.InOutData:='|3|IDCT_STATUS=XML_PROCESSED|IDCT_ERR_CODE=NO_DATA|IDCT_MESSAGE_TYPE=02|';
                transrec.InOutCode:=0;
                return;

        exception
                when FLDERR then
                        rollback;
                        transrec.OraError:=substr(SQLERRM,1,100);
                        transrec.OraCode:=SQLCODE;
                        insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
                        transrec.InOutCode:=-1;
                        transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE='||transrec.IDCT_ERR_CODE||'|IDCT_MESSAGE_TYPE=02|';
                        return;
                when NO_DATA_FOUND then
                        rollback;
                        transrec.OraError:=substr(SQLERRM,1,100);
                        transrec.OraCode:=SQLCODE;
                        insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
                        transrec.InOutCode:=-2;
                        transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE='||transrec.IDCT_ERR_CODE||'|IDCT_MESSAGE_TYPE=02|';
                        return;
                        transrec.IDCT_ERR_CODE:='03';
                        rollback;
                        transrec.OraError:=substr(SQLERRM,1,100);
                        transrec.OraCode:=SQLCODE;
                        insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
                        transrec.InOutCode:=-3;
                        transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE=03|IDCT_MESSAGE_TYPE=02|';
                        return;

end pGetProductsEffect; 


procedure getTemplateReplaceData(v_Product in varchar2,v_Cin in varchar2,v_tempid in varchar2,RetCur out C_CUR) is
		
	v_address       varchar2(4000):=null;
	
	v_ResAddress  	varchar2(4000):=null;
	v_PerAddress  	varchar2(4000):=null;
	v_raddress  	varchar2(4000):=null;
	v_rcity  		varchar2(4000):=null;
	v_rdistrict  	varchar2(4000):=null;
	v_rstate  		varchar2(4000):=null;
	v_rpin  		varchar2(4000):=null;
	v_rmobile  	varchar2(4000):=null;
	v_rlandmark  	varchar2(4000):=null;
	v_rtel1  		varchar2(4000):=null;
	v_rtel2  		varchar2(4000):=null;
	v_paddress  	varchar2(4000):=null;
	v_pcity  		varchar2(4000):=null;
	v_pdistrict  	varchar2(4000):=null;
	v_pstate  		varchar2(4000):=null;
	v_ppin  		varchar2(4000):=null;
	v_pmobile  	varchar2(4000):=null;
	v_plandmark  	varchar2(4000):=null;
	v_ptel1  		varchar2(4000):=null;
	v_ptel2  		varchar2(4000):=null;
	v_cnt			number:=0;
	v_cnts			number:=0;
	
	begin
	

	select 
		NVL(substr(cust.address,instr(cust.address,'|',1,1)+1,instr(cust.address,'|',1,2)-instr(cust.address,'|',1,1)-1),'NO_DATA')  , 
		NVL(substr(cust.address,instr(cust.address,'R'),instr(cust.address,'R')-instr(cust.address,'R')+1 ),'NO_DATA') , 
		NVL(substr(cust.address,4,instr(cust.address,'~')-4),'NO_DATA')  , 
		
		NVL(substr(cust.address,instr(cust.address,'~',1,1)+1,instr(cust.address,'~',1,2)-instr(cust.address,'~',1,1)-1),'NO_DATA') , 
		NVL(substr(cust.address,instr(cust.address,'~',1,2)+1,instr(cust.address,'~',1,3)-instr(cust.address,'~',1,2)-1),'NO_DATA') , 
		NVL(substr(cust.address,instr(cust.address,'~',1,3)+1,instr(cust.address,'~',1,4)-instr(cust.address,'~',1,3)-1),'NO_DATA') , 
		NVL(substr(cust.address,instr(cust.address,'~',1,4)+1,instr(cust.address,'~',1,5)-instr(cust.address,'~',1,4)-1),'NO_DATA') , 
		
		
		NVL(substr(cust.address,instr(cust.address,'~',1,5)+1,instr(cust.address,'~',1,6)-instr(cust.address,'~',1,5)-1),'NO_DATA') , 
		NVL(substr(cust.address,instr(cust.address,'~',1,6)+1,instr(cust.address,'~',1,7)-instr(cust.address,'~',1,6)-1),'NO_DATA') , 
		NVL(substr(cust.address,instr(cust.address,'~',1,7)+1,instr(cust.address,'~',1,8)-instr(cust.address,'~',1,7)-1),'NO_DATA') , 		
		NVL(substr(cust.address,instr(cust.address,'|',1,2)+1,instr(cust.address,'|',1,3)-instr(cust.address,'|',1,2)-1),'NO_DATA'),		
		
		nvl(substr(cust.address,instr(cust.address,'|R|')+3, instr(cust.address,'~',instr(cust.address,'|R|')+3)-instr(cust.address,'|R|')-3),'NO_DATA') ,			
		NVL(substr(cust.address,instr(cust.address,'~',1,9)+1,instr(cust.address,'~',1,10)-instr(cust.address,'~',1,9)-1),'NO_DATA') , 
		NVL(substr(cust.address,instr(cust.address,'~',1,10)+1,instr(cust.address,'~',1,11)-instr(cust.address,'~',1,10)-1),'NO_DATA') , 		
		NVL(substr(cust.address,instr(cust.address,'~',1,11)+1,instr(cust.address,'~',1,12)-instr(cust.address,'~',1,11)-1),'NO_DATA') ,
		
		
		NVL(substr(cust.address,instr(cust.address,'~',1,12)+1,instr(cust.address,'~',1,13)-instr(cust.address,'~',1,12)-1),'NO_DATA') , 
		NVL(substr(cust.address,instr(cust.address,'~',1,13)+1,instr(cust.address,'~',1,14)-instr(cust.address,'~',1,13)-1),'NO_DATA') , 
		NVL(substr(cust.address,instr(cust.address,'~',1,14)+1,instr(cust.address,'~',1,15)-instr(cust.address,'~',1,14)-1),'NO_DATA') , 
		NVL(substr(cust.address,instr(cust.address,'~',1,15)+1,instr(cust.address,'~',1,16)-instr(cust.address,'~',1,15)-1),'NO_DATA') , 		
		NVL(substr(cust.address,instr(cust.address,'~',1,16)+1),'NO_DATA')
		
		into v_ResAddress,v_PerAddress,v_raddress,
		v_rcity,v_rdistrict,v_rstate,v_rpin,
		v_rmobile,v_rlandmark,v_rtel1,v_rtel2,
		v_paddress,v_pcity,v_pdistrict,v_pstate,
		v_ppin,v_pmobile,v_plandmark,v_ptel1,v_ptel2		
		from CUSTOMER_MASTER_WK cust where cust.cin=v_Cin;
	
	
	
	select    '<P>'||v_raddress||'</P>'
			||'<P>'||v_rcity||'</P>'
			||'<P>'||v_rdistrict||'</P>'
			||'<P>'||v_rstate||'</P>'
			||'<P>'||v_rpin||'</P>' into v_address from dual;
			
	-- for Welcome Letter
			
	if v_tempid='100' then
	
	
	
	select 	count(*) into v_cnt
	from PRODUCT_MASTER P,CARD_MASTER_WK C,CUSTOMER_MASTER CM,CR_LMT_TXN CLT 
	where P.PRD_CODE=v_Product and
	P.PRD_CODE=C.PRODUCT_TYPE and 
	CLT.REFNO=C.ACC_NO and 
	C.CIN=CM.CIN and 
	CM.CIN=v_Cin;

	if v_cnt=0 then
	
	Open RetCur for 
	select 	'No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available'
	from DUAL;	
	
	else
	
	Open RetCur for 
	
	select 	CM.F_NAME,CM.APP_NO,P.PRD_NAME,CLT.CREDIT_LIMIT,CLT.CASH_LIMIT,CLT.TE_LIMIT,C.CARD_NO,v_address,CM.CUSTOMER_ID,nvl(CM.MOBILE_NO,' '),nvl(CM.EMAIL_ID,' ')
	from PRODUCT_MASTER P,CARD_MASTER_WK C,CUSTOMER_MASTER CM,CR_LMT_TXN CLT 
	where P.PRD_CODE=v_Product and
	P.PRD_CODE=C.PRODUCT_TYPE and 
	CLT.REFNO=C.ACC_NO and 
	C.CIN=CM.CIN and 
	CM.CIN=v_Cin;
	
	insert into LETTER_GENERATION(TEMPLETE_ID,PRD_CODE,CARD_NO,CHECKER_ID,CHECKER_DTTM,MAKER_ID,MAKER_DTTM) values(v_tempid,v_Product,(select card_no from card_master where cin=v_Cin),'ABCDEF',sysdate,'ABCDEF',sysdate);commit; 
	
	end if;
	
	
		
	end if;
	
	
	-- for Reject Letter
	
if v_tempid='103' then



	SELECT count(*) into v_cnt FROM CUSTOMER_MASTER_WK  where CIN=v_Cin;

	if  v_cnt=0 then 
		Open RetCur for 
		SELECT 'No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available' FROM DUAL;
	else
		Open RetCur for
		SELECT F_NAME,to_char(DOB,'dd-MON-yyyy'),nvl(MOBILE_NO,' '),nvl(EMAIL_ID,' '),v_address,APP_NO,CIN FROM CUSTOMER_MASTER_WK  where CIN=v_Cin ;
		
	end if;

end if;

if v_tempid='107' then

select count(*) into v_cnt
FROM PRODUCT_MASTER P,CARD_MASTER cm,CUSTOMER_MASTER stm ,CUST_PAY_TB cpt,CUST_PAY_MASTER cpm 
		where cm.cin=stm.cin 
		and P.PRD_CODE=cm.PRODUCT_TYPE
		and cm.CARD_NO=cpt.CARD_NO
		and cm.PRODUCT_TYPE=v_Product		
		and cpt.REFNO=cpm.REFNO 
		and cm.CARD_STATUS='I' and cpm.STATUS_FLG='B' and cm.CIN=v_Cin;
		
if  v_cnt=0 then 
Open RetCur for 
		SELECT 'No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available',
		'No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available'
		FROM DUAL;

else

	Open RetCur for
	select stm.F_NAME,cm.CARD_NO,cm.ACC_NO,P.PRD_NAME,nvl(stm.MOBILE_NO,' '),nvl(stm.EMAIL_ID,' '),
	(select um.USER_NAME from user_id_mapping uim,user_master um where uim.system_user_id=um.user_id and uim.login_user_id=cm.BR_ID),
	v_address,stm.CUSTOMER_ID,cpm.bank_name,cpm.BOUNCE_DESC,cpm.CHQ_NO,to_char(cpm.BOUNCE_DT,'dd-MON-yyyy'),cpm.PAY_AMT
	
	FROM PRODUCT_MASTER P,CARD_MASTER cm,CUSTOMER_MASTER stm ,CUST_PAY_TB cpt,CUST_PAY_MASTER cpm 
		where cm.cin=stm.cin 
        and P.PRD_CODE=cm.PRODUCT_TYPE
		and cm.CARD_NO=cpt.CARD_NO
		and cm.PRODUCT_TYPE=v_Product		
		and cpt.REFNO=cpm.REFNO 
		and cm.CARD_STATUS='I' and cpm.STATUS_FLG='B' and cm.CIN=v_Cin;

end if;

end if;



if v_tempid='102' then



	SELECT count(*) into v_cnt FROM CUSTOMER_MASTER_WK  where CIN=v_Cin;

	if  v_cnt=0 then 
		Open RetCur for 
		SELECT 'No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available' FROM DUAL;
	else
		Open RetCur for
		SELECT F_NAME,nvl(MOBILE_NO,' '),nvl(EMAIL_ID,' '),
		--(select um.USER_NAME from user_id_mapping uim,user_master um where uim.system_user_id=um.user_id and um.user_id=(select SYSTEM_USER_ID from user_id_mapping where LOGIN_USER_ID=MAKER_ID)),
		v_address,nvl(CUSTOMER_ID,' '),APP_NO,to_char(DOB,'dd-MON-yyyy') FROM CUSTOMER_MASTER_WK  where CIN=v_Cin ;
		
	end if;

end if;





if v_tempid='111' then

select count(*) into v_cnt
FROM PRODUCT_MASTER P,CARD_MASTER cm,CUSTOMER_MASTER stm ,CUSTOMER_REQUEST crq
		where cm.cin=stm.cin 
		and cm.CARD_NO=crq.CARD_NO 
		and P.PRD_CODE=cm.PRODUCT_TYPE
		and cm.PRODUCT_TYPE=v_Product 
		and cm.cin=v_Cin;
		
if  v_cnt=0 then 
Open RetCur for 
		SELECT 'No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available',
		'No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available'
		FROM DUAL;

else

	Open RetCur for
	select stm.F_NAME,cm.CARD_NO,cm.ACC_NO,P.PRD_NAME,nvl(stm.MOBILE_NO,' '),nvl(stm.EMAIL_ID,' '),
	(select um.USER_NAME from user_id_mapping uim,user_master um where uim.system_user_id=um.user_id and uim.login_user_id=cm.BR_ID),
	v_address,stm.CUSTOMER_ID,crq.TXN_AMOUNT,crq.REQUEST_DATE_TIME,crq.REF_NO
	
	FROM PRODUCT_MASTER P,CARD_MASTER cm,CUSTOMER_MASTER stm ,CUSTOMER_REQUEST crq
		where cm.cin=stm.cin 
		and cm.CARD_NO=crq.CARD_NO 
		and P.PRD_CODE=cm.PRODUCT_TYPE
		and cm.PRODUCT_TYPE=v_Product 
		and cm.cin=v_Cin;

end if;

end if;


	
	-- for All 
	
	if v_tempid='101'  or v_tempid='104' or v_tempid='105'  then
	
	
	select count(*) into v_cnt
	from PRODUCT_MASTER P,CARD_MASTER C,CUSTOMER_MASTER CM,CARD_ACCOUNT_MASTER CAM,CR_LMT_TXN CLT 
	where P.PRD_CODE=v_Product and
	P.PRD_CODE=C.PRODUCT_TYPE and 
	CAM.CARD_ACCT=C.ACC_NO and
	CLT.REFNO=C.CARD_NO and 
	C.CIN=CM.CIN and 
	CM.CIN=v_Cin and 
	C.CARD_STATUS='I'; 
	
	if v_cnt=0 then
	
	Open RetCur for
	select 	'No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available',
			'No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available'
	from DUAL;	
	
	else
	                                          
	select count(*) into v_cnts from STMT_TBL ST,CARD_MASTER C where ST.CARD_NO=C.CARD_NO and C.CIN=v_Cin and ST.BILL_DATE=(select max(STA.BILL_DATE) from STMT_TBL STA,CARD_MASTER C where STA.CARD_NO=C.CARD_NO and C.CIN=v_Cin);
	
	if v_cnts=0 then
	
	Open RetCur for
	select CM.F_NAME,C.CARD_NO,C.ACC_NO,P.PRD_NAME,nvl(CM.MOBILE_NO,' '),nvl(CM.EMAIL_ID,' '),
	(select um.USER_NAME from user_id_mapping uim,user_master um where uim.system_user_id=um.user_id and uim.login_user_id=C.BR_ID),
	to_char(C.V_THRU_DT,'dd-MON-yyyy'),
	CAM.DEL_COUNT,CLT.CREDIT_LIMIT,CLT.CASH_LIMIT,CLT.TE_LIMIT,
	'Statement Not At Generated','Statement Not At Generated',
	v_address,CM.CUSTOMER_ID,decode(C.PRIM_FLAG,'Y','Primary','N','Supplementary','Primary'),CM.APP_NO,to_char(CM.DOB,'dd-MON-yyyy')
	from PRODUCT_MASTER P,CARD_MASTER C,CUSTOMER_MASTER CM,CARD_ACCOUNT_MASTER CAM,CR_LMT_TXN CLT 
	where P.PRD_CODE=v_Product and
	P.PRD_CODE=C.PRODUCT_TYPE and 
	CAM.CARD_ACCT=C.ACC_NO and 
	CLT.REFNO=C.CARD_NO and 
	C.CIN=CM.CIN and 
	CM.CIN=v_Cin and  
	C.CARD_STATUS='I';
	
	
	else
	
	
	Open RetCur for
	select CM.F_NAME,C.CARD_NO,C.ACC_NO,P.PRD_NAME,nvl(CM.MOBILE_NO,' '),nvl(CM.EMAIL_ID,' '),
	(select um.USER_NAME from user_id_mapping uim,user_master um where uim.system_user_id=um.user_id and uim.login_user_id=C.BR_ID),
	to_char(C.V_THRU_DT,'dd-MON-yyyy'),
	CAM.DEL_COUNT,CLT.CREDIT_LIMIT,CLT.CASH_LIMIT,CLT.TE_LIMIT,
	(select nvl(ST.OUTSTANDING,0) from STMT_TBL ST where ST.CARD_NO=C.CARD_NO and ST.BILL_DATE=(select max(STA.BILL_DATE) from STMT_TBL STA where STA.CARD_NO=C.CARD_NO )),
	(select nvl(ST.MIN_DUE,0) from STMT_TBL ST where ST.CARD_NO=C.CARD_NO and ST.BILL_DATE=(select max(STA.BILL_DATE) from STMT_TBL STA where STA.CARD_NO=C.CARD_NO )),
	v_address,CM.CUSTOMER_ID,decode(C.PRIM_FLAG,'Y','Primary','N','Supplementary','Primary'),CM.APP_NO,to_char(CM.DOB,'dd-MON-yyyy')
	from PRODUCT_MASTER P,CARD_MASTER C,CUSTOMER_MASTER CM,CARD_ACCOUNT_MASTER CAM,CR_LMT_TXN CLT 
	where P.PRD_CODE=v_Product and
	P.PRD_CODE=C.PRODUCT_TYPE and 
	CAM.CARD_ACCT=C.ACC_NO and 
	CLT.REFNO=C.CARD_NO and 
	C.CIN=CM.CIN and 
	CM.CIN=v_Cin and 
	C.CARD_STATUS='I';
	
	end if;
	
	insert into LETTER_GENERATION(TEMPLETE_ID,PRD_CODE,CARD_NO,CHECKER_ID,CHECKER_DTTM,MAKER_ID,MAKER_DTTM) values(v_tempid,v_Product,(select card_no from card_master where cin=v_Cin),'ABCDEF',sysdate,'ABCDEF',sysdate);commit; 
	commit;
	
	
  end if;
	
end if;




if v_tempid='106' or v_tempid='108' or v_tempid='109' or v_tempid='110' then
	
	
	select count(*) into v_cnt
	from PRODUCT_MASTER P,CARD_MASTER C,CUSTOMER_MASTER CM,CARD_ACCOUNT_MASTER CAM,CR_LMT_TXN CLT 
	where P.PRD_CODE=v_Product and
	P.PRD_CODE=C.PRODUCT_TYPE and 
	CAM.CARD_ACCT=C.ACC_NO and
	CLT.REFNO=C.CARD_NO and 
	C.CIN=CM.CIN and 
	CM.CIN=v_Cin and 
	C.CARD_STATUS='I'; 
	
	if v_cnt=0 then
	
	Open RetCur for
	select 	'No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available',
			'No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available','No Record Available'
	from DUAL;	
	
	else
	                                          
	select count(*) into v_cnts from STMT_TBL ST,CARD_MASTER C where ST.CARD_NO=C.CARD_NO and C.CIN=v_Cin and ST.BILL_DATE=(select max(STA.BILL_DATE) from STMT_TBL STA,CARD_MASTER C where STA.CARD_NO=C.CARD_NO and C.CIN=v_Cin);
	
	if v_cnts=0 then
	
	Open RetCur for
	select CM.F_NAME,C.CARD_NO,C.ACC_NO,P.PRD_NAME,nvl(CM.MOBILE_NO,' '),nvl(CM.EMAIL_ID,' '),
	(select um.USER_NAME from user_id_mapping uim,user_master um where uim.system_user_id=um.user_id and uim.login_user_id=C.BR_ID),
	to_char(C.V_THRU_DT,'dd-MON-yyyy'),
	CAM.DEL_COUNT,CLT.CREDIT_LIMIT,CLT.CASH_LIMIT,CLT.TE_LIMIT,
	'Statement Not At Generated','Statement Not At Generated',
	v_address,CM.CUSTOMER_ID,decode(C.PRIM_FLAG,'Y','Primary','N','Supplementary','Primary'),CM.APP_NO,to_char(CM.DOB,'dd-MON-yyyy'),ABS(CAM.CARD_ACCT_BAL+CLT.CREDIT_LIMIT)
	from PRODUCT_MASTER P,CARD_MASTER C,CUSTOMER_MASTER CM,CARD_ACCOUNT_MASTER CAM,CR_LMT_TXN CLT 
	where P.PRD_CODE=v_Product and
	P.PRD_CODE=C.PRODUCT_TYPE and 
	CAM.CARD_ACCT=C.ACC_NO and 
	CLT.REFNO=C.CARD_NO and 
	C.CIN=CM.CIN and 
	CM.CIN=v_Cin and  
	C.CARD_STATUS='I';
	
	
	else
	
	
	Open RetCur for
	select CM.F_NAME,C.CARD_NO,C.ACC_NO,P.PRD_NAME,nvl(CM.MOBILE_NO,' '),nvl(CM.EMAIL_ID,' '),
	(select um.USER_NAME from user_id_mapping uim,user_master um where uim.system_user_id=um.user_id and uim.login_user_id=C.BR_ID),
	to_char(C.V_THRU_DT,'dd-MON-yyyy'),
	CAM.DEL_COUNT,CLT.CREDIT_LIMIT,CLT.CASH_LIMIT,CLT.TE_LIMIT,
	(select nvl(ST.OUTSTANDING,0) from STMT_TBL ST where ST.CARD_NO=C.CARD_NO and ST.BILL_DATE=(select max(STA.BILL_DATE) from STMT_TBL STA where STA.CARD_NO=C.CARD_NO )),
	(select nvl(ST.MIN_DUE,0) from STMT_TBL ST where ST.CARD_NO=C.CARD_NO and ST.BILL_DATE=(select max(STA.BILL_DATE) from STMT_TBL STA where STA.CARD_NO=C.CARD_NO )),
	v_address,CM.CUSTOMER_ID,decode(C.PRIM_FLAG,'Y','Primary','N','Supplementary','Primary'),CM.APP_NO,to_char(CM.DOB,'dd-MON-yyyy'),ABS(CAM.CARD_ACCT_BAL+CLT.CREDIT_LIMIT)
	from PRODUCT_MASTER P,CARD_MASTER C,CUSTOMER_MASTER CM,CARD_ACCOUNT_MASTER CAM,CR_LMT_TXN CLT 
	where P.PRD_CODE=v_Product and
	P.PRD_CODE=C.PRODUCT_TYPE and 
	CAM.CARD_ACCT=C.ACC_NO and 
	CLT.REFNO=C.CARD_NO and 
	C.CIN=CM.CIN and 
	CM.CIN=v_Cin and 
	C.CARD_STATUS='I';
	
	end if;
	
	insert into LETTER_GENERATION(TEMPLETE_ID,PRD_CODE,CARD_NO,CHECKER_ID,CHECKER_DTTM,MAKER_ID,MAKER_DTTM) values(v_tempid,v_Product,(select card_no from card_master where cin=v_Cin),'ABCDEF',sysdate,'ABCDEF',sysdate);commit; 
	commit;
	
	
  end if;
	
end if;






	

	end getTemplateReplaceData;
	
	

	
	 procedure pGetTemplateRD(transrec in out txnrec, RetCur out C_CUR) is
              
		i_retval				number:=0;
		i_Cnt					number:=0;
		FnFlag 				number:=0;
		FLDERR					exception;
		ErrRec 				ErrorStatus%rowtype;
		ErrorMsg				varchar2(4000):=null;

		v_CardNo             	       varchar2(4000):=null;
		v_CardType				varchar2(4000):=null;
		v_CardStatus				varchar2(4000):=null;
		v_CardStatus1				varchar2(4000):=null;
		v_CardStatus2				varchar2(4000):=null;
		v_producttype					varchar2(4000):=null;

		v_TransCode				varchar2(4000):=null;
		v_maker_id				varchar2(4000):=null;
		v_Count				number:=0;

		v_BrnEntity                varchar2(4000):=null;  
		v_BrnUser_type             varchar2(4000):=null;
		v_maxcrlt        varchar2(4000):=null;
		v_mincrlt        varchar2(4000):=null;
		v_maxcalt         varchar2(4000):=null;
		v_mincalt        varchar2(4000):=null;
		v_maxtelt        varchar2(4000):=null;
		v_mintelt         varchar2(4000):=null;
		v_pcrlt        varchar2(4000):=null;
		v_pcalt        varchar2(4000):=null;
		v_ptelt         varchar2(4000):=null;
		v_LimitUsageCode    varchar2(4000):=null;

		v_Cin   varchar2(4000):=null;
		v_Product  varchar2(4000):=null;
		v_tempid  varchar2(4000):=null;
			  
			  
		v_address       varchar2(4000):=null;
			  

		v_ResAddress  	varchar2(4000):=null;
		v_PerAddress  	varchar2(4000):=null;
		v_raddress  	varchar2(4000):=null;
		v_rcity  		varchar2(4000):=null;
		v_rdistrict  	varchar2(4000):=null;
		v_rstate  		varchar2(4000):=null;
		v_rpin  		varchar2(4000):=null;
		v_rmobile  	varchar2(4000):=null;
		v_rlandmark  	varchar2(4000):=null;
		v_rtel1  		varchar2(4000):=null;
		v_rtel2  		varchar2(4000):=null;
		v_paddress  	varchar2(4000):=null;
		v_pcity  		varchar2(4000):=null;
		v_pdistrict  	varchar2(4000):=null;
		v_pstate  		varchar2(4000):=null;
		v_ppin  		varchar2(4000):=null;
		v_pmobile  	varchar2(4000):=null;
		v_plandmark  	varchar2(4000):=null;
		v_ptel1  		varchar2(4000):=null;
		v_ptel2  		varchar2(4000):=null;
		v_cnt			number:=0;
		v_cnts			number:=0;

		v_branchname  	varchar2(4000):=null;
		v_add1  	varchar2(4000):=null;
		v_add2  	varchar2(4000):=null;
		v_add3  	varchar2(4000):=null;
		v_add4  	varchar2(4000):=null;
		v_bdist  	varchar2(4000):=null;
		v_bstate  	varchar2(4000):=null;
		v_bpin  	varchar2(4000):=null;
		v_branchadd varchar2(4000):=null;
		v_fname 	varchar2(4000):=null;

		v_d1	varchar2(4000):=null;
		v_d2	varchar2(4000):=null;
		v_d3	varchar2(4000):=null;
		v_d4	varchar2(4000):=null;
		v_aname	varchar2(4000):=null;	  

	begin
		-- Parsing the string
		transrec.ErrorData := 'Before parsing....';
		transrec.TRANS_CODE:=CreditUtilPkg.GetStrField(transrec.InOutData,'TRANS_CODE',i_retval);
		transrec.DATETIME:=CreditUtilPkg.GetStrField(transrec.InOutData,'DATETIME',i_retval);
		transrec.NET_ID:=CreditUtilPkg.GetStrField(transrec.InOutData,'NET_ID',i_retval);
		transrec.IDCT_ID:=CreditUtilPkg.GetStrField(transrec.InOutData,'IDCT_ID',i_retval);
		
		ErrRec.TransCode:=transrec.TRANS_CODE;
		ErrRec.IdctTime:=transrec.DATETIME;
		ErrRec.NetId:=transrec.NET_ID;
		ErrRec.IdctId:=transrec.IDCT_ID;
	
		transrec.IDCT_ERR_CODE :='20';
		transrec.IDCT_MESSAGE_TYPE:='02';
		transrec.ErrorData:='Removing header ........';
		transrec.InOutData:=substr(transrec.InOutData,instr(transrec.InOutData,'IDCT_MESSAGE_TYPE')+22);
		transrec.ErrorData := 'preparing data.....';
        v_TransCode:=transrec.TRANS_CODE;
		v_maker_id:=transrec.NET_ID;

				

		
	    v_Cin:=UPPER(CreditUtilPkg.GetStrField(transrec.InOutData,'F0010',i_retval)); 
		v_Product:=UPPER(CreditUtilPkg.GetStrField(transrec.InOutData,'F0011',i_retval));
		v_tempid:=UPPER(CreditUtilPkg.GetStrField(transrec.InOutData,'F0012',i_retval)); 
		
		
		
		transrec.ErrorData := 'getting data from customer_master_wk....'||v_Cin;
		
		select replace(F_NAME||' '||M_NAME||' '||L_NAME,'  ',' '),
		NVL(substr(cust.address,instr(cust.address,'|',1,1)+1,instr(cust.address,'|',1,2)-instr(cust.address,'|',1,1)-1),'NO_DATA')  , 
		NVL(substr(cust.address,instr(cust.address,'R'),instr(cust.address,'R')-instr(cust.address,'R')+1 ),'NO_DATA') , 
		NVL(substr(cust.address,4,instr(cust.address,'~')-4),'NO_DATA')  , 
		
		NVL(substr(cust.address,instr(cust.address,'~',1,1)+1,instr(cust.address,'~',1,2)-instr(cust.address,'~',1,1)-1),'NO_DATA') , 
		NVL(substr(cust.address,instr(cust.address,'~',1,2)+1,instr(cust.address,'~',1,3)-instr(cust.address,'~',1,2)-1),'NO_DATA') , 
		NVL(substr(cust.address,instr(cust.address,'~',1,3)+1,instr(cust.address,'~',1,4)-instr(cust.address,'~',1,3)-1),'NO_DATA') , 
		NVL(substr(cust.address,instr(cust.address,'~',1,4)+1,instr(cust.address,'~',1,5)-instr(cust.address,'~',1,4)-1),'NO_DATA') , 
		
		
		NVL(substr(cust.address,instr(cust.address,'~',1,5)+1,instr(cust.address,'~',1,6)-instr(cust.address,'~',1,5)-1),'NO_DATA') , 
		NVL(substr(cust.address,instr(cust.address,'~',1,6)+1,instr(cust.address,'~',1,7)-instr(cust.address,'~',1,6)-1),'NO_DATA') , 
		NVL(substr(cust.address,instr(cust.address,'~',1,7)+1,instr(cust.address,'~',1,8)-instr(cust.address,'~',1,7)-1),'NO_DATA') , 		
		NVL(substr(cust.address,instr(cust.address,'|',1,2)+1,instr(cust.address,'|',1,3)-instr(cust.address,'|',1,2)-1),'NO_DATA'),		
		
		nvl(substr(cust.address,instr(cust.address,'|R|')+3, instr(cust.address,'~',instr(cust.address,'|R|')+3)-instr(cust.address,'|R|')-3),'NO_DATA') ,			
		NVL(substr(cust.address,instr(cust.address,'~',1,9)+1,instr(cust.address,'~',1,10)-instr(cust.address,'~',1,9)-1),'NO_DATA') , 
		NVL(substr(cust.address,instr(cust.address,'~',1,10)+1,instr(cust.address,'~',1,11)-instr(cust.address,'~',1,10)-1),'NO_DATA') , 		
		NVL(substr(cust.address,instr(cust.address,'~',1,11)+1,instr(cust.address,'~',1,12)-instr(cust.address,'~',1,11)-1),'NO_DATA') ,
		
		
		NVL(substr(cust.address,instr(cust.address,'~',1,12)+1,instr(cust.address,'~',1,13)-instr(cust.address,'~',1,12)-1),'NO_DATA') , 
		NVL(substr(cust.address,instr(cust.address,'~',1,13)+1,instr(cust.address,'~',1,14)-instr(cust.address,'~',1,13)-1),'NO_DATA') , 
		NVL(substr(cust.address,instr(cust.address,'~',1,14)+1,instr(cust.address,'~',1,15)-instr(cust.address,'~',1,14)-1),'NO_DATA') , 
		NVL(substr(cust.address,instr(cust.address,'~',1,15)+1,instr(cust.address,'~',1,16)-instr(cust.address,'~',1,15)-1),'NO_DATA') , 		
		NVL(substr(cust.address,instr(cust.address,'~',1,16)+1),'NO_DATA')
		
		into v_fname,v_ResAddress,v_PerAddress,v_raddress,
		v_rcity,v_rdistrict,v_rmobile,v_rpin,
		v_rstate,v_rlandmark,v_rtel1,v_rtel2,
		v_paddress,v_pcity,v_pdistrict,v_pstate,
		v_ppin,v_pmobile,v_plandmark,v_ptel1,v_ptel2		
		from CUSTOMER_MASTER_WK cust where cust.cin=v_Cin;
		
		transrec.ErrorData := 'getting address data.....'||v_address;
		/*select    '<P>'||v_raddress||'</P>'
			||'<P>'||v_rcity||'</P>'
			||'<P>'||v_rdistrict||'</P>'
			||'<P>'||v_rstate||'</P>'
			||'<P>'||v_rpin||'</P>' into v_address from dual;*/
			
			select  'U-LPU-RU-LFONT size="9"U-R'||v_raddress||'U-L/FONTU-RU-L/PU-R'
			||'U-LPU-RU-LFONT size="9"U-R'||v_rcity||'U-L/FONTU-RU-L/PU-R'
			||'U-LPU-RU-LFONT size="9"U-R'||v_rdistrict||'U-L/FONTU-RU-L/PU-R'
			||'U-LPU-RU-LFONT size="9"U-R'||v_rstate||','||v_rpin||'U-L/FONTU-RU-L/PU-R' into v_address from dual;
			
			transrec.ErrorData := 'getting  data from customer_master.....'||v_Cin;
			
			
			
			
		transrec.ErrorData := 'getting data111.....';
			
			
		if v_tempid='99' then    -- Welcome Letter
			
			select BRANCH_NAME,ADR_ONE,ADR_TWO,ADR_THREE,ADR_FOUR,DISTRICT,STATE,PIN into v_branchname,v_add1,v_add2,v_add3,v_add4,v_bdist,v_bstate,v_bpin from SYND_BRANCH_MASTER
			where BIC=(select BIC from CUSTOMER_MASTER where CIN=v_Cin);
			
			
			
			select 	count(*) into v_cnt
			from PRODUCT_MASTER P,CARD_MASTER_WK C,CUSTOMER_MASTER CM,CR_LMT_TXN CLT 
			where P.PRD_CODE=C.PRODUCT_TYPE and 
			CLT.REFNO=C.ACC_NO and 
			C.CIN=CM.CIN and 
			CM.CIN=v_Cin;
			
				if v_cnt=0 then
				
				Open RetCur for  select  'F0001'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0002'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0003'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0004'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0005'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0006'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0007'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0008'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'
						from DUAL;
				

				else
				
				select v_raddress||','||v_rcity into v_d1 from dual;
				select v_rdistrict||','||v_rstate||','||v_rpin into v_d2 from dual;
				select v_branchname||','||v_add1||','||v_add2||','||v_add3||','||v_add4 into v_d3 from dual;
				select v_bdist||','||v_bstate||','||v_bpin into v_d4 from dual;
				
				Open RetCur for  select  'F0001'||lpad(nvl(length(CM.F_NAME),0),3,'0')||CM.F_NAME||
						'F0002'||lpad(nvl(length(v_d1),0),3,'0')||v_d1||
						'F0003'||lpad(nvl(length(v_d2),0),3,'0')||v_d2||
						'F0004'||lpad(nvl(length(v_d3),0),3,'0')||v_d3||
						'F0005'||lpad(nvl(length(v_d4),0),3,'0')||v_d4||
						'F0006'||lpad(nvl(length(C.CARD_NO),0),3,'0')||C.CARD_NO||
						'F0007'||lpad(nvl(length(CLT.CREDIT_LIMIT),0),3,'0')||CLT.CREDIT_LIMIT||
						'F0008'||lpad(nvl(length(CLT.CASH_LIMIT),0),3,'0')||CLT.CASH_LIMIT
						from PRODUCT_MASTER P,CARD_MASTER_WK C,CUSTOMER_MASTER CM,CR_LMT_TXN CLT 
						where P.PRD_CODE=C.PRODUCT_TYPE and 
						CLT.REFNO=C.ACC_NO and 
						C.CIN=CM.CIN and 
						CM.CIN=v_Cin;
						
					update 	CUSTOMER_MASTER set LETTER_GEN_FLG='G' where cin=v_Cin;
				
					--insert into LETTER_GENERATION(TEMPLETE_ID,PRD_CODE,CARD_NO,CHECKER_ID,CHECKER_DTTM,MAKER_ID,MAKER_DTTM) values(v_tempid,v_Product,(select card_no from card_master where cin=v_Cin),v_maker_id,sysdate,v_maker_id,sysdate);commit; 
				end if;
		end if;
		
			
			
			
			
			if v_tempid='100' then    -- Welcome Letter
			
			/*select BRANCH_NAME,ADR_ONE,ADR_TWO,ADR_THREE,ADR_FOUR,DISTRICT,STATE,PIN into v_branchname,v_add1,v_add2,v_add3,v_add4,v_bdist,v_bstate,v_bpin from SYND_BRANCH_MASTER
			where BIC=(select BIC from CUSTOMER_MASTER where CIN=v_Cin);*/
			
			--select v_branchname||','||v_add1||','||v_add2||','||v_add3||','||v_add4||','||v_bdist||','||v_bstate||','||v_bpin into v_branchadd from dual;
			
			select 	count(*) into v_cnt
			from PRODUCT_MASTER P,CARD_MASTER_WK C,CUSTOMER_MASTER CM,CR_LMT_TXN CLT 
			where 
			P.PRD_CODE=C.PRODUCT_TYPE and 
			CLT.REFNO=C.ACC_NO and 
			C.CIN=CM.CIN and 
			CM.CIN=v_Cin;
			
				if v_cnt=0 then
				
				Open RetCur for  select  'F0001'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0002'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0003'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0004'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0005'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0006'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0007'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0008'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0009'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0010'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0011'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0012'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'
						from DUAL;
				

				else
				
				Open RetCur for  select  'F0001'||lpad(nvl(length(replace((F_NAME||' '||m_name||' '||l_name),'  ',' ')),0),3,'0')||replace((F_NAME||' '||m_name||' '||l_name),'  ',' ')||
						'F0002'||lpad(nvl(length(CM.APP_NO),0),3,'0')||CM.APP_NO||
						'F0003'||lpad(nvl(length(P.PRD_NAME),0),3,'0')||P.PRD_NAME||
						'F0004'||lpad(nvl(length(CLT.CREDIT_LIMIT),0),3,'0')||CLT.CREDIT_LIMIT||
						'F0005'||lpad(nvl(length(CLT.CASH_LIMIT),0),3,'0')||CLT.CASH_LIMIT||
						'F0006'||lpad(nvl(length(CLT.TE_LIMIT),0),3,'0')||CLT.TE_LIMIT||
						'F0007'||lpad(nvl(length(C.CARD_NO),0),3,'0')||C.CARD_NO||
						'F0008'||lpad(nvl(length(v_address),0),3,'0')||v_address||
						'F0009'||lpad(nvl(length(CM.CUSTOMER_ID),0),3,'0')||CM.CUSTOMER_ID||
						'F0010'||lpad(nvl(length(nvl(CM.MOBILE_NO,' ')),0),3,'0')||nvl(CM.MOBILE_NO,' ')||
						'F0011'||lpad(nvl(length(nvl(CM.EMAIL_ID,' ')),0),3,'0')||nvl(CM.EMAIL_ID,' ')||
						'F0013'||lpad(nvl(length(current_date),0),3,'0')||current_date||
						'F0014'||lpad(nvl(length(''),0),3,'0')||''||
						'F0015'||lpad(nvl(length(substr(C.CARD_NO,11,16)),0),3,'0')||substr(C.CARD_NO,11,16)||
						'F0016'||lpad(nvl(length(''),0),3,'0')||''
						--'F0012'||lpad(nvl(length(v_branchadd),0),3,'0')||v_branchadd
						from PRODUCT_MASTER P,CARD_MASTER_WK C,CUSTOMER_MASTER CM,CR_LMT_TXN CLT 
						where 
						P.PRD_CODE=C.PRODUCT_TYPE and 
						CLT.REFNO=C.ACC_NO and 
						C.CIN=CM.CIN and 
						CM.CIN=v_Cin;
							update 	CUSTOMER_MASTER set LETTER_GEN_FLG='G' where cin=v_Cin;	
				--insert into LETTER_GENERATION(TEMPLETE_ID,PRD_CODE,CARD_NO,CHECKER_ID,CHECKER_DTTM,MAKER_ID,MAKER_DTTM) values(v_tempid,v_Product,(select card_no from card_master where cin=v_Cin),v_maker_id,sysdate,v_maker_id,sysdate);commit; 

				end if;
		end if;
		
		
		
		if v_tempid='103' then  -- for Reject Letter

		SELECT count(*) into v_cnt FROM CUSTOMER_MASTER_WK  where CIN=v_Cin;

			if  v_cnt=0 then 
			Open RetCur for  select  'F0001'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0002'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0003'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0004'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0005'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0006'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0007'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'
						 FROM DUAL;
			else
			Open RetCur for  select  'F0001'||lpad(nvl(length(F_NAME),0),3,'0')||F_NAME||
						'F0002'||lpad(nvl(length(to_char(DOB,'dd-MON-yyyy')),0),3,'0')||to_char(DOB,'dd-MON-yyyy')||
						'F0003'||lpad(nvl(length(nvl(MOBILE_NO,' ')),0),3,'0')||nvl(MOBILE_NO,' ')||
						'F0004'||lpad(nvl(length(nvl(EMAIL_ID,' ')),0),3,'0')||nvl(EMAIL_ID,' ')||
						'F0005'||lpad(nvl(length(v_address),0),3,'0')||v_address||
						'F0006'||lpad(nvl(length(APP_NO),0),3,'0')||APP_NO||
						'F0007'||lpad(nvl(length(CIN),0),3,'0')||CIN
						 FROM CUSTOMER_MASTER_WK  where CIN=v_Cin ;
			end if;

		end if;
		
		
		
		if v_tempid='107' then  

		select count(*) into v_cnt
		FROM PRODUCT_MASTER P,CARD_MASTER cm,CUSTOMER_MASTER stm ,CUST_PAY_TB cpt,CUST_PAY_MASTER cpm 
		where cm.cin=stm.cin 
		and P.PRD_CODE=cm.PRODUCT_TYPE
		and cm.CARD_NO=cpt.CARD_NO
		and cm.PRODUCT_TYPE=v_Product		
		and cpt.REFNO=cpm.REFNO 
		and cm.CARD_STATUS='I' and cpm.STATUS_FLG='B' and cm.CIN=v_Cin;
		
			if  v_cnt=0 then 
				
			Open RetCur for  select  'F0001'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0002'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0003'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0004'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0005'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0006'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0007'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0008'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0009'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0010'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0011'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0012'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0013'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0014'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'
						 FROM DUAL;
			else
			Open RetCur for  select  'F0001'||lpad(nvl(length(stm.F_NAME),0),3,'0')||stm.F_NAME||
						'F0002'||lpad(nvl(length(cm.CARD_NO),0),3,'0')||cm.CARD_NO||
						'F0003'||lpad(nvl(length(cm.ACC_NO),0),3,'0')||cm.ACC_NO||
						'F0004'||lpad(nvl(length(P.PRD_NAME),0),3,'0')||P.PRD_NAME||
						'F0005'||lpad(nvl(length(nvl(stm.MOBILE_NO,' ')),0),3,'0')||nvl(stm.MOBILE_NO,' ')||
						'F0006'||lpad(nvl(length(nvl(stm.EMAIL_ID,' ')),0),3,'0')||nvl(stm.EMAIL_ID,' ')||
						'F0007'||lpad(nvl(length((select um.USER_NAME from user_id_mapping uim,user_master um where uim.system_user_id=um.user_id and uim.login_user_id=cm.BR_ID)),0),3,'0')||(select um.USER_NAME from user_id_mapping uim,user_master um where uim.system_user_id=um.user_id and uim.login_user_id=cm.BR_ID)||
						'F0008'||lpad(nvl(length(v_address),0),3,'0')||v_address||
						'F0009'||lpad(nvl(length(stm.CUSTOMER_ID),0),3,'0')||stm.CUSTOMER_ID||
						'F0010'||lpad(nvl(length(cpm.bank_name),0),3,'0')||cpm.bank_name||
						'F0011'||lpad(nvl(length(cpm.BOUNCE_DESC),0),3,'0')||cpm.BOUNCE_DESC||
						'F0012'||lpad(nvl(length(cpm.CHQ_NO),0),3,'0')||cpm.CHQ_NO||
						'F0013'||lpad(nvl(length(to_char(cpm.BOUNCE_DT,'dd-MON-yyyy')),0),3,'0')||to_char(cpm.BOUNCE_DT,'dd-MON-yyyy')||
						'F0014'||lpad(nvl(length(cpm.PAY_AMT),0),3,'0')||cpm.PAY_AMT
						FROM PRODUCT_MASTER P,CARD_MASTER cm,CUSTOMER_MASTER stm ,CUST_PAY_TB cpt,CUST_PAY_MASTER cpm 
						where cm.cin=stm.cin 
						and P.PRD_CODE=cm.PRODUCT_TYPE
						and cm.CARD_NO=cpt.CARD_NO
						and cm.PRODUCT_TYPE=v_Product		
						and cpt.REFNO=cpm.REFNO 
						and cm.CARD_STATUS='I' and cpm.STATUS_FLG='B' and cm.CIN=v_Cin;
	

			end if;

		end if;
		
		if v_tempid='102' then

			SELECT count(*) into v_cnt FROM CUSTOMER_MASTER_WK  where CIN=v_Cin;

			if  v_cnt=0 then 
			Open RetCur for  select  'F0001'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0002'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0003'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0004'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0005'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0006'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0007'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'
						 FROM DUAL;
			else
			Open RetCur for  select  'F0001'||lpad(nvl(length(F_NAME),0),3,'0')||F_NAME||
						'F0002'||lpad(nvl(length(nvl(MOBILE_NO,' ')),0),3,'0')||nvl(MOBILE_NO,' ')||
						'F0003'||lpad(nvl(length(nvl(EMAIL_ID,' ')),0),3,'0')||nvl(EMAIL_ID,' ')||
						'F0004'||lpad(nvl(length(v_address),0),3,'0')||v_address||
						'F0005'||lpad(nvl(length(nvl(CUSTOMER_ID,' ')),0),3,'0')||nvl(CUSTOMER_ID,' ')||
						'F0006'||lpad(nvl(length(APP_NO),0),3,'0')||APP_NO||
						'F0007'||lpad(nvl(length(to_char(DOB,'dd-MON-yyyy')),0),3,'0')||to_char(DOB,'dd-MON-yyyy')
						 FROM CUSTOMER_MASTER_WK  where CIN=v_Cin ;
			end if;

		end if;
		
		
		if v_tempid='111' then

				select count(*) into v_cnt
				FROM PRODUCT_MASTER P,CARD_MASTER cm,CUSTOMER_MASTER stm ,CUSTOMER_REQUEST crq
				where cm.cin=stm.cin 
				and cm.CARD_NO=crq.CARD_NO 
				and P.PRD_CODE=cm.PRODUCT_TYPE
				and cm.PRODUCT_TYPE=v_Product 
				and cm.cin=v_Cin;
		
			if  v_cnt=0 then 
				Open RetCur for  select  'F0001'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0002'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0003'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0004'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0005'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0006'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0007'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0008'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0009'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0010'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0011'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0012'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'
						 FROM DUAL;
			else
				Open RetCur for  select  'F0001'||lpad(nvl(length(stm.F_NAME),0),3,'0')||stm.F_NAME||
						'F0002'||lpad(nvl(length(cm.CARD_NO),0),3,'0')||cm.CARD_NO||
						'F0003'||lpad(nvl(length(cm.ACC_NO),0),3,'0')||cm.ACC_NO||
						'F0004'||lpad(nvl(length(P.PRD_NAME),0),3,'0')||P.PRD_NAME||
						'F0005'||lpad(nvl(length(nvl(stm.MOBILE_NO,' ')),0),3,'0')||nvl(stm.MOBILE_NO,' ')||
						'F0006'||lpad(nvl(length(nvl(stm.EMAIL_ID,' ')),0),3,'0')||nvl(stm.EMAIL_ID,' ')||
						'F0007'||lpad(nvl(length((select um.USER_NAME from user_id_mapping uim,user_master um where uim.system_user_id=um.user_id and uim.login_user_id=cm.BR_ID)),0),3,'0')||(select um.USER_NAME from user_id_mapping uim,user_master um where uim.system_user_id=um.user_id and uim.login_user_id=cm.BR_ID)||
						'F0008'||lpad(nvl(length(v_address),0),3,'0')||v_address||
						'F0009'||lpad(nvl(length(stm.CUSTOMER_ID),0),3,'0')||stm.CUSTOMER_ID||
						'F0010'||lpad(nvl(length(crq.TXN_AMOUNT),0),3,'0')||crq.TXN_AMOUNT||
						'F0011'||lpad(nvl(length(crq.REQUEST_DATE_TIME),0),3,'0')||crq.REQUEST_DATE_TIME||
						'F0012'||lpad(nvl(length(crq.REF_NO),0),3,'0')||crq.REF_NO
						FROM PRODUCT_MASTER P,CARD_MASTER cm,CUSTOMER_MASTER stm ,CUSTOMER_REQUEST crq
						where cm.cin=stm.cin 
						and cm.CARD_NO=crq.CARD_NO 
						and P.PRD_CODE=cm.PRODUCT_TYPE
						and cm.PRODUCT_TYPE=v_Product 
						and cm.cin=v_Cin;

			end if;

		end if;
		
	if v_tempid='101'  or v_tempid='104' or v_tempid='105'  then
	
		select count(*) into v_cnt
		from PRODUCT_MASTER P,CARD_MASTER C,CUSTOMER_MASTER CM,CARD_ACCOUNT_MASTER CAM,CR_LMT_TXN CLT 
		where P.PRD_CODE=v_Product and
		P.PRD_CODE=C.PRODUCT_TYPE and 
		CAM.CARD_ACCT=C.ACC_NO and
		CLT.REFNO=C.CARD_NO and 
		C.CIN=CM.CIN and 
		CM.CIN=v_Cin and 
		C.CARD_STATUS='I'; 
	
		if v_cnt=0 then
			
			Open RetCur for  select  'F0001'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0002'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0003'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0004'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0005'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0006'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0007'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0008'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0009'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0010'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0011'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0012'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0013'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0014'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0015'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0016'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0017'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0018'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0019'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'
						 FROM DUAL;
	
		else
	                                          
		select count(*) into v_cnts from STMT_TBL ST,CARD_MASTER C where ST.CARD_NO=C.CARD_NO and C.CIN=v_Cin and ST.BILL_DATE=(select max(STA.BILL_DATE) from STMT_TBL STA,CARD_MASTER C where STA.CARD_NO=C.CARD_NO and C.CIN=v_Cin);
	
			if v_cnts=0 then
	
			Open RetCur for  select  'F0001'||lpad(nvl(length(CM.F_NAME),0),3,'0')||CM.F_NAME||
						'F0002'||lpad(nvl(length(C.CARD_NO),0),3,'0')||C.CARD_NO||
						'F0003'||lpad(nvl(length(C.ACC_NO),0),3,'0')||C.ACC_NO||
						'F0004'||lpad(nvl(length(P.PRD_NAME),0),3,'0')||P.PRD_NAME||
						'F0005'||lpad(nvl(length(nvl(CM.MOBILE_NO,' ')),0),3,'0')||nvl(CM.MOBILE_NO,' ')||
						'F0006'||lpad(nvl(length(nvl(CM.EMAIL_ID,' ')),0),3,'0')||nvl(CM.EMAIL_ID,' ')||
						'F0007'||lpad(nvl(length((select um.USER_NAME from user_id_mapping uim,user_master um where uim.system_user_id=um.user_id and uim.login_user_id=C.BR_ID)),0),3,'0')||(select um.USER_NAME from user_id_mapping uim,user_master um where uim.system_user_id=um.user_id and uim.login_user_id=C.BR_ID)||
						'F0008'||lpad(nvl(length(to_char(C.V_THRU_DT,'dd-MON-yyyy')),0),3,'0')||to_char(C.V_THRU_DT,'dd-MON-yyyy')||
						'F0009'||lpad(nvl(length(CAM.DEL_COUNT),0),3,'0')||CAM.DEL_COUNT||
						'F0010'||lpad(nvl(length(CLT.CREDIT_LIMIT),0),3,'0')||CLT.CREDIT_LIMIT||
						'F0011'||lpad(nvl(length(CLT.CASH_LIMIT),0),3,'0')||CLT.CASH_LIMIT||
						'F0012'||lpad(nvl(length(CLT.TE_LIMIT),0),3,'0')||CLT.TE_LIMIT||
						'F0013'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0014'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0015'||lpad(nvl(length(v_address),0),3,'0')||v_address||
						'F0016'||lpad(nvl(length(CM.CUSTOMER_ID),0),3,'0')||CM.CUSTOMER_ID||
						'F0017'||lpad(nvl(length(decode(C.PRIM_FLAG,'Y','Primary','N','Supplementary','Primary')),0),3,'0')||decode(C.PRIM_FLAG,'Y','Primary','N','Supplementary','Primary')||
						'F0018'||lpad(nvl(length(CM.APP_NO),0),3,'0')||CM.APP_NO||
						'F0019'||lpad(nvl(length(to_char(CM.DOB,'dd-MON-yyyy')),0),3,'0')||to_char(CM.DOB,'dd-MON-yyyy')
						from PRODUCT_MASTER P,CARD_MASTER C,CUSTOMER_MASTER CM,CARD_ACCOUNT_MASTER CAM,CR_LMT_TXN CLT 
						where P.PRD_CODE=v_Product and
						P.PRD_CODE=C.PRODUCT_TYPE and 
						CAM.CARD_ACCT=C.ACC_NO and 
						CLT.REFNO=C.CARD_NO and 
						C.CIN=CM.CIN and 
						CM.CIN=v_Cin and 
						C.CARD_STATUS='I';
	
	
			else
				Open RetCur for  select  'F0001'||lpad(nvl(length(CM.F_NAME),0),3,'0')||CM.F_NAME||
						'F0002'||lpad(nvl(length(C.CARD_NO),0),3,'0')||C.CARD_NO||
						'F0003'||lpad(nvl(length(C.ACC_NO),0),3,'0')||C.ACC_NO||
						'F0004'||lpad(nvl(length(P.PRD_NAME),0),3,'0')||P.PRD_NAME||
						'F0005'||lpad(nvl(length(nvl(CM.MOBILE_NO,' ')),0),3,'0')||nvl(CM.MOBILE_NO,' ')||
						'F0006'||lpad(nvl(length(nvl(CM.EMAIL_ID,' ')),0),3,'0')||nvl(CM.EMAIL_ID,' ')||
						'F0007'||lpad(nvl(length((select um.USER_NAME from user_id_mapping uim,user_master um where uim.system_user_id=um.user_id and uim.login_user_id=C.BR_ID)),0),3,'0')||(select um.USER_NAME from user_id_mapping uim,user_master um where uim.system_user_id=um.user_id and uim.login_user_id=C.BR_ID)||
						'F0008'||lpad(nvl(length(to_char(C.V_THRU_DT,'dd-MON-yyyy')),0),3,'0')||to_char(C.V_THRU_DT,'dd-MON-yyyy')||
						'F0009'||lpad(nvl(length(CAM.DEL_COUNT),0),3,'0')||CAM.DEL_COUNT||
						'F0010'||lpad(nvl(length(CLT.CREDIT_LIMIT),0),3,'0')||CLT.CREDIT_LIMIT||
						'F0011'||lpad(nvl(length(CLT.CASH_LIMIT),0),3,'0')||CLT.CASH_LIMIT||
						'F0012'||lpad(nvl(length(CLT.TE_LIMIT),0),3,'0')||CLT.TE_LIMIT||
						'F0013'||lpad(nvl(length((select nvl(ST.OUTSTANDING,0) from STMT_TBL ST where ST.CARD_NO=C.CARD_NO and ST.BILL_DATE=(select max(STA.BILL_DATE) from STMT_TBL STA where STA.CARD_NO=C.CARD_NO ))),0),3,'0')||(select nvl(ST.OUTSTANDING,0) from STMT_TBL ST where ST.CARD_NO=C.CARD_NO and ST.BILL_DATE=(select max(STA.BILL_DATE) from STMT_TBL STA where STA.CARD_NO=C.CARD_NO ))||
						'F0014'||lpad(nvl(length((select nvl(ST.MIN_DUE,0) from STMT_TBL ST where ST.CARD_NO=C.CARD_NO and ST.BILL_DATE=(select max(STA.BILL_DATE) from STMT_TBL STA where STA.CARD_NO=C.CARD_NO ))),0),3,'0')||(select nvl(ST.MIN_DUE,0) from STMT_TBL ST where ST.CARD_NO=C.CARD_NO and ST.BILL_DATE=(select max(STA.BILL_DATE) from STMT_TBL STA where STA.CARD_NO=C.CARD_NO ))||
						'F0015'||lpad(nvl(length(v_address),0),3,'0')||v_address||
						'F0016'||lpad(nvl(length(CM.CUSTOMER_ID),0),3,'0')||CM.CUSTOMER_ID||
						'F0017'||lpad(nvl(length(decode(C.PRIM_FLAG,'Y','Primary','N','Supplementary','Primary')),0),3,'0')||decode(C.PRIM_FLAG,'Y','Primary','N','Supplementary','Primary')||
						'F0018'||lpad(nvl(length(CM.APP_NO),0),3,'0')||CM.APP_NO||
						'F0019'||lpad(nvl(length(to_char(CM.DOB,'dd-MON-yyyy')),0),3,'0')||to_char(CM.DOB,'dd-MON-yyyy')
						from PRODUCT_MASTER P,CARD_MASTER C,CUSTOMER_MASTER CM,CARD_ACCOUNT_MASTER CAM,CR_LMT_TXN CLT 
						where P.PRD_CODE=v_Product and
						P.PRD_CODE=C.PRODUCT_TYPE and 
						CAM.CARD_ACCT=C.ACC_NO and 
						CLT.REFNO=C.CARD_NO and 
						C.CIN=CM.CIN and 
						CM.CIN=v_Cin and 
						C.CARD_STATUS='I';
	
	
	
			end if;
	
			insert into LETTER_GENERATION(TEMPLETE_ID,PRD_CODE,CARD_NO,CHECKER_ID,CHECKER_DTTM,MAKER_ID,MAKER_DTTM) values(v_tempid,v_Product,(select card_no from card_master where cin=v_Cin),'ABCDEF',sysdate,'ABCDEF',sysdate);commit; 
			commit;
	
	
		end if;
	
	end if;
	
	
	if v_tempid='106' or v_tempid='108' or v_tempid='109' or v_tempid='110' then
	
		select count(*) into v_cnt
		from PRODUCT_MASTER P,CARD_MASTER C,CUSTOMER_MASTER CM,CARD_ACCOUNT_MASTER CAM,CR_LMT_TXN CLT 
		where P.PRD_CODE=v_Product and
		P.PRD_CODE=C.PRODUCT_TYPE and 
		CAM.CARD_ACCT=C.ACC_NO and
		CLT.REFNO=C.CARD_NO and 
		C.CIN=CM.CIN and 
		CM.CIN=v_Cin and 
		C.CARD_STATUS='I'; 
	
		if v_cnt=0 then
			Open RetCur for  select  'F0001'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0002'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0003'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0004'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0005'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0006'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0007'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0008'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0009'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0010'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0011'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0012'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0013'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0014'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0015'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0016'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0017'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0018'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0019'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0020'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'
						 FROM DUAL;
	
		else
	                                          
		select count(*) into v_cnts from STMT_TBL ST,CARD_MASTER C where ST.CARD_NO=C.CARD_NO and C.CIN=v_Cin and ST.BILL_DATE=(select max(STA.BILL_DATE) from STMT_TBL STA,CARD_MASTER C where STA.CARD_NO=C.CARD_NO and C.CIN=v_Cin);
	
			if v_cnts=0 then
				Open RetCur for  select  'F0001'||lpad(nvl(length(CM.F_NAME),0),3,'0')||CM.F_NAME||
						'F0002'||lpad(nvl(length(C.CARD_NO),0),3,'0')||C.CARD_NO||
						'F0003'||lpad(nvl(length(C.ACC_NO),0),3,'0')||C.ACC_NO||
						'F0004'||lpad(nvl(length(P.PRD_NAME),0),3,'0')||P.PRD_NAME||
						'F0005'||lpad(nvl(length(nvl(CM.MOBILE_NO,' ')),0),3,'0')||nvl(CM.MOBILE_NO,' ')||
						'F0006'||lpad(nvl(length(nvl(CM.EMAIL_ID,' ')),0),3,'0')||nvl(CM.EMAIL_ID,' ')||
						'F0007'||lpad(nvl(length((select um.USER_NAME from user_id_mapping uim,user_master um where uim.system_user_id=um.user_id and uim.login_user_id=C.BR_ID)),0),3,'0')||(select um.USER_NAME from user_id_mapping uim,user_master um where uim.system_user_id=um.user_id and uim.login_user_id=C.BR_ID)||
						'F0008'||lpad(nvl(length(to_char(C.V_THRU_DT,'dd-MON-yyyy')),0),3,'0')||to_char(C.V_THRU_DT,'dd-MON-yyyy')||
						'F0009'||lpad(nvl(length(CAM.DEL_COUNT),0),3,'0')||CAM.DEL_COUNT||
						'F0010'||lpad(nvl(length(CLT.CREDIT_LIMIT),0),3,'0')||CLT.CREDIT_LIMIT||
						'F0011'||lpad(nvl(length(CLT.CASH_LIMIT),0),3,'0')||CLT.CASH_LIMIT||
						'F0012'||lpad(nvl(length(CLT.TE_LIMIT),0),3,'0')||CLT.TE_LIMIT||
						'F0013'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0014'||lpad(nvl(length('NO_DATA'),0),3,'0')||'NO_DATA'||
						'F0015'||lpad(nvl(length(v_address),0),3,'0')||v_address||
						'F0016'||lpad(nvl(length(CM.CUSTOMER_ID),0),3,'0')||CM.CUSTOMER_ID||
						'F0017'||lpad(nvl(length(decode(C.PRIM_FLAG,'Y','Primary','N','Supplementary','Primary')),0),3,'0')||decode(C.PRIM_FLAG,'Y','Primary','N','Supplementary','Primary')||
						'F0018'||lpad(nvl(length(CM.APP_NO),0),3,'0')||CM.APP_NO||
						'F0019'||lpad(nvl(length(to_char(CM.DOB,'dd-MON-yyyy')),0),3,'0')||to_char(CM.DOB,'dd-MON-yyyy')||
						'F0020'||lpad(nvl(length(ABS(CAM.CARD_ACCT_BAL+CLT.CREDIT_LIMIT)),0),3,'0')||ABS(CAM.CARD_ACCT_BAL+CLT.CREDIT_LIMIT)
						from PRODUCT_MASTER P,CARD_MASTER C,CUSTOMER_MASTER CM,CARD_ACCOUNT_MASTER CAM,CR_LMT_TXN CLT 
						where P.PRD_CODE=v_Product and
						P.PRD_CODE=C.PRODUCT_TYPE and 
						CAM.CARD_ACCT=C.ACC_NO and 
						CLT.REFNO=C.CARD_NO and 
						C.CIN=CM.CIN and 
						CM.CIN=v_Cin and 
						C.CARD_STATUS='I';
	
	
			else
	
				Open RetCur for  select  'F0001'||lpad(nvl(length(CM.F_NAME),0),3,'0')||CM.F_NAME||
						'F0002'||lpad(nvl(length(C.CARD_NO),0),3,'0')||C.CARD_NO||
						'F0003'||lpad(nvl(length(C.ACC_NO),0),3,'0')||C.ACC_NO||
						'F0004'||lpad(nvl(length(P.PRD_NAME),0),3,'0')||P.PRD_NAME||
						'F0005'||lpad(nvl(length(nvl(CM.MOBILE_NO,' ')),0),3,'0')||nvl(CM.MOBILE_NO,' ')||
						'F0006'||lpad(nvl(length(nvl(CM.EMAIL_ID,' ')),0),3,'0')||nvl(CM.EMAIL_ID,' ')||
						'F0007'||lpad(nvl(length((select um.USER_NAME from user_id_mapping uim,user_master um where uim.system_user_id=um.user_id and uim.login_user_id=C.BR_ID)),0),3,'0')||(select um.USER_NAME from user_id_mapping uim,user_master um where uim.system_user_id=um.user_id and uim.login_user_id=C.BR_ID)||
						'F0008'||lpad(nvl(length(to_char(C.V_THRU_DT,'dd-MON-yyyy')),0),3,'0')||to_char(C.V_THRU_DT,'dd-MON-yyyy')||
						'F0009'||lpad(nvl(length(CAM.DEL_COUNT),0),3,'0')||CAM.DEL_COUNT||
						'F0010'||lpad(nvl(length(CLT.CREDIT_LIMIT),0),3,'0')||CLT.CREDIT_LIMIT||
						'F0011'||lpad(nvl(length(CLT.CASH_LIMIT),0),3,'0')||CLT.CASH_LIMIT||
						'F0012'||lpad(nvl(length(CLT.TE_LIMIT),0),3,'0')||CLT.TE_LIMIT||
						'F0013'||lpad(nvl(length((select nvl(ST.OUTSTANDING,0) from STMT_TBL ST where ST.CARD_NO=C.CARD_NO and ST.BILL_DATE=(select max(STA.BILL_DATE) from STMT_TBL STA where STA.CARD_NO=C.CARD_NO ))),0),3,'0')||(select nvl(ST.OUTSTANDING,0) from STMT_TBL ST where ST.CARD_NO=C.CARD_NO and ST.BILL_DATE=(select max(STA.BILL_DATE) from STMT_TBL STA where STA.CARD_NO=C.CARD_NO ))||
						'F0014'||lpad(nvl(length((select nvl(ST.MIN_DUE,0) from STMT_TBL ST where ST.CARD_NO=C.CARD_NO and ST.BILL_DATE=(select max(STA.BILL_DATE) from STMT_TBL STA where STA.CARD_NO=C.CARD_NO ))),0),3,'0')||(select nvl(ST.MIN_DUE,0) from STMT_TBL ST where ST.CARD_NO=C.CARD_NO and ST.BILL_DATE=(select max(STA.BILL_DATE) from STMT_TBL STA where STA.CARD_NO=C.CARD_NO ))||
						'F0015'||lpad(nvl(length(v_address),0),3,'0')||v_address||
						'F0016'||lpad(nvl(length(CM.CUSTOMER_ID),0),3,'0')||CM.CUSTOMER_ID||
						'F0017'||lpad(nvl(length(decode(C.PRIM_FLAG,'Y','Primary','N','Supplementary','Primary')),0),3,'0')||decode(C.PRIM_FLAG,'Y','Primary','N','Supplementary','Primary')||
						'F0018'||lpad(nvl(length(CM.APP_NO),0),3,'0')||CM.APP_NO||
						'F0019'||lpad(nvl(length(to_char(CM.DOB,'dd-MON-yyyy')),0),3,'0')||to_char(CM.DOB,'dd-MON-yyyy')||
						'F0020'||lpad(nvl(length(ABS(CAM.CARD_ACCT_BAL+CLT.CREDIT_LIMIT)),0),3,'0')||ABS(CAM.CARD_ACCT_BAL+CLT.CREDIT_LIMIT)
						from PRODUCT_MASTER P,CARD_MASTER C,CUSTOMER_MASTER CM,CARD_ACCOUNT_MASTER CAM,CR_LMT_TXN CLT 
						where P.PRD_CODE=v_Product and
						P.PRD_CODE=C.PRODUCT_TYPE and 
						CAM.CARD_ACCT=C.ACC_NO and 
						CLT.REFNO=C.CARD_NO and 
						C.CIN=CM.CIN and 
						CM.CIN=v_Cin and 
						C.CARD_STATUS='I';
	
	
	
			end if;
	
			insert into LETTER_GENERATION(TEMPLETE_ID,PRD_CODE,CARD_NO,CHECKER_ID,CHECKER_DTTM,MAKER_ID,MAKER_DTTM) values(v_tempid,v_Product,(select card_no from card_master where cin=v_Cin),'ABCDEF',sysdate,'ABCDEF',sysdate);commit; 
			commit;
	
	
		end if;
	
	end if;


			

        
		transrec.ErrorData:='Success';
		transrec.InOutData:='|3|IDCT_STATUS=XML_PROCESSED|IDCT_ERR_CODE=NO_DATA|IDCT_MESSAGE_TYPE=02|';
		transrec.InOutCode:=0;
		return;
               
		exception
		when FLDERR then
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-1;
			transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE='||transrec.IDCT_ERR_CODE||'|IDCT_MESSAGE_TYPE=02|';
			return;
		when NO_DATA_FOUND then
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-2;
			transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE='||transrec.IDCT_ERR_CODE||'|IDCT_MESSAGE_TYPE=02|';
			return;
		when others then
			transrec.IDCT_ERR_CODE:='03';
			rollback;
			transrec.OraError:=substr(SQLERRM,1,100);
			transrec.OraCode:=SQLCODE;
			insert into ErrorStatus(ErrorData,ErrorNo,Comments,IdctTime,NetId,IdctId,TransCode) values(transrec.OraError,transrec.OraCode,transrec.ErrorData,ErrRec.IdctTime,ErrRec.NetId,ErrRec.IdctId,ErrRec.TransCode);
                        commit;
			transrec.InOutCode:=-3;
                        transrec.InOutData:='|3|IDCT_STATUS=XML_ERROR|IDCT_ERR_CODE=03|IDCT_MESSAGE_TYPE=02|';
			return;

	end pGetTemplateRD;
	
	
	
	
	
  
end TemplateDesignPkg;
/
