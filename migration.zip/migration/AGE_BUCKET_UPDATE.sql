        SET SERVEROUTPUT ON
        DECLARE

        ACCT_NO VARCHAR2(50):=null;

        UPD_NEW_MIN_DUE NUMBER(15,2):=0;
        UPD_NEW_DEL_CNT NUMBER(5):=0;
        UPD_NEW_DEL_PAY NUMBER(15,2):=0;
        BAL NUMBER(15,2):=0;
		V_DEL_PAY NUMBER(15,2):=0;
		V_ERRMSG VARCHAR2(5000);
		C_CNT  NUMBER;
		
        CURSOR ACCOUNTS_CURSOR IS SELECT DISTINCT ACCOUNT_NO FROM STMT_TBL where trunc(bill_date)='15-JUL-16' ;

        BEGIN
								dbms_output.put_line('Begin started');
								
                                OPEN  ACCOUNTS_CURSOR;
                                LOOP
                        --(
                                FETCH ACCOUNTS_CURSOR INTO ACCT_NO;
                                IF (ACCOUNTS_CURSOR%NOTFOUND) THEN EXIT; END IF;

                                DBMS_OUTPUT.PUT_LINE('ACCOUNT NO IS : '||ACCT_NO);

                                        BAL:=0;
										
SELECT COUNT(*) INTO C_CNT FROM BILL_FEE_TBL WHERE ACC_NO=ACCT_NO AND BILL_DATE IS NULL AND 
TXN_TYPE IN('DEP','REFUN','RECHG_PUR','RECHRG_CA'); 
IF C_CNT>0 THEN

SELECT SUM(ABS(NVL(LOCAL_AMT,0))) INTO UPD_NEW_DEL_PAY FROM BILL_FEE_TBL WHERE ACC_NO=ACCT_NO AND BILL_DATE IS NULL AND 
TXN_TYPE IN('DEP','REFUN','RECHG_PUR','RECHRG_CA');

dbms_output.put_line('UPD_NEW_DEL_PAY '||UPD_NEW_DEL_PAY);

ELSE
UPD_NEW_DEL_PAY:=0;
END IF;
								
                --UPDATE AGE BUCKET
										
                                        SELECT
                                                        NVL(MIN_DUE,0),
                                                        NVL(DEL_CNT,0)
                                        INTO
                                                        UPD_NEW_MIN_DUE,
                                                        UPD_NEW_DEL_CNT
                                        FROM
                                                        STMT_TBL
                                        WHERE
                                                        TRUNC(BILL_DATE)='15-JUL-16' AND
                                                        ROWNUM < 2 AND
                                                        ACCOUNT_NO=ACCT_NO;
														
										dbms_output.put_line('UPD_NEW_MIN_DUE '||UPD_NEW_MIN_DUE);
										dbms_output.put_line('UPD_NEW_DEL_CNT '||UPD_NEW_DEL_CNT);
							
                                        SELECT (UPD_NEW_MIN_DUE-UPD_NEW_DEL_PAY) INTO BAL FROM DUAL;
										V_DEL_PAY:=(BAL-UPD_NEW_MIN_DUE);

										dbms_output.put_line('BAL '||BAL);
										dbms_output.put_line('V_DEL_PAY '||V_DEL_PAY);
										
										
                                        UPDATE
                                                STMT_TBL
                                        SET
                                                del_flag='', AGE_CURRENT=0, age_30=0, AGE_60=0, AGE_90=0, AGE_120=0, AGE_150=0, AGE_180=0, AGE_210=0, AGE_ABOVE_210=0
                                        WHERE
                                                TRUNC(BILL_DATE)='15-JUL-16'
                                                AND ACCOUNT_NO=ACCT_NO;

                IF((BAL > '0') OR (BAL > '0.00')) THEN
                                IF UPD_NEW_DEL_CNT IS NULL THEN
                                        UPDATE STMT_TBL SET
                                        AGE_CURRENT=BAL,DEL_PAY=V_DEL_PAY
                                        WHERE TRUNC(BILL_DATE)='15-JUL-16' AND ACCOUNT_NO=ACCT_NO;
                                ELSIF UPD_NEW_DEL_CNT='0' THEN
                                        UPDATE STMT_TBL SET
                                        AGE_CURRENT=BAL,DEL_PAY=V_DEL_PAY
                                        WHERE TRUNC(BILL_DATE)='15-JUL-16' AND ACCOUNT_NO=ACCT_NO;
                                ELSIF UPD_NEW_DEL_CNT='1' AND BAL>'1' THEN
                                        UPDATE STMT_TBL SET
                                        AGE_CURRENT='1',AGE_30=(BAL-1),DEL_PAY=V_DEL_PAY
                                        WHERE TRUNC(BILL_DATE)='15-JUL-16' AND ACCOUNT_NO=ACCT_NO;
                                ELSIF UPD_NEW_DEL_CNT='2' AND BAL>'2' THEN
                                        UPDATE STMT_TBL SET
                                        AGE_CURRENT='1',AGE_30='1',AGE_60=(BAL-2),DEL_PAY=V_DEL_PAY
                                        WHERE TRUNC(BILL_DATE)='15-JUL-16' AND ACCOUNT_NO=ACCT_NO;
                                ELSIF UPD_NEW_DEL_CNT='3' AND BAL>'3' THEN
                                        UPDATE STMT_TBL SET
                                        AGE_CURRENT='1',AGE_30='1',AGE_60='1',AGE_90=(BAL-3),DEL_PAY=V_DEL_PAY
                                        WHERE TRUNC(BILL_DATE)='15-JUL-16' AND ACCOUNT_NO=ACCT_NO;
                                ELSIF UPD_NEW_DEL_CNT='4' AND BAL>'4' THEN
                                        UPDATE STMT_TBL SET
                                        AGE_CURRENT='1',AGE_30='1',AGE_60='1',AGE_90='1',AGE_120=(BAL-4),DEL_PAY=V_DEL_PAY
                                        WHERE TRUNC(BILL_DATE)='15-JUL-16' AND ACCOUNT_NO=ACCT_NO;
                                ELSIF UPD_NEW_DEL_CNT='5' AND BAL>'5' THEN
                                        UPDATE STMT_TBL SET
                                        AGE_CURRENT='1',AGE_30='1',AGE_60='1',AGE_90='1',AGE_120='1',AGE_150=(BAL-5),DEL_PAY=V_DEL_PAY
                                        WHERE TRUNC(BILL_DATE)='15-JUL-16' AND ACCOUNT_NO=ACCT_NO;
                                ELSIF UPD_NEW_DEL_CNT='6' AND BAL>'6' THEN
                                        UPDATE STMT_TBL SET
                                        AGE_CURRENT='1',AGE_30='1',AGE_60='1',AGE_90='1',AGE_120='1',AGE_150='1',AGE_180=(BAL-6),DEL_PAY=V_DEL_PAY
                                        WHERE TRUNC(BILL_DATE)='15-JUL-16' AND ACCOUNT_NO=ACCT_NO;
                                ELSIF UPD_NEW_DEL_CNT='7' AND BAL>'7' THEN
                                        UPDATE STMT_TBL SET
                                        AGE_CURRENT='1',AGE_30='1',AGE_60='1',AGE_90='1',AGE_120='1',AGE_150='1',AGE_180='1',AGE_210=(BAL-7),DEL_PAY=V_DEL_PAY
                                        WHERE TRUNC(BILL_DATE)='15-JUL-16' AND ACCOUNT_NO=ACCT_NO;
                                ELSIF UPD_NEW_DEL_CNT>'7' AND BAL>'8' THEN
                                        UPDATE STMT_TBL SET
                                        AGE_CURRENT='1',AGE_30='1',AGE_60='1',AGE_90='1',AGE_120='1',AGE_150='1',AGE_180='1',AGE_210='1',AGE_ABOVE_210=(BAL-8),DEL_PAY=V_DEL_PAY
                                        WHERE TRUNC(BILL_DATE)='15-JUL-16' AND ACCOUNT_NO=ACCT_NO;
                                ELSIF UPD_NEW_DEL_CNT='1' THEN
                                        UPDATE STMT_TBL SET
                                        AGE_30=BAL,DEL_PAY=V_DEL_PAY
                                        WHERE TRUNC(BILL_DATE)='15-JUL-16' AND ACCOUNT_NO=ACCT_NO;
                                ELSIF UPD_NEW_DEL_CNT='2' THEN
                                        UPDATE STMT_TBL SET
                                        AGE_60=BAL,DEL_PAY=V_DEL_PAY
                                        WHERE TRUNC(BILL_DATE)='15-JUL-16' AND ACCOUNT_NO=ACCT_NO;
                                ELSIF UPD_NEW_DEL_CNT='3' THEN
                                        UPDATE STMT_TBL SET
                                        AGE_90=BAL,DEL_PAY=V_DEL_PAY
                                        WHERE TRUNC(BILL_DATE)='15-JUL-16' AND ACCOUNT_NO=ACCT_NO;
                                ELSIF UPD_NEW_DEL_CNT='4' THEN
                                        UPDATE STMT_TBL SET
                                        AGE_120=BAL,DEL_PAY=V_DEL_PAY
                                        WHERE TRUNC(BILL_DATE)='15-JUL-16' AND ACCOUNT_NO=ACCT_NO;
                                ELSIF UPD_NEW_DEL_CNT='5' THEN
                                        UPDATE STMT_TBL SET
                                        AGE_150=BAL,DEL_PAY=V_DEL_PAY
                                        WHERE TRUNC(BILL_DATE)='15-JUL-16' AND ACCOUNT_NO=ACCT_NO;
                                ELSIF UPD_NEW_DEL_CNT='6' THEN
                                        UPDATE STMT_TBL SET
                                        AGE_180=BAL,DEL_PAY=V_DEL_PAY
                                        WHERE TRUNC(BILL_DATE)='15-JUL-16' AND ACCOUNT_NO=ACCT_NO;
                                ELSIF UPD_NEW_DEL_CNT='7' THEN
                                        UPDATE STMT_TBL SET
                                        AGE_210=BAL,DEL_PAY=V_DEL_PAY
                                        WHERE TRUNC(BILL_DATE)='15-JUL-16' AND ACCOUNT_NO=ACCT_NO;
                                ELSIF UPD_NEW_DEL_CNT>'7' THEN
                                        UPDATE STMT_TBL SET
                                        AGE_ABOVE_210=BAL,DEL_PAY=V_DEL_PAY
                                        WHERE TRUNC(BILL_DATE)='15-JUL-16' AND ACCOUNT_NO=ACCT_NO;
                                ELSE
                                        DBMS_OUTPUT.PUT_LINE('ELSE CASE ACCOUNT NO IS : '||ACCT_NO);
                                END IF;
                ELSE
                                UPDATE
                                        STMT_TBL
                                SET
                                        DEL_FLAG = 'F',DEL_PAY=UPD_NEW_MIN_DUE
                                WHERE
                                        TRUNC(BILL_DATE)='15-JUL-16' AND
                                        ACCOUNT_NO=ACCT_NO;
																			
                END IF;

                        --COMMIT;

                        END LOOP;
        --)
                        CLOSE ACCOUNTS_CURSOR;
        END;
        /

