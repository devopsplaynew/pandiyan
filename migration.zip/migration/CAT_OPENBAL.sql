set time on;
set timi on;
set serveroutput on;
Declare
	
	v_card_acct varchar2(100):=null;
	v_updatedopenbal varchar2(100):=null;
	v_migbal varchar2(100):=null;
	v_currbal varchar2(100):=null;
	icnt number:=0;
	icnt1 number:=0;
	icnt2 number:=0;
	Vfrom_dt date;
Begin

for c1 in (select card_acct,rowid from CAT_OPENBAL where status_flag='N') loop
		v_card_acct :=c1.card_acct;
		
		update card_acct_txn set card_acct_openbal=(select credit_limit from cr_lmt_txn where refno=v_card_acct) where card_acct=v_card_acct;
		
		--select card_acct_bal into v_currbal from card_account_master where card_acct=v_card_acct;
	
	icnt :=0;
	
		for i in (	select 		card_acct_openbal,CARD_ACCT_AMOUNT,DRCR_FLAG,system_resp_code,txn_code,type_of_details,rowid 
					from 		card_acct_Txn 
					where 		CARD_ACCT = v_card_acct 
					order by 	maker_dttm) loop

					if icnt = 0 then

							if i.system_resp_code =00 then
								select 	to_number(nvl(card_acct_openbal,0))+ to_number(decode(drcr_flag,'D','-'||CARD_ACCT_AMOUNT,'C',CARD_ACCT_AMOUNT))
								into 	v_updatedopenbal
								from 	card_acct_Txn 
								where 	rowid=i.rowid;
							else
								select 	to_number(nvl(card_acct_openbal,0))
								into 	v_updatedopenbal
								from 	card_acct_Txn 
								where 	rowid=i.rowid;
							end if;
							--dbms_output.put_line ('from 1 record :'||v_updatedopenbal);
					else
					
							dbms_output.put_line ('update record:'||v_updatedopenbal||'~'||i.card_acct_openbal||'~'||i.CARD_ACCT_AMOUNT||'~'||i.DRCR_FLAG||'~'||i.txn_code||'~'||i.type_of_details||'~'||i.system_resp_code);
							update card_acct_Txn set card_acct_openbal=v_updatedopenbal where rowid=i.rowid;

							if i.system_resp_code ='00' then
								select 	to_number(v_updatedopenbal)+ to_number(decode(drcr_flag,'D','-'||CARD_ACCT_AMOUNT,'C',CARD_ACCT_AMOUNT))
								into 	v_updatedopenbal
								from 	card_acct_Txn 
								where 	rowid=i.rowid;
								--dbms_output.put_line ('from 2 record :'||v_updatedopenbal);
							else
								v_updatedopenbal:=v_updatedopenbal;
							end if;

					end if;

		icnt:=icnt+1;			
		update CAT_OPENBAL set status_flag='Y' where rowid=c1.rowid;
		--commit;
		end loop;
		icnt2:=icnt2+1;		

	--Commit;
end loop;
dbms_output.put_line ('Total acct count :'||icnt2);

dbms_output.put_line ('Running Balance updation completed');

end;
/

