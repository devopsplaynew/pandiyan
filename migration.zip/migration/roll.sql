delete from CARD_ACCOUNT_MASTER;

delete from carD_account_master_wk;

delete carD_master;

delete from customer_master;

delete from cardacct_carD_link;

delete from cr_lmt_txn;

update mig_carD_master set mig_flag='N';
update mig_bill_feE_tbl set mig_flag='N';
update mig_accounts_master set mig_flag='N';
update mig_customer_master set mig_flag='N';
update mig_used_tbl set mig_flag='N';

delete from carD_master_wk;

delete from customer_master_wk;
update mig_crd_host  set mig_flag='N' where mig_flag='Y';
update mig_stmt_tbl set mig_flag='N' where mig_flag='Y';
update mig_bill_fee_tbl set mig_flag='N' where mig_flag='Y';
delete from stmt_tbl;
delete from fintxn_unsettle_history;
delete from fintxn_unsettle;
delete from txn_details;
delete from carD_acct_txn;
update mig_crd_host set mig_flag='N';
update mig_bill_fee_tbl set mig_flag='N' where mig_flag='Y';
update mig_stmt_tbl set mig_flag='N' where mig_flag='Y';
