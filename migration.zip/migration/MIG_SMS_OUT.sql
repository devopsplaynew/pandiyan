set serveroutput on
declare

v_rowid  			varchar2(30);
v_cnt 				number;
v_cin				varchar2(30);
V_ERRMSG			varchar2(3000);	
v_mail				varchar2(60);
p_mail				varchar2(60);	
cursor sms_cursor is select rowid,cin from mig_sms_out where nvl(mig_flag,'N')='N';

begin

open sms_cursor;

loop

fetch sms_cursor into v_rowid,V_cin;

if sms_cursor%notfound then exit;

end if;

begin
select MAIL_TO,P_MAILID into v_mail,p_mail from mig_customer_master where cin=v_cin;
exception
when no_data_found then
 V_ERRMSG        := substr(SQLERRM,1,100);
dbms_output.PUT_LINE('NO DATA FOUND WHILE PROCESSING MIG_CUSTOMER_MASTER ['||v_rowid||'-'||V_ERRMSG||']');

when others then
 V_ERRMSG        := substr(SQLERRM,1,100);
dbms_output.PUT_LINE('ERROR CAUGHT WHILE PROCESSING MIG_CUSTOMER_MASTER ['||v_rowid||'-'||V_ERRMSG||']');
end;

insert into sms_out 
(CARD_NO,MSG_DATE,FAX_NO,EMAIL_ID,MOBILE_NO,MESSAGE,APPL,FETCH_FLAG,MAILFROM,MAILTO,MAILCC,MAILBCC,SUBJECT,APPCODE,AGENCY_NAME,
DETAILS,TXN_TYPE,TXN_REF_NO,RETRY_COUNT,RESDTTM,SENT_STATUS,DELIVERY_STATUS,REQSTATUSDTTM,TEMPLATE_ID,UNIQUE_ID,INBOUND_MESSAGE_ID,
REQDTTM,IN_MESSAGE,OUT_MESSAGE,MOBILENO,CIN,SMSG,IN_DATE)
(select CARD_NO,IN_DATE,'',p_mail,MOBILENO,RMSG,'SMS','C','',v_mail,'','','','CREDIT','MIGUSER','','','','1',
IN_DATE,'C',nvl(APPL,'OFFLINE'),sysdate,sms_id,GUID,SMS_SEQ,IN_DATE,'',SMSG,MOBILENO,CIN,SMSG,IN_DATE from mig_sms_out where rowid=v_rowid);

update mig_sms_out set mig_flag='Y' where rowid=v_rowid;

end loop;

exception

when others then
 V_ERRMSG        := substr(SQLERRM,1,100);
dbms_output.PUT_LINE('ERROR CAUGHT WHILE PROCESSING SMS_OUT ['||v_rowid||'-'||V_ERRMSG||']');

close sms_cursor;

end;

/
