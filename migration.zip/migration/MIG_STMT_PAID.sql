

SET SERVEROUTPUT ON
DECLARE

PRIMACCT        VARCHAR2(50):=null;

STCARD		VARCHAR2(50):=null;
STACC		VARCHAR2(50):=null;
STTYPE		VARCHAR2(50):=null;

STLOCAL		NUMBER:=0;
STBAL		NUMBER:=0;
STREMAIN	NUMBER:=0;
STINT		NUMBER:=0;
STBALINT	NUMBER:=0;
STREMINT	NUMBER:=0;

STREWARD	VARCHAR2(50):=null;
STCCY		VARCHAR2(50):=null;
STBILLDT	DATE;
STDUEDT		DATE;


CURSOR PRIMACC IS SELECT DISTINCT ACC_NO FROM BILL_FEE_TBL where substr(Bill_Card_No,1,8)='&Bin';

CURSOR STMT_CURSOR IS SELECT BILL_CARD_NO,ACC_NO, TXN_TYPE, 
SUM(NVL(LOCAL_AMT,0)), sum(NVL(BAL_AMT,0)), sum(NVL(REMAIN_AMT,0)), sum(NVL(INT_AMT,0)), sum(NVL(BAL_INT_AMT,0)), sum(NVL(REMAIN_INT_AMT,0)), sum(NVL(REWARD_POINTS,0)), LOCAL_CCY, trunc(BILL_DATE), trunc(DUE_DATE)  
from BILL_FEE_TBl 
where ACC_NO=PRIMACCT and txn_type not in ('DEP','REFUN','RCHRG_CA','RCHRG_PUR') and bill_date is NOT NULL 
GROUP BY BILL_CARD_NO,ACC_NO,TXN_TYPE,LOCAL_CCY, trunc(BILL_DATE), trunc(DUE_DATE);


BEGIN
OPEN PRIMACC;


LOOP
--(
        FETCH PRIMACC INTO PRIMACCT;
        IF (PRIMACC%NOTFOUND) THEN EXIT; END IF;

                DBMS_OUTPUT.PUT_LINE('ACC_NO : '||PRIMACCT);

OPEN STMT_CURSOR;
                LOOP
                --(
                        FETCH STMT_CURSOR INTO STCARD,STACC,STTYPE,STLOCAL, STBAL, STREMAIN, STINT, STBALINT, STREMINT, STREWARD, STCCY, STBILLDT, STDUEDT;
                        EXIT WHEN STMT_CURSOR%NOTFOUND;


        --(STMT PAID Insert

                                        INSERT INTO
                                                STMT_PAID_TBL
						(
						BILL_CARD_NO,
						CARD_NO, 
						ACC_NO, 
						TYPE, 
						TXN_AMT, 
						BAL_AMT, 
						REMAIN_AMT, 
						INT_AMT, 
						BAL_INT_AMT, 
						REMAIN_INT_AMT, 
						REWARD_POINTS, 
						TXN_CCY, 
						BILL_DATE, 
						DUE_DATE 
                                                )
                                       VALUES
						(
						STCARD,
						STCARD,
						STACC,
						STTYPE,
						STLOCAL, 
						STBAL, 
						STREMAIN, 
						STINT, 
						STBALINT, 
						STREMINT, 
						STREWARD, 
						STCCY, 
						STBILLDT, 
						STDUEDT
						);
                --)
--)
        END LOOP;
        CLOSE STMT_CURSOR;
                

        END LOOP;
    CLOSE PRIMACC;

commit;

    
END;
/

