
set serveroutput on
declare

v_card varchar2(30);
v_ROWID varchar2(30);
V_ERRMSG varchar2(3000);
V_ACC varchar2(30);
v_cnt number(5);

cursor overlmt_cursor is select distinct carD_no,ROWID from mig_OVERLIMIT_TB where nvl(mig_flag,'N')='N';

begin 

open overlmt_cursor;

loop

fetch overlmt_cursor into v_card,v_ROWID;

if overlmt_cursor%notfound then exit;

end if;

begin

select count(*) into v_cnt from MIG_ACCOUNTS_MASTER WHERE CARD_NO=V_CARD;

if v_cnt>0 then

SELECT DISTINCT ACC_NO INTO V_ACC FROM MIG_ACCOUNTS_MASTER WHERE CARD_NO=V_CARD;

else

dbms_output.put_line('No records available in mig_accounts_master '||v_card);

end if;

INSERT INTO OVERLIMIT_TB (REFNO,ENTRY_DT,FROM_DT,TO_DT,CARD_NO,AMOUNT,AMT_FLAG,REMARKS,DEL_FLG,DEL_DATE,STATUS_FLG,SUPP_CRD_FLG,PER_CASH_AMT,AUTH_ID,AUTH_DATE,
MAKER_ID,MAKER_DATE,FEE,TE_AMT,REJECT_REASON,CONSENT_DT,CONSENT_MODE,CONSENT_TYPE,CONSENT_REJREASON,ACCOUNT_NO,ACCT_CRCY)
(SELECT REFNO,ENTRY_DT,FROM_DT,TO_DT,CARD_NO,AMOUNT,AMT_FLAG,REMARKS,DEL_FLG,DEL_DATE,STATUS_FLG,SUPP_CRD_FLG,PER_CASH_AMT,AUTH_ID,AUTH_DATE,
MAKER_ID,MAKER_DATE,'','','','','','','',V_ACC,'356' from MIG_OVERLIMIT_TB WHERE ROWID=v_ROWID );

EXCEPTION 

WHEN OTHERS THEN
 V_ERRMSG        := substr(SQLERRM,1,100);
dbms_output.PUT_LINE('ERROR CAUGHT WHILE PROCESSING OVERLIMIT_TB ['||V_ERRMSG||']');

end;

update mig_OVERLIMIT_TB set mig_flag='Y' where rowid=v_ROWID;

--commit;

end loop;

close overlmt_cursor;

end;

/


