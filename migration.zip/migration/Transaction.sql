SET SERVEROUTPUT ON
DECLARE

TYPE C_CUR IS REF CURSOR;
STMTTBL_CUR     C_CUR;
TYPE    temp_typ is table of varchar2(4000);

                                Rwid_Ty                         temp_typ;
                                Crd_Ty                          temp_typ;
                                Acc_ty                          temp_typ;
                                bDte_ty                         temp_typ;
                                TTYPE_TY                        temp_typ;
                                MERC_TY                         temp_typ;
                                AUTH_TY                         temp_typ;
                                CHARG_TY                        temp_typ;
                                DEL_TY                          temp_typ;
                                MIN_TY                          temp_typ;
                                BDATE                           temp_typ;
                                v_RowId                 varchar2(4000):=null;
                                v_Card                  varchar2(4000):=null;
                                v_StmtNo                varchar2(4000):=null;
                                v_BillDt                varchar2(4000):=null;
                                V_ERRMSG                varchar2(4000):=null;
                                V_TABLE_NAME    varchar2(4000):=null;
                                v_TxnRefNo              varchar2(4000):=null;
                                v_oldcnt                NUMBER:=0;
                                v_newcnt                NUMBER:=0;
                                v_status                NUMBER:=0;
                                V_TXN_TYPE      VARCHAR2(4000) := NULL;
                                v_RefNo                 VARCHAR2(4000);
                                V_TXN_AMT               VARCHAR2(20);
                                V_BAL_AMT               VARCHAR2(20);
                                V_INT_AMT               VARCHAR2(20);
                                V_BAL_INT_AMT   VARCHAR2(20);
                                V_REMAIN_INT_AMT VARCHAR2(20);
                                V_REMAIN_AMT    VARCHAR2(20);
                                V_COUNT                 NUMBER(10);
                                V_CUR_INT               VARCHAR2(20);
                                V_DEL_CNT               varchar2(5);
                                V_MIN_DUE               VARCHAR2(20);
                                V_AGE_CURRENT   VARCHAR2(20) :=0;
                                V_AGE_30                VARCHAR2(20):=0;
                                V_AGE_60                VARCHAR2(20):=0;
                                V_AGE_90                VARCHAR2(20):=0;
                                V_AGE_120               VARCHAR2(20):=0;
                                V_AGE_150               VARCHAR2(20):=0;
                                V_AGE_180               VARCHAR2(20):=0;
                                V_AGE_210               VARCHAR2(20):=0;
                                V_AGE_ABOVE_210 VARCHAR2(20):=0;
                                V_MAXBILLDATE   DATE;

                v_CardNo                        VARCHAR2(50):=null;
                v_TypeOfDetails                         VARCHAR2(4000):=null;
                v_TxnDetails                            VARCHAR2(4000):=null;
                v_FeeTxnDetails                         VARCHAR2(4000):=null;
                v_SubFeeTxnDetails                      VARCHAR2(4000):=null;
                v_DelFeeTxnDetails                      VARCHAR2(4000):=null;
                v_MakerId                       VARCHAR2(20):=null;
                v_RecStatus                     VARCHAR2(20):=null;
                ADDONCARD                               VARCHAR2(30):=null;
                V_OLDCARD                               VARCHAR2(30):=null;
                V_CARD_NO                               VARCHAR2(30):=null;

                                V_RWID                                                                  VARCHAR(20);
                                v_tab                                                                   VARCHAR(50);
                                V_ACC                                                                   VARCHAR2(15);
                                V_BILLDATE                                                      DATE;
                                V_MERC_ID                                                       VARCHAR2(17);
                                V_AUTH                                                                  VARCHAR2(20);
                                V_CHRGTYPE                                                      VARCHAR2(5);
                                V_TXNCODE                                                               VARCHAR2(10);
                                V_TXN_REF_NO                                                    VARCHAR(50);
                                v_BillSeqNo                                                     VARCHAR(50);
                v_MakerDateTime                         VARCHAR2(50):=null;
                v_SysRespCode                           VARCHAR2(50):=null;
                v_CardAcct                              VARCHAR2(50):=null;
                v_ChnCode                               VARCHAR2(50):=null;
                v_TxnDateTime                           VARCHAR2(50):=null;
                v_BrCode                                VARCHAR2(50):=null;
                v_PaymentMode                           VARCHAR2(50):=null;
                v_PaymentDetails                        VARCHAR2(2000);
                v_TxnAmt                                        VARCHAR2(50):=null;
                v_FeeAmt                                        VARCHAR2(50):=null;
                v_SubFeeAmt                                     VARCHAR2(50):=null;
                v_DelFeeAmt                                     VARCHAR2(50):=null;
                v_TxnCcy                                        VARCHAR2(1000):=null;
                v_CardAcctAmt                           VARCHAR2(50):=null;
                v_IndvCardAcctAmt                       VARCHAR2(50):=null;
                v_RRNo                                          VARCHAR2(50):=null;
                v_CardAcctCcy                           VARCHAR2(50):=null;
                v_ExgRate                                       VARCHAR2(50):=null;
                v_TempExgRate                           VARCHAR2(50):=null;
                ErrorData                                       VARCHAR2(1000):=null;
                v_IndvTxnCurr                           VARCHAR2(1000):=null;
                v_IndvTxnAmt                            VARCHAR2(1000):=null;
                v_IndvTypeOfDetails                     VARCHAR2(1000):=null;
                v_TransCode                                     VARCHAR2(1000):=null;
                v_IndvTransCode                         VARCHAR2(1000):=null;
                v_IndvCardAcctCcy                       VARCHAR2(1000):=null;
                v_ErrorDesc                             VARCHAR2(2000):=null;
                v_emvdata                               VARCHAR2(2000):=null;
                v_TerminalID                            VARCHAR2(50):=null;
                v_MsgType                                       VARCHAR2(50):=null;
                v_ProcCode                                      VARCHAR2(50):=null;
                v_DeviceType                            VARCHAR2(50):=null;
                v_OfusFlag                                      VARCHAR2(50):=null;
                v_SysTraceNo                            VARCHAR2(50):=null;
                v_AgentType                                     VARCHAR2(50):=null;
                v_SettlCcy                                      VARCHAR2(50):=null;
                v_SettlAmt                                      VARCHAR2(50):=null;
                v_BatchNo                                       VARCHAR2(50):=null;
                v_AuthId                                        VARCHAR2(50):=null;
                v_DelivInst                                     VARCHAR2(50):=null;
                v_PosEntry_Mode                         VARCHAR2(50):=null;
                v_AcqInstId                                     VARCHAR2(50):=null;
                v_ExpiryDate                            VARCHAR2(30):=null;
                v_LimitCode                                     VARCHAR2(50):=null;
                v_FeeCode                                       VARCHAR2(50):=null;
                v_MerchandId                            VARCHAR2(50):=null;
                v_MerchantName                          VARCHAR2(500):=null;
                v_MerchantLocCode                       VARCHAR2(50):=null;
                v_MerchantCity                          VARCHAR2(100):=null;
                v_ATMAcSel                      VARCHAR2(50):=null;
                v_RPIData                       VARCHAR2(50):=null;
                v_Remarks                       VARCHAR2(4000):=null;
                v_TempRemarks                           VARCHAR2(4000):=null;
                v_IndvRemarks                           VARCHAR2(4000);
                v_PackRefNo                     VARCHAR2(50):=null;
                v_FileRefNo                     VARCHAR2(50):=null;
                v_MCC                           VARCHAR2(50):=null;
                v_BankRefNo                     VARCHAR2(50):=null;
                v_SettFlg                               VARCHAR2(50):=null;
                v_SettFlg1                              VARCHAR2(50):=null;
                v_CardAcctCurr                          VARCHAR2(1000):=null;
                v_Cin                           VARCHAR2(20):=null;
                v_Cin1                          VARCHAR2(20):=null;
                                c_cnt                                                   number;
                v_CardAcctOpenBal                       VARCHAR2(50):=null;
                v_SubTxnCode                            VARCHAR2(20):=null;
                v_SystemRespCode                        VARCHAR2(1000):=null;
                v_bill_flag                             VARCHAR2(1000):=null;
                v_process_flag                          VARCHAR2(1000):=null;
                v_CurrDecl                      number:=0;
                i_Count                         number:=0;
                ErrorCode                       number;
                v_IndvDrCrFlag                          VARCHAR2(30):=null;
                i_TxnCount                      number(3):=0;
                i_Order                         number(3):=0;
                v_SysReqDttm                            VARCHAR2(1000):=null;
                v_AcqRefNo                      VARCHAR2(1000):=null;
                v_BaseIBillAmt                          number:=0;
                v_TotalFeeAmt                           number:=0;
                v_Merc_Name                     VARCHAR2(1000):=null;
                v_Merc_Loc                      VARCHAR2(1000):=null;
                v_Merc_city                     VARCHAR2(1000):=null;
                v_Msg_type                      VARCHAR2(1000):=null;
                v_Device_Type                           VARCHAR2(1000):=null;
                v_Sys_Trace_no                          VARCHAR2(1000):=null;
                v_POS_Entry                             VARCHAR2(1000):=null;
                v_Exp_dt                                VARCHAR2(1000):=null;
                v_Agent_type                            VARCHAR2(1000):=null;
                v_BaseIBillCcy                          VARCHAR2(4000):=null;
                v_SrcConvRate                           VARCHAR2(4000):=null;
                v_DestConvRate                          VARCHAR2(4000):=null;
                v_bill_conv                             VARCHAR2(4000):=null;
                v_MulticcyFlag                          VARCHAR2(40):=null;
                v_TotalTxnAmt                           VARCHAR2(1000):=null;
                v_TxnIndvCurr                           VARCHAR2(1000):=null;
                v_TotalBillAmt                          VARCHAR2(1000):=null;
                v_Acq_Id                                VARCHAR2(1000):=null;
                V_PRD_CODE                              VARCHAR2(1000):=null;
                v_Reversalflg                           VARCHAR2(3):=null;
                v_ChargeType                            VARCHAR2(40):=null;
                v_PosConCode                            VARCHAR2(40):=null;
                V_TOD                                   VARCHAR2(40);
                V_ORIGINAL_TXNAMT                       VARCHAR2(15);
                V_SETTLE_DATE                           DATE;
                V_CARD_TYPE                             VARCHAR2(2);
                V_CHARGES                               VARCHAR2(15);
                V_ACCT                                  VARCHAR2(20);
                CARDCOUNT                               number:=0;
                V_TYPEOFDETAILS1                        VARCHAR2(15):=null;
                V_Prog                                  VARCHAR2(20):=null;

                CURSOR CARD_CUR IS SELECT CARD_NO, CIN FROM MIG_CARD_MASTER;
                CURSOR CRD_CUR(V_CARD_NO VARCHAR2) IS SELECT R.*,R.ROWID FROM MIG_CRD_HOST R WHERE CARD_NO = V_CARD_NO AND NVL(MIG_FLAG,'N')='N';
                                CURSOR BILL_CURSOR IS SELECT ROWID,BILL_CARD_NO,ACC_NO,BILL_DATE,TXN_TYPE,MERC_ID,AUTHID,CHRG_TYPE FROM MIG_BILL_FEE_TBL WHERE
                                NVL(MIG_FLAG,'N')='N' ORDER BY ACC_NO;


                R1_CARD CARD_CUR%ROWTYPE;
                R2_CRD CRD_CUR%ROWTYPE;

 BEGIN

 OPEN CARD_CUR;

                LOOP
                --(
                FETCH CARD_CUR INTO R1_CARD;
                EXIT WHEN CARD_CUR%NOTFOUND;

                BEGIN
                OPEN CRD_CUR(R1_CARD.CARD_NO);
                LOOP
                --(
                FETCH CRD_CUR INTO R2_CRD;
                EXIT WHEN CRD_CUR%NOTFOUND;

                        DBMS_OUTPUT.PUT_LINE('CARD_NO:'||V_CARD_NO);
                v_ExgRate                       := '1';
                v_RecStatus         := 'CA';
                v_AgentType         := 'ICI';
                v_CardAcctCcy       := '356';
                v_MakerId           := 'MIGUSER01';
                v_BrCode            := '';
                --v_LimitCode       := 'NO_DATA';
                v_FeeCode           := '';
                v_DelivInst         := '';
                v_MCC               := R2_CRD.CHRG_TYPE;
                v_PaymentDetails    := '';
                v_BatchNo           := '';
                v_OfusFlag          := '';
                v_FileRefNo         := '';
                v_RPIData           := '';
                v_ATMAcSel          := '';
                v_ErrorDesc         := R2_CRD.ERROR_REASON;
                v_emvdata           := '';
                v_CardAcct          := R2_CRD.AC_NO;
                v_AcqInstId         := R2_CRD.ACQ_INSTITUTION_ID_CODE;
                --v_Remarks         := 'CAL'; --APPROVED, SETTLED ETC;
                v_AuthId            := R2_CRD.AUTHID;
                v_CardAcctAmt       := R2_CRD.BILLING_AMT;
                --v_BankRefNo       := R2_CRD.BILLING_CCY;

                v_MerchantName      := R2_CRD.CARD_ACCEPTOR_NAME_LOCATION;
                v_MerchantLocCode   := '';
                v_PackRefNo         := ''; --CARD_MASTER_WK;
                v_CardNo            := R2_CRD.CARD_NO;
                v_ExpiryDate        := R2_CRD.EXP_DATE;
                v_PaymentMode       := 'From Card Account';
                v_MerchandId        := R2_CRD.MERCHANT_ID;
                v_PosEntry_Mode     := R2_CRD.POS_ENTRY_CODE;
                v_ProcCode          := R2_CRD.PROC_CODE;
                --v_DeviceType        := R2_CRD.SRC_AGENT_TYPE;
                v_MsgType           := R2_CRD.REQ_MSG_TYPE;
                v_SysRespCode       := R2_CRD.RESPONSE_CODE;
                v_RRNo              := R2_CRD.RET_REF_NO;
                v_SettlAmt          := R2_CRD.SETTLEMENT_AMT;
                v_SettlCcy          := R2_CRD.SETTLEMENT_CCY;
                v_SysTraceNo        := R2_CRD.SRC_SYSTEM_TRACE_NO;
                v_TerminalID        := R2_CRD.TERMINAL_ID;
                v_TransCode         := R2_CRD.TRANS_CODE;
                v_TxnAmt            := R2_CRD.TXN_AMOUNT;
                v_TxnCcy            := R2_CRD.TXN_CCY;--INR
                v_MakerDateTime     := R2_CRD.TXN_DATE;
                v_TxnDateTime       := to_char(R2_CRD.TXN_DATE,'DD-MM-YYYY HH24:MI:SS');
                v_TxnRefNo          := R2_CRD.UNIQUE_ID;
                v_SettFlg           := R2_CRD.SETTLEMENT_FLAG;
                v_CardAcctCurr      :='356';
                v_SystemRespCode    := R2_CRD.RESPONSE_CODE;
                v_IndvDrCrFlag      :='D';
                v_CardAcctOpenBal   := 'NULL';
                v_Cin               := V_CIN1;
                v_ChargeType        := R2_CRD.CHRG_TYPE;
                v_PosConCode        := R2_CRD.POS_CONDITION_CODE;
                v_Merc_Name         := v_MerchantName;
                v_Merc_Loc          := v_MerchantLocCode;
                v_Merc_city         := v_MerchantCity;
                v_Msg_type          := v_MsgType;
                v_Sys_Trace_no      := v_SysTraceNo;
                v_POS_Entry         := v_PosEntry_Mode;
                v_Acq_Id            := v_AcqInstId;
                v_Exp_dt            := v_ExpiryDate;
                v_SysReqDttm        := R2_CRD.SYSTEM_AUTH_DTTIME;
                v_AcqRefNo          := R2_CRD.ACQR_REF_NO;
                v_Agent_type        := v_AgentType;
                v_BaseIBillCcy      := R2_CRD.BILLING_CCY;
                v_CHARGES       := R2_CRD.CHARGES;
                v_SrcConvRate       := '';
                v_DestConvRate      := '';
                v_bill_conv         := '';
                v_MulticcyFlag      := 'SC';
                v_TotalBillAmt      := R2_CRD.BILLING_AMT;
                v_TotalTxnAmt       := v_TxnAmt;
                v_TxnIndvCurr       := v_TxnCcy;
                v_Reversalflg       := R2_CRD.REVERSAL_FLAG;
               -- V_TOD             := R2_CRD.TOD;
                V_ORIGINAL_TXNAMT   := R2_CRD.ORIGINAL_TXN_AMT;
                V_CARD_TYPE         := R2_CRD.CARD_TYPE;
                v_bill_flag         := 'N';
                v_process_flag      := 'Y';
                V_Prog              := R2_CRD.PRG_NAME;

                BEGIN
                SELECT TO_NUMBER(v_TotalBillAmt) INTO v_BaseIBillAmt FROM DUAL;
                EXCEPTION WHEN OTHERS THEN
                ErrorData:=substr(SQLERRM,1,100);
                ErrorCode:=SQLCODE;

                END;

                SELECT UPPER(SUBSTR(v_MerchantName,-2,2)) INTO v_MerchantCity FROM DUAL;

               -- v_TypeOfDetails := V_TOD;
                --v_IndvTypeOfDetails:= v_TypeOfDetails;
                v_IndvTransCode:= v_TransCode;
                i_TxnCount := 1;
                v_IndvTxnAmt:=v_TxnAmt;
                v_IndvTxnCurr:=v_TxnCcy;
                v_IndvCardAcctAmt:=v_CardAcctAmt;
                v_IndvCardAcctCcy:=v_CardAcctCcy;

		if v_Reversalflg is null then
			v_Reversalflg:='N';
		else
			v_Reversalflg:='Y';
		end if;


                if (v_SettFlg='Y') then
                        V_TYPEOFDETAILS1:='T|F|';
		elsif(v_SettFlg='Y' and v_Reversalflg='Y') then
			V_TYPEOFDETAILS1:='T|F|R|RF|';
                elsif (v_SettFlg='S') then
                        V_TYPEOFDETAILS1:='S|F|';
                elsif (v_SettFlg='R' and V_Prog is not null) then
                        V_TYPEOFDETAILS1:='T|F|TR|RF|';
                elsif (v_SettFlg='R') then
                        V_TYPEOFDETAILS1:='T|F|RL|FRL|';
                else
                        V_TYPEOFDETAILS1:='';
                end if;


                CASE
                WHEN v_ChargeType = '6011' THEN v_ChnCode:= 'CHN1';
                WHEN v_ChargeType <> '6011' AND v_PosConCode = '59' THEN v_ChnCode:= 'CHN4';
                WHEN v_ChargeType <> '6011' AND v_PosConCode <> '59' THEN v_ChnCode:= 'CHN2';
                ELSE v_ChnCode:= 'CHN2';
                END CASE;

                CASE
                WHEN v_ChargeType = '6011' THEN v_DeviceType:= 'ATM';
                WHEN v_ChargeType <> '6011' AND v_PosConCode = '59' THEN v_DeviceType:= 'ECOM';
                WHEN v_ChargeType <> '6011' AND v_PosConCode <> '59' THEN v_DeviceType:= 'POS';
                ELSE v_DeviceType:= 'POS';
                END CASE;
                v_Device_Type           := v_DeviceType;

                BEGIN

                SELECT CIN INTO v_Cin FROM CARD_MASTER WHERE CARD_NO = v_CardNo;

                SELECT COUNT(*) INTO C_CNT FROM CARDACCT_CARD_LINK WHERE CIN=V_CIN;

             IF C_CNT>0 THEN

                SELECT CARD_ACCT INTO V_ACCT FROM CARDACCT_CARD_LINK WHERE CIN=V_CIN;

             ELSE
                CARDCOUNT:=1;
                V_CARD:=V_CARD_NO;
                     while (CARDCOUNT>=1)
                     loop
                             SELECT COUNT(*) into CARDCOUNT  FROM PARENTCHILD WHERE PARENTCARD=V_CARD;
                             SELECT ADDONCARD INTO V_OLDCARD FROM PARENTCHILD WHERE PARENTCARD=V_CARD;
                             V_CARD:=V_OLDCARD;
                             SELECT COUNT(*) into CARDCOUNT  FROM PARENTCHILD WHERE PARENTCARD=V_CARD;
                     end loop;

                     SELECT CARD_ACCT INTO V_ACCT FROM CARDACCT_CARD_LINK WHERE CARD_NO=V_CARD;

             END IF;

                        SELECT PRD_CODE INTO  V_PRD_CODE FROM CARD_ACCOUNT_MASTER WHERE CARD_ACCT = V_ACCT;

                EXCEPTION
                WHEN NO_DATA_FOUND THEN
                v_Cin := '';
                V_PRD_CODE              := '';
                ErrorData:=substr(SQLERRM,1,100);
                ErrorCode:=SQLCODE;

                END;

                while length(V_TYPEOFDETAILS1)>=0
                loop
                --(
                v_IndvTypeOfDetails:=substr(V_TYPEOFDETAILS1,1,instr(V_TYPEOFDETAILS1,'|',1)-1);
                DBMS_OUTPUT.PUT_LINE('V_TYPEOFDETAILS1:'||V_TYPEOFDETAILS1||' v_IndvTypeOfDetails:'||v_IndvTypeOfDetails);

                if(v_IndvTypeOfDetails='F') then
                v_IndvCardAcctAmt:=v_CHARGES;
                else
                v_IndvCardAcctAmt:=v_CardAcctAmt;
                end if;


                select count(*) into i_Order from TXN_DETAILS where TXN_REF_NO=v_TxnRefNo;
                I_ORDER := I_ORDER+1;
                v_CardAcctOpenBal :='0';
               -- SELECT DECODE(V_TOD,'T','01','S','01','F','02') INTO v_SubTxnCode FROM DUAL;
                        DBMS_OUTPUT.PUT_LINE('CARD_NO:'||V_CARD_NO||'v_SubTxnCode:'||v_SubTxnCode||'V_TYPEOFDETAILS1:'||V_TYPEOFDETAILS1||' v_IndvTypeOfDetails:'||v_IndvTypeOfDetails);

                SELECT DECODE(v_SettFlg1,'Y','Pending','S','Settled','T','Settled','R','Reversed','RF','Fee Reversed','RL','Released','FRL','Fee Released','TR','Reversed','TF','Fee Reversed')
                        INTO v_IndvRemarks FROM DUAL;

                v_TxnDetails:=v_RRNo||'|'||v_CardNo||'|'||v_SysRespCode||'|'||v_CardAcct||'|'||v_ChnCode||'|'||v_TxnDateTime||'|'||
                                v_BrCode||'|'||v_PaymentMode||'|'||v_PaymentDetails||'|'||v_IndvTxnAmt||'|'||v_IndvTxnCurr||'|'||v_IndvCardAcctAmt||'|'||
                                v_BaseIBillCcy||'|'||v_ExgRate||'|'||v_TerminalID||'|'||v_MsgType||'|'||v_ProcCode||'|'||v_DeviceType||'|'||v_OfusFlag
                                ||'|'||v_SysTraceNo||'|'||v_AgentType||'|'||v_SettlCcy||'|'||v_SettlAmt||'|'||v_BatchNo||'|'||v_AuthId||'|'||v_PosEntry_Mode
                                ||'|'||v_AcqInstId||'|'||v_ExpiryDate||'|'||v_LimitCode||'|'||v_FeeCode||'|'||v_MerchandId||'|'||v_MerchantName||'|'||
                                v_MerchantLocCode||'|'||v_MerchantCity||'|'||v_ATMAcSel||'|'||v_RPIData||'|'||v_IndvRemarks||'|'||v_PackRefNo||'|'||
                                v_FileRefNo||'|'||v_MCC||'|'||v_DelivInst||'|'||v_emvdata;
                                dbms_output.put_line('card_no '||'-'||v_CardNo||'-'||'Settle_flag '||v_SettFlg);

                --IF v_SettFlg1 in('T','S') THEN

                -- INSERTING VALUES INTO TXN_DETAILS

                INSERT INTO TXN_DETAILS(TXN_REF_NO, TYPE_OF_DETAILS, REC_SEQ_NO, TXN_CODE, TXN_DETAILS, MAKER_ID, MAKER_DTTM, PAYMENT_MODE, PAYMENT_DETAILS, REC_STATUS, REMARKS, TXN_DTTM, BANK_DTTM, TXN_ORDER, ERROR_DESC, BANK_REF_NO,AUTHID)
                values(v_RRNo, v_IndvTypeOfDetails, i_TxnCount, v_IndvTransCode, v_TxnDetails, v_MakerId, to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'), v_PaymentMode, v_PaymentDetails, v_RecStatus, v_IndvRemarks,to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'), to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'), i_Order, v_ErrorDesc,null,v_AuthId);

                -- INSERTING VALUES INTO CARD_ACCT_TXN

                INSERT INTO CARD_ACCT_TXN(CARD_ACCT, CIN, CARD_NO, CARD_ACCT_CCY, CARD_ACCT_OPENBAL, CARD_ACCT_AMOUNT, DRCR_FLAG, TYPE_OF_DETAILS,
                SUB_TXN_CODE, TXN_CODE, TXN_REF_NO, MAKER_ID, MAKER_DTTM, REC_STATUS, TXN_DTTM, SYS_REQ_DTTM, BANK_DTTM, TXN_AMT, TXN_CRCY, REMARKS,
                TXN_ORDER, RRNO, SYSTEM_RESP_CODE,BILL_FLAG,PROCESS_FLAG) values(v_CardAcct, v_Cin, v_CardNo, v_CardAcctCurr, v_CardAcctOpenBal,
                v_IndvCardAcctAmt, v_IndvDrCrFlag, v_IndvTypeOfDetails, v_SubTxnCode, v_IndvTransCode, v_RRNo, v_MakerId,
                to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'), v_RecStatus, to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'),
                to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'), to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'), v_IndvTxnAmt,
                v_IndvTxnCurr, v_IndvRemarks, i_Order, v_RRNo, v_SystemRespCode,v_bill_flag,v_process_flag);


                -- INSERTING VALUES INTO FINTXN_UNSETTLE

                --if v_SettFlg1 not in('T') then
                if v_SettFlg1 in('S') then
                INSERT INTO FINTXN_UNSETTLE_HISTORY(UNIQUEREFNO, ACCOUNT_NO, CARD_NO, BILL_CCY, BILL_AMT, DEBIT_FLAG, TXN_AMT, TXN_CCY,ME_NAME, ME_LOC_CODE,
                ME_CITY, RRNO, MSGTYPE, DEVICE_TYPE, SYS_TRACE_NO, POS_ENTRY_MODE, ACQ_INST_ID, EXP_DATE, DEBIT_RESPONSE_CODE, PROCCODE, TXNREQDTTIME,
                SYSTEM_REQ_DTTIME, TXN_CHARGES, CHRG_TYPE, TXNRESPDTTIME, ACQR_REF_NO,AGENTTYPE,OFFUSFLG,BASE1_BILL_CCY,BASE1_BILL_AMT,SRC_CONV_RATE,
                DEST_CONV_RATE,BILL_CONV_RATE,MULTI_CCY_FLAG,CHANNEL_NAME,MERCHANT_ID,SETTLE_FLAG,ORIGINAL_TXN_AMT,AUTHID,SETTLE_DATE,PROCESS_FLG,
                SETTLE_AMT,SETTLE_CCY,CARD_TYPE,ACC_CCY) values(v_RRNo,v_CardAcct, v_CardNo, v_BaseIBillCcy, v_TotalBillAmt, v_IndvDrCrFlag,
                v_TotalTxnAmt, v_TxnIndvCurr, v_Merc_Name, v_Merc_Loc, v_Merc_city, v_RRNo, v_Msg_type, v_Device_Type, v_Sys_Trace_no, v_POS_Entry,
                v_Acq_Id, v_Exp_dt, v_SysRespCode, v_ProcCode, to_date(v_TxnDateTime,'DD-MM-YYYY HH24:MI:SS'), v_SysReqDttm, v_TotalFeeAmt, v_MCC,
                to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'), v_AcqRefNo,v_Agent_type,v_OfusFlag,v_BaseIBillCcy,v_BaseIBillAmt,v_SrcConvRate,
                v_DestConvRate,v_bill_conv,v_MulticcyFlag,v_ChnCode,v_MerchandId,v_SettFlg,V_ORIGINAL_TXNAMT,v_AuthId,V_SETTLE_DATE,v_process_flag,
                v_SettlAmt,v_SettlCcy,V_CARD_TYPE,v_CardAcctCurr);

                /*ELSE
                -- INSERTING VALUES INTO TXN_DETAILS---AUTH---
                INSERT INTO TXN_DETAILS(TXN_REF_NO, TYPE_OF_DETAILS, REC_SEQ_NO, TXN_CODE, TXN_DETAILS, MAKER_ID, MAKER_DTTM, PAYMENT_MODE,
                PAYMENT_DETAILS, REC_STATUS, REMARKS, TXN_DTTM, BANK_DTTM, TXN_ORDER, ERROR_DESC, BANK_REF_NO,AUTHID) values(v_RRNo,
                v_IndvTypeOfDetails, i_TxnCount, v_IndvTransCode, v_TxnDetails, v_MakerId, to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'),
                v_PaymentMode, v_PaymentDetails, v_RecStatus, v_IndvRemarks, to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'),
                to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'), i_Order, v_ErrorDesc, null,v_AuthId);

                -- INSERTING VALUES INTO T_CARD_ACCT_TXN---AUTH---
                INSERT INTO CARD_ACCT_TXN(CARD_ACCT, CIN, CARD_NO, CARD_ACCT_CCY, CARD_ACCT_OPENBAL, CARD_ACCT_AMOUNT, DRCR_FLAG, TYPE_OF_DETAILS,
                SUB_TXN_CODE, TXN_CODE, TXN_REF_NO, MAKER_ID, MAKER_DTTM, REC_STATUS, TXN_DTTM, SYS_REQ_DTTM, BANK_DTTM, TXN_AMT, TXN_CRCY, REMARKS,
                TXN_ORDER, RRNO, SYSTEM_RESP_CODE,BILL_FLAG,PROCESS_FLAG) values(v_CardAcct, v_Cin, v_CardNo, v_CardAcctCurr, v_CardAcctOpenBal,
                v_IndvCardAcctAmt, v_IndvDrCrFlag, v_IndvTypeOfDetails, v_SubTxnCode, v_IndvTransCode, v_RRNo, v_MakerId, to_date(v_MakerDateTime,
                'DD-MM-YYYY HH24:MI:SS'), v_RecStatus, to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'),
                to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'), to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'), v_IndvTxnAmt, v_IndvTxnCurr,
                v_IndvRemarks, i_Order, v_RRNo, v_SystemRespCode,v_bill_flag,v_process_flag);

                                -- INSERTING VALUES INTO T_CARD_ACCT_TXN---FEE---
                                INSERT INTO TXN_DETAILS(TXN_REF_NO, TYPE_OF_DETAILS, REC_SEQ_NO, TXN_CODE, TXN_DETAILS, MAKER_ID, MAKER_DTTM, PAYMENT_MODE,
                PAYMENT_DETAILS, REC_STATUS, REMARKS, TXN_DTTM, BANK_DTTM, TXN_ORDER, ERROR_DESC, BANK_REF_NO,AUTHID) values(v_RRNo,
                'F', i_TxnCount, v_IndvTransCode, v_TxnDetails, v_MakerId, to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'),
                v_PaymentMode, v_PaymentDetails, v_RecStatus, v_IndvRemarks, to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'),
                to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'), i_Order, v_ErrorDesc, null,v_AuthId);

                -- INSERTING VALUES INTO T_CARD_ACCT_TXN---FEE---
                INSERT INTO CARD_ACCT_TXN(CARD_ACCT, CIN, CARD_NO, CARD_ACCT_CCY, CARD_ACCT_OPENBAL, CARD_ACCT_AMOUNT, DRCR_FLAG, TYPE_OF_DETAILS,
                SUB_TXN_CODE, TXN_CODE, TXN_REF_NO, MAKER_ID, MAKER_DTTM, REC_STATUS, TXN_DTTM, SYS_REQ_DTTM, BANK_DTTM, TXN_AMT, TXN_CRCY, REMARKS,
                TXN_ORDER, RRNO, SYSTEM_RESP_CODE,BILL_FLAG,PROCESS_FLAG) values(v_CardAcct, v_Cin, v_CardNo, v_CardAcctCurr, v_CardAcctOpenBal,
                v_CHARGES, v_IndvDrCrFlag, 'F', v_SubTxnCode, v_IndvTransCode, v_RRNo, v_MakerId, to_date(v_MakerDateTime,
                'DD-MM-YYYY HH24:MI:SS'), v_RecStatus, to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'),
                to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'), to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'), v_CHARGES, v_IndvTxnCurr,
                v_IndvRemarks, i_Order, v_RRNo, v_SystemRespCode,v_bill_flag,v_process_flag);*/


                elsif v_SettFlg1 in('T') then
                                 INSERT INTO FINTXN_UNSETTLE (UNIQUEREFNO, ACCOUNT_NO, CARD_NO, BILL_CCY, BILL_AMT, DEBIT_FLAG, TXN_AMT, TXN_CCY,ME_NAME, ME_LOC_CODE,
                ME_CITY, RRNO, MSGTYPE, DEVICE_TYPE, SYS_TRACE_NO, POS_ENTRY_MODE, ACQ_INST_ID, EXP_DATE, DEBIT_RESPONSE_CODE, PROCCODE, TXNREQDTTIME,
                SYSTEM_REQ_DTTIME, TXN_CHARGES, CHRG_TYPE, TXNRESPDTTIME, ACQR_REF_NO,AGENTTYPE,OFFUSFLG,BASE1_BILL_CCY,BASE1_BILL_AMT,SRC_CONV_RATE,
                DEST_CONV_RATE,BILL_CONV_RATE,MULTI_CCY_FLAG,CHANNEL_NAME,MERCHANT_ID,SETTLE_FLAG,ORIGINAL_TXN_AMT,AUTHID,SETTLE_DATE,PROCESS_FLG,
                SETTLE_AMT,SETTLE_CCY,CARD_TYPE,ACC_CCY) values(v_RRNo,v_CardAcct, v_CardNo, v_BaseIBillCcy, v_TotalBillAmt, v_IndvDrCrFlag,
                v_TotalTxnAmt, v_TxnIndvCurr, v_Merc_Name, v_Merc_Loc, v_Merc_city, v_RRNo, v_Msg_type, v_Device_Type, v_Sys_Trace_no, v_POS_Entry,
                v_Acq_Id, v_Exp_dt, v_SysRespCode, v_ProcCode, to_date(v_TxnDateTime,'DD-MM-YYYY HH24:MI:SS'), v_SysReqDttm, v_TotalFeeAmt, v_MCC,
                to_date(v_MakerDateTime,'DD-MM-YYYY HH24:MI:SS'), v_AcqRefNo,v_Agent_type,v_OfusFlag,v_BaseIBillCcy,v_BaseIBillAmt,v_SrcConvRate,
                v_DestConvRate,v_bill_conv,v_MulticcyFlag,v_ChnCode,v_MerchandId,v_SettFlg,V_ORIGINAL_TXNAMT,v_AuthId,V_SETTLE_DATE,v_process_flag,
                v_SettlAmt,v_SettlCcy,V_CARD_TYPE,v_CardAcctCurr);

                END IF;


                         V_TYPEOFDETAILS1:=substr(V_TYPEOFDETAILS1,instr(V_TYPEOFDETAILS1,'|',1)+1);
                --)
                end loop;

                UPDATE MIG_CRD_HOST SET MIG_FLAG='Y' where ROWID=R2_CRD.ROWID;
                COMMIT;

                 END LOOP;
                --)
                close CRD_CUR;
                END;

                END LOOP;
                --)
                close CARD_CUR;

OPEN BILL_CURSOR;
--(
LOOP

FETCH BILL_CURSOR INTO V_RWID,V_CARD,V_ACC,V_BILLDATE,V_TXN_TYPE,V_MERC_ID, V_AUTH, V_CHRGTYPE;

IF BILL_CURSOR%NOTFOUND THEN EXIT;

END IF;

                        SELECT GenTxnRefnoPkg.GenTxnRefno('909090','909090') into V_TXN_REF_NO from dual;

                        dbms_output.put_line('txn_ref_no' ||V_TXN_REF_NO);

                        CASE
                        WHEN V_TXN_TYPE = 'PUR' AND V_AUTH = 'ADJ' THEN V_TXNCODE :='100332';
                        WHEN V_TXN_TYPE = 'PUR' AND V_AUTH <> 'ADJ' THEN V_TXNCODE :='000000';
                        WHEN V_TXN_TYPE = 'CHRG_PUR'  THEN V_TXNCODE :='000001';
                        WHEN V_TXN_TYPE = 'REFUN'  THEN V_TXNCODE :='800009';
                        WHEN V_TXN_TYPE = 'RCHRG_PUR'  THEN V_TXNCODE :='000001';
                        WHEN V_TXN_TYPE = 'CA' AND V_AUTH = 'ADJ' THEN V_TXNCODE :='100332';
                        WHEN V_TXN_TYPE = 'CA' AND V_AUTH <> 'ADJ' AND V_CHRGTYPE = '6011' THEN V_TXNCODE :='010000';
                        WHEN V_TXN_TYPE = 'CA' AND V_AUTH <> 'ADJ' AND V_CHRGTYPE = '6010' THEN V_TXNCODE :='200005';
                        WHEN V_TXN_TYPE = 'CAFEE' AND V_CHRGTYPE = '6011' THEN V_TXNCODE :='000008';
                        WHEN V_TXN_TYPE = 'CAFEE' AND V_CHRGTYPE = '6010' THEN V_TXNCODE :='000008';
                        WHEN V_TXN_TYPE = 'CHRG_CA' AND V_CHRGTYPE = '6011' THEN V_TXNCODE :='100006';
                        WHEN V_TXN_TYPE = 'CHRG_CA' AND V_CHRGTYPE = '6010' THEN V_TXNCODE :='200006';
                        WHEN V_TXN_TYPE = 'CHRG_BI' AND V_CHRGTYPE = '6011' THEN V_TXNCODE :='310001';
                        WHEN V_TXN_TYPE = 'CHRG_BI' AND V_CHRGTYPE = '6010' THEN V_TXNCODE :='300001';
                        WHEN V_TXN_TYPE = 'GOVT FEE' AND V_MERC_ID = 'IT' THEN V_TXNCODE :='101011';
                        WHEN V_TXN_TYPE = 'GOVT FEE' AND V_MERC_ID <> 'SC' THEN V_TXNCODE :='101010';
                        WHEN V_TXN_TYPE = 'GOVT FEE' AND V_MERC_ID = 'EC' THEN V_TXNCODE :='101012';
                    WHEN V_TXN_TYPE = 'DEP'  THEN V_TXNCODE :='100114';
                        WHEN V_TXN_TYPE = 'FEE' AND V_MERC_ID = 'OF' THEN V_TXNCODE :='100905';
                        WHEN V_TXN_TYPE = 'FEE' AND V_MERC_ID = '03' THEN V_TXNCODE :='100426';
                        WHEN V_TXN_TYPE = 'FEE' AND V_MERC_ID = '08' THEN V_TXNCODE :='100406';
                        WHEN V_TXN_TYPE = 'FEE' AND V_MERC_ID = '10' THEN V_TXNCODE :='100437';
                        WHEN V_TXN_TYPE = 'FEE' AND V_MERC_ID = '05' THEN V_TXNCODE :='100428';
                        WHEN V_TXN_TYPE = 'FEE' AND V_MERC_ID = 'LF' THEN V_TXNCODE :='100903';
                        WHEN V_TXN_TYPE = 'FEE' AND V_AUTH = 'ADJ' THEN V_TXNCODE :='OTHFEE';
                        ELSE
                                V_TXNCODE:=V_TXNCODE;
                        END CASE;

                        SELECT BFT_SEQ_NO.NEXTVAL INTO v_BillSeqNo FROM DUAL;

                        IF V_TXN_TYPE = 'CHRG_CA' THEN
                                V_TXN_TYPE := 'FEE';
                                V_MERC_ID := 'CHRG_CA';
                        ELSIF V_TXN_TYPE = 'CHRG_BI' THEN
                                V_TXN_TYPE := 'FEE';
                                V_MERC_ID := 'CHRG_BI';
                        ELSIF V_TXN_TYPE = 'CHRG_PUR' THEN
                                V_TXN_TYPE := 'FEE';
                                V_MERC_ID := 'CHRG_PUR';
                        ELSIF V_TXN_TYPE = 'GOVT FEE' THEN
                                V_TXN_TYPE := 'FEE';
                                V_MERC_ID := V_MERC_ID;
                        ELSIF V_TXN_TYPE = 'RCHRG_PUR' THEN
                                V_TXN_TYPE := 'REFUN';
                                V_MERC_ID := V_MERC_ID;
                        ELSIF V_TXN_TYPE = 'RCHRG_CA' THEN
                                V_TXN_TYPE := 'REFUN';
                                V_MERC_ID := V_MERC_ID;
                        ELSE
                                V_TXN_TYPE := V_TXN_TYPE;
                                V_MERC_ID := V_MERC_ID;
                        END IF;

BEGIN

IF V_BILLDATE IS NOT NULL THEN

INSERT INTO BILL_FEE_TBL (ACC_NO,ACQ_INS_ID_CODE,AGENT_TYPE,AUTHID,BAL_AMT,BAL_INT_AMT,BILL_AMT,BILL_CARD_NO,BILL_CCY,BILL_DATE,BILL_FLAG,CARD_NO,CHARGES,CHRG_TYPE,
CUR_INT,DEPOSIT_DATE,DIFF_INT_AMT,DRCR_FLAG,DUE_DATE,DUE_FLAG,EMI_FLAG,EMI_INS_AMT,EMI_REFNO,EMI_TYPE,IN_DATE,INT_AMT,INT_DATE,
LAST_BAL_AMT,LAST_BAL_INT_AMT,LOCAL_AMT,LOCAL_CCY,MARKUP_PER,ME_LOCATION,ME_NAME,MERC_ID,MIN_DUE,NEW_INT,NEW_INT_AMT,O_ACC_NO,
REF_NO,REMAIN_AMT,REMAIN_INT_AMT,REWARD_FLAG,REWARD_POINTS,SEQ_NO,SETT_IND,SETTLE_DATE,STMT_ID,SUSP_FLAG,SYS_TRACE_NO,TEMP_INT,
TEMP_INT_AMT,TERM_ID,TRANS_CODE,TXN_AMT,TXN_CCY,TXN_CODE,TXN_DATE,TXN_NAME,TXN_REF_NO,TXN_TYPE)
(select ACC_NO,'',AGENT_TYPE,AUTHID,LAST_BAL_AMT,LAST_BAL_INT_AMT,BILL_AMT,BILL_CARD_NO,BILL_CCY,BILL_DATE,BILL_FLAG,CARD_NO,CHARGES,CHRG_TYPE,'',
DEPOSIT_DATE,'',DR_CR_FLAG,DUE_DATE,'','','','','',IN_DATE,INT_AMT,INT_DATE,LAST_BAL_AMT,LAST_BAL_INT_AMT,LOCAL_AMT,LOCAL_CCY,
MARKUP_PER,ME_LOCATION,ME_NAME,V_MERC_ID,'','','','',REF_NO,BAL_AMT,BAL_INT_AMT,REWARD_FLAG,REWARD_POINTS,v_BillSeqNo,SETT_IND,
SETTLE_DATE,'','',SYS_TRACE_NO,TEMP_INT,TEMP_INT,TERM_ID,TRANS_CODE,TXN_AMT,TXN_CCY,V_TXNCODE,TXN_DATE,V_TXNCODE,V_TXN_REF_NO,V_TXN_TYPE
FROM MIG_BILL_FEE_TBL WHERE BILL_DATE IS NOT NULL AND NVL(MIG_FLAG,'N')='N' AND ROWID = V_RWID);

ELSE

INSERT INTO BILL_FEE_TBL (ACC_NO,ACQ_INS_ID_CODE,AGENT_TYPE,AUTHID,BAL_AMT,BAL_INT_AMT,BILL_AMT,BILL_CARD_NO,BILL_CCY,BILL_DATE,BILL_FLAG,CARD_NO,CHARGES,CHRG_TYPE,
CUR_INT,DEPOSIT_DATE,DIFF_INT_AMT,DRCR_FLAG,DUE_DATE,DUE_FLAG,EMI_FLAG,EMI_INS_AMT,EMI_REFNO,EMI_TYPE,IN_DATE,INT_AMT,INT_DATE,
LAST_BAL_AMT,LAST_BAL_INT_AMT,LOCAL_AMT,LOCAL_CCY,MARKUP_PER,ME_LOCATION,ME_NAME,MERC_ID,MIN_DUE,NEW_INT,NEW_INT_AMT,O_ACC_NO,
REF_NO,REMAIN_AMT,REMAIN_INT_AMT,REWARD_FLAG,REWARD_POINTS,SEQ_NO,SETT_IND,SETTLE_DATE,STMT_ID,SUSP_FLAG,SYS_TRACE_NO,TEMP_INT,
TEMP_INT_AMT,TERM_ID,TRANS_CODE,TXN_AMT,TXN_CCY,TXN_CODE,TXN_DATE,TXN_NAME,TXN_REF_NO,TXN_TYPE)
(select ACC_NO,'',AGENT_TYPE,AUTHID,LOCAL_AMT,INT_AMT,BILL_AMT,BILL_CARD_NO,BILL_CCY,BILL_DATE,BILL_FLAG,CARD_NO,CHARGES,CHRG_TYPE,'',
DEPOSIT_DATE,'',DR_CR_FLAG,DUE_DATE,'','','','','',IN_DATE,INT_AMT,INT_DATE,LAST_BAL_AMT,LAST_BAL_INT_AMT,LOCAL_AMT,LOCAL_CCY,
MARKUP_PER,ME_LOCATION,ME_NAME,V_MERC_ID,'','','','',REF_NO,BAL_AMT,BAL_INT_AMT,REWARD_FLAG,REWARD_POINTS,v_BillSeqNo,SETT_IND,
SETTLE_DATE,'','',SYS_TRACE_NO,TEMP_INT,TEMP_INT,TERM_ID,TRANS_CODE,TXN_AMT,TXN_CCY,V_TXNCODE,TXN_DATE,V_TXNCODE,V_TXN_REF_NO,V_TXN_TYPE
FROM MIG_BILL_FEE_TBL WHERE BILL_DATE IS NULL AND NVL(MIG_FLAG,'N')='N' AND ROWID = V_RWID);

END IF;

EXCEPTION
                                WHEN NO_DATA_FOUND THEN
                                dbms_output.PUT_LINE('DATA NOT AVAIALBLE WHILE PROCESSING BILL_FEE_TBL ['||v_Acc||'] ['||v_Card||'] ['||V_RWID||']');
                                V_ERRMSG:='DATA NOT AVAIALBLE WHILE PROCESSING BILL_FEE_TBL';
                                v_tab:='BILL_FEE_TBL';
                                insert into mig_status values (v_Acc,V_RWID,V_ERRMSG,v_tab);

                                WHEN OTHERS THEN
                                V_ERRMSG        := substr(SQLERRM,1,200);
                                DBMS_OUTPUT.PUT_LINE('ERROR WHILE PROCESSING ['||v_Acc||'] ['||v_Card||'] ['||V_RWID||'] ERROR  ['||V_ERRMSG||']');
                                v_tab:='BILL_FEE_TBL';
                                insert into mig_status values (v_Acc,V_RWID,V_ERRMSG,v_tab);
                        UPDATE MIG_BILL_FEE_TBL SET MIG_FLAG = 'E' WHERE  ROWID = V_RWID AND MIG_FLAG='N';

                        END;

                        UPDATE MIG_BILL_FEE_TBL SET MIG_FLAG = 'Y' WHERE  ROWID = V_RWID AND MIG_FLAG='N';

                        commit;
END LOOP;
--)
CLOSE BILL_CURSOR;

OPEN STMTTBL_CUR FOR
SELECT ROWID,BILL_CARD_NO,ACCOUNT_NO,DEL_CNT,MIN_DUE,trunc(BILL_DATE) FROM MIG_STMT_TBL where nvl(mig_flag,'N')='N'
ORDER BY ACCOUNT_NO;
--(
        LOOP
                FETCH STMTTBL_CUR BULK COLLECT into Rwid_Ty,Crd_Ty,Acc_ty,DEL_TY,MIN_TY,BDATE LIMIT 500;
                exit when Rwid_Ty.COUNT=0;
                for inde in 1 .. Rwid_Ty.COUNT
                LOOP
                        v_RowId := Rwid_Ty(INDE);
                        v_Card  := Crd_Ty(INDE);
                        v_Acc   := Acc_ty(INDE);
                        V_DEL_CNT := DEL_TY(INDE);
                        V_MIN_DUE := MIN_TY(INDE);
                        V_BILLDATE  := BDATE(INDE);

begin
              select max(bill_date) into V_MAXBILLDATE from stmt_tbl where account_no=v_Acc;
exception
when no_data_found then
V_MAXBILLDATE:='';
when others then
  V_ERRMSG        := substr(SQLERRM,1,200);
DBMS_OUTPUT.PUT_LINE('ERROR WHILE PROCESSING MAX BILL_DATE['||v_Acc||'] ['||v_Card||'] ['||v_RowId||'] ERROR  ['||V_ERRMSG||']');
end;


                                V_AGE_CURRENT :=0;
                                V_AGE_30      :=0;
                                V_AGE_60          :=0;
                                V_AGE_90      :=0;
                                V_AGE_120         :=0;
                                V_AGE_150         :=0;
                                V_AGE_180         :=0;
                                V_AGE_210     :=0;
                                V_AGE_ABOVE_210         :=0;

                        IF V_BILLDATE = V_MAXBILLDATE THEN

                                IF V_DEL_CNT = 0 THEN
                                V_AGE_CURRENT := V_MIN_DUE;
                                ELSIF V_DEL_CNT = 1 THEN
                                V_AGE_CURRENT := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_30      := V_MIN_DUE /(V_DEL_CNT+1);
                                ELSIF V_DEL_CNT = 2 THEN
                                V_AGE_CURRENT := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_30      := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_60          := V_MIN_DUE /(V_DEL_CNT+1);
                                ELSIF V_DEL_CNT = 3 THEN
                                V_AGE_CURRENT := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_30      := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_60          := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_90      := V_MIN_DUE /(V_DEL_CNT+1);
                                ELSIF V_DEL_CNT = 4 THEN
                                V_AGE_CURRENT := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_30      := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_60          := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_90      := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_120         := V_MIN_DUE /(V_DEL_CNT+1);
                                ELSIF V_DEL_CNT = 5 THEN
                                V_AGE_CURRENT := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_30      := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_60          := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_90      := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_120         := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_150         := V_MIN_DUE /(V_DEL_CNT+1);
                                ELSIF V_DEL_CNT = 6 THEN
                                V_AGE_CURRENT := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_30      := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_60          := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_90      := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_120         := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_150         := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_180         := V_MIN_DUE /(V_DEL_CNT+1);
                                ELSIF V_DEL_CNT = 7 THEN
                                V_AGE_CURRENT := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_30      := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_60          := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_90      := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_120         := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_150         := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_180         := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_210     := V_MIN_DUE /(V_DEL_CNT+1);
                                ELSIF V_DEL_CNT = 8 THEN
                                V_AGE_CURRENT := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_30      := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_60          := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_90      := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_120         := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_150         := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_180         := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_210     := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_ABOVE_210 := V_MIN_DUE - ((V_MIN_DUE/(V_DEL_CNT+1)) * 8);
                                ELSIF V_DEL_CNT > 8 THEN
                                V_AGE_CURRENT := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_30      := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_60          := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_90      := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_120         := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_150         := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_180         := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_210     := V_MIN_DUE /(V_DEL_CNT+1);
                                V_AGE_ABOVE_210 := V_MIN_DUE - ((V_MIN_DUE/(V_DEL_CNT+1)) * 8);
                                END IF;

                        ELSE

                                V_AGE_CURRENT :=0;
                                V_AGE_30      :=0;
                                V_AGE_60          :=0;
                                V_AGE_90      :=0;
                                V_AGE_120         :=0;
                                V_AGE_150         :=0;
                                V_AGE_180         :=0;
                                V_AGE_210     :=0;
                                V_AGE_ABOVE_210         :=0;
                        END IF;
                               -- DBMS_OUTPUT.PUT_LINE(V_AGE_CURRENT||'|'||V_AGE_30||'|'||V_AGE_60||'|'||V_AGE_90||'|'||V_AGE_120||'|'||V_AGE_150||'|'||V_AGE_180||'|'||V_AGE_210||'|'||V_AGE_ABOVE_210);


                        BEGIN
                                INSERT INTO STMT_TBL (ACCOUNT_NO,AGE_120,AGE_150,AGE_180,AGE_210,AGE_30,AGE_60,AGE_90,AGE_ABOVE_210,AGE_CURRENT,AVL_CASH_LMT,AVL_CR_LMT,BILL_CARD_NO,BILL_DATE,
                                BILL_FLAG,BIRTH_DESC,CA_AMT,CA_CHR,CA_INT,CAFEE_AMT,CAFEE_INT,CARD_NO,CASH_LMT,CASHINHAND,CHRG_AMT,CHRG_INT,CORPORATE_ID,CR_LMT,CUR_CA_INT,
                                CUR_CAFEE_INT,CUR_CHRG_INT,CUR_FEE_INT,CUR_GOVT_FEE_INT,CUR_PUR_INT,DEL_CNT,DEL_CNT_GRP,DEL_FLAG,DEL_PAY,DEPT_ID,DUE_DATE,EMI_BAL_AMT,
                                FEE_AMT,FEE_INT,INVOICE_NO,MIN_DUE,OUTSTANDING,PREV_BILL_DATE,PRINT_FLAG,PUR_AMT,PUR_CHR,PUR_INT,REDEEMED_CURR,REWARD_CLOSE,REWARD_CURR,
                                REWARD_OPEN,REWARD_POINTS,STMT_FLAG,STMT_ID,STMT_TYPE,TOT_OUTSTANDING,TOTAL_POINTS)
                                (SELECT ACCOUNT_NO,V_AGE_120,V_AGE_150,V_AGE_180,V_AGE_210,V_AGE_30,V_AGE_60,V_AGE_90,V_AGE_ABOVE_210,V_AGE_CURRENT,AVL_CASH_LMT,AVL_CR_LMT,BILL_CARD_NO,BILL_DATE,BILL_FLAG,
                                '',CA_AMT,CA_CHR,CA_INT,CAFEE_AMT,CAFEE_INT,CARD_NO,CASH_LMT,CASHINHAND,CHRG_AMT,CHRG_INT,'',CR_LMT,CUR_CA_INT,CUR_CAFEE_INT,CUR_CHRG_INT,
                                (CUR_FEE_INT+CUR_CHRG_INT+CUR_GOVT_FEE_INT),CUR_GOVT_FEE_INT,CUR_PUR_INT,DEL_CNT,'',DEL_FLAG,'','',DUE_DATE,'',(FEE_AMT + CHRG_AMT+GOVT_FEE_AMT),(FEE_INT+CHRG_INT+GOVT_FEE_INT),'',MIN_DUE,OUTSTANDING,PREV_BILL_DATE,
                                'C',PUR_AMT,PUR_CHR,PUR_INT,REDEEMED_CURR,REWARD_CLOSE,REWARD_CURR,REWARD_OPEN,REWARD_POINTS,ST_SUSP_FLAG,STMT_NO,'','',TOTAL_POINTS FROM MIG_STMT_TBL WHERE
                                NVL(MIG_FLAG,'N')='N' and rowid=v_rowid);

                        EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                                dbms_output.PUT_LINE('DATA NOT AVAIALBLE WHILE PROCESSING STMT_TBL ['||v_Acc||'] ['||v_Card||'] ['||v_RowId||']');
                                                                v_tab:='STMT_TBL';
                                                                insert into mig_status values (v_Acc,V_RWID,V_ERRMSG,v_tab);

                        WHEN OTHERS THEN
                                        V_ERRMSG        := substr(SQLERRM,1,200);
                                        DBMS_OUTPUT.PUT_LINE('ERROR WHILE PROCESSING STMT_TBL ['||v_Acc||'] ['||v_Card||'] ['||v_RowId||'] ERROR  ['||V_ERRMSG||']');
                                                                                v_tab:='STMT_TBL';
                                                                                insert into mig_status values (v_Acc,V_RWID,V_ERRMSG,v_tab);

                        END;

                        UPDATE MIG_STMT_TBL SET MIG_FLAG = 'Y' where rowid = v_RowId;

                END LOOP;
                --COMMIT;
        END LOOP;
        close STMTTBL_CUR;
--)
        --COMMIT;
END;
/

