        /**=================TABLE INFORMATION===
        CARD_MASTER
        CARD_MASTER_WK
        CUSTOMER_MASTER
        CUSTOMER_MASTER_WK
        CUSTOMER_MASTER_TEMP
        SI_TB
        SI_TB_TEMP
        USER_ID_MAPPING
        USER_MASTER
        PIN_MASTER
        CARD_ORDER_DETAILS
        INVOICE_MASTER
        INVOICE_TRANS
		CARD_ACCOUNT_MASTER
		CARD_ACCOUNT_MASTER_WK
		CR_LMT_TXN
		CARDACCT_CARD_LINK
		
        ======================================**/

        SET SERVEROUTPUT ON

        DECLARE

        V_PRIM  VARCHAR2(3);
        MIGCARD VARCHAR2(20);
        V_CNT   NUMBER(2);
        V_ROW   NUMBER(10);
        V_ORDERREFNO VARCHAR2(30);
        V_PACKREFNO   VARCHAR2(30);
        V_CIN VARCHAR2(20);
        V_FINACCTYPE VARCHAR2(30);
        V_EMAILFLAG VARCHAR2(10);
        V_MOBILE VARCHAR2(30);
        V_TXNREFNO VARCHAR2(30);
        V_CUSTID VARCHAR2(10);
        V_EMAIL VARCHAR2(50);
        V_ERRMSG VARCHAR2(4000):=NULL;
        V_OffMail VARCHAR2(50);
        V_OffFax VARCHAR2(30);
        V_OffPH VARCHAR2(30);
        V_TMPADDRESS    VARCHAR2(1000);
        V_ADDRESS VARCHAR2(1000);
        V_OFFADDRESS VARCHAR2(1000);
        V_SYSTEM_ID varchar2(20);
        v_user_name varchar2(30);
        v_user varchar2(30);
        V_USER_TYPE varchar2(30);
        V_USER_GROUPS varchar2(30);
         V_USER_STATUS  varchar2(30);
         V_PROD varchar2(10);
         V_BRANCHCODE varchar2(10);
         V_PLACODE varchar2(10);
         V_PRD_NAME varchar2(30);
         V_INVOICEREFNO varchar2(30);
        V_BIN varchar2(30);
        v_card varchar2(20);
        v_acc varchar2(20);
        d_cnt number(20);
        t_cnt number(20);
        b_cnt number(20);
        v_LmtId varchar2(20);
        v_creditlmt varchar2(20);
        v_cashlmt varchar2(20);
        v_telmt varchar2(20);
        v_cashinhand varchar2(20);
        v_cashinhand1 varchar2(20);
        v_noh varchar2(2);
        c_cnt number(2);
        cam_cnt number(2);
        vUSED_CREDIT_LINE  varchar2(20);
        v_UsdCrLmt  varchar2(20);
        v_UsdCsLmt  varchar2(20);
        v_AvlTeLmt varchar2(20);
        v_UsdTeLmt varchar2(20);
        v_AvlCrLmt varchar2(20);
        v_AvlCsLmt varchar2(20);
        V_BALANCE varchar2(20);

        CURSOR ACCT_CUR IS SELECT CIN FROM MIG_CARD_MASTER WHERE MIG_FLAG='N';

        cursor acc_cursor is select distinct acC_no,cin,card_no,noh from mig_accounts_master where nvl(mig_flag,'N')='N' order by acC_no;

        BEGIN

        OPEN ACCT_CUR;

        LOOP

                        FETCH ACCT_CUR INTO MIGCARD;

                                        V_ROW:=ACCT_CUR%ROWCOUNT;

        IF ACCT_CUR%NOTFOUND THEN EXIT;

        END IF;

        BEGIN

                                                                        SELECT LPAD(NVL(ORDER_REF_NO_SEQ.NEXTVAL,'0'),6,'0') INTO V_ORDERREFNO FROM DUAL;

                                                                        SELECT LPAD(PACKREFSEQ.NEXTVAL,12,'0') INTO V_PACKREFNO FROM DUAL;

                                                                        SELECT GENTXNREFNOPKG.GENTXNREFNO('TRSCDE','MIGUSER01') INTO V_TXNREFNO FROM DUAL;

                                                                                                                                        SELECT DISTINCT ACC_NO,CARD_NO INTO V_ACC,V_CARD FROM MIG_CARD_MASTER WHERE CIN=MIGCARD;
                                                                                                                                        dbms_output.put_line(V_ACC||'---'||V_CARD||'---'||MIGCARD);

        BEGIN
                                                                        SELECT SUBSTR(V_CARD,1,8) INTO V_BIN FROM MIG_CARD_MASTER WHERE CIN=MIGCARD;

                                                                        SELECT DECODE(V_BIN,'43280901','GOLD STAFF PRODUCT','43280902','GOLD CUSTOMER PRODUCT','43280801','CLASSIC STAFF PRODUCT','43280802','CLASSIC CUSTOMER PRODUCT','43280903','GLOBAL BHARAT CARD',
                                                                        '43280803','CLASSIC BHARATH','42847901','VISA BUSINESS PRODUCT','42847900','VISA BUSINESS CARD','SUPERVISOR CARD') INTO V_PRD_NAME FROM DUAL;

                                                                        SELECT DECODE(V_BIN,'43280901','GLDSTF','43280902','GLDCST','43280801','CLASTF','43280802','CLACST','43280903','GLBCRD',
                                                                        '43280803','CLABRD','42847901','VISPRD','42847900','VISCRD','NOPPRD') INTO V_PROD FROM DUAL;



        EXCEPTION
                                                                        WHEN NO_DATA_FOUND THEN
                                                                                        dbms_output.PUT_LINE('DATA NOT AVAIALBLE WHILE PROCESSING MIG_CARD_GRP_TB-CARD_MASRER'||V_BIN||'-'||MIGCARD);
                                                                        WHEN OTHERS THEN
                                                                                        V_ERRMSG        := substr(SQLERRM,1,100);
                                                                                        dbms_output.PUT_LINE('ERROR CAUGHT WHILE PROCESSING MIG_CARD_GRP_TB-CARD_MASRER ['||V_ERRMSG||']');


        END ;


        BEGIN

        SELECT PRIM_FLAG INTO V_PRIM FROM MIG_ACCOUNTS_MASTER WHERE CIN=MIGCARD;


        EXCEPTION
                                                                        WHEN NO_DATA_FOUND THEN
                                                                        V_PRIM:='N';

                                                                        WHEN OTHERS THEN
                                                                                        V_ERRMSG        := SUBSTR(SQLERRM,1,100);
                                                                                        DBMS_OUTPUT.PUT_LINE('ERROR CAUGHT WHILE PROCESSING MIG_ACCOUNTS_MASTER ['||V_ERRMSG||']');
        END;


                                         INSERT INTO CARD_MASTER
                                         (ACC_NO,ACCOUNT_NO,ACCOUNT_TYPE,ACT_GRP,ACTIVATION_FLAG,ADC_NO,AMT_CCY,ANNUAL_DATE,APP_NO,ATM_ID,AUTH_DATE,AUTH_ID,AVG_BALANCE,BALANCE_AMT,
                                        BATCH_NO,BILL_DAY,BR_ID,BR_REC_DATE,BRANCH_CODE,BUSINESS_DATE,CARD_DESP_COURIER,CARD_NO,CARD_RETAINED_FLAG,CARD_STATUS,CARD_TYPE,CHECKER_DTTM,
                                        CHECKER_ID,CIN,CLOSE_DATE,CLOSING_DATE,CMS_FLAG,CONV_RATE_REFNO,DESPATCH_STAT,E_STAT,EMB_DATE,FETCH_CD,FILE_NUMBER,GRP_ID,HOT_DATE,HOT_STATUS,
                                        INITIAL_AMT,INITIAL_CCY,INS_FLAG,ISSUE_DATE,IT_EMB_DT,IT_REC_DATE,LAST_TXN_DATE,LOAN_NO,MAIL_DATE,MAKER_DT,MAKER_DTTM,MAKER_ID,MAX_AMOUNT,
                                        MAX_CYCLE,OLD_STATUS,PACKREFNO,PARENTCARD,PIN,PIN_REQ_DT,PLASTIC_CODE,PRIM_FLAG,PROC_DATE,PRODUCT_TYPE,PROXY_NO,RE_AMT,RE_FLAG,RE_INIT_AMT,
                                        REASON,REAUTH,REC_STATUS,RECVD_BY,REF_NO,REG_ID,REJECT_CODE,REMARKS,REN_EMB_STATUS,REN_FLAG,REP_FLAG,RNUMBER,S_NO,SOLD_BY_USERID,STATUS_FLAG,SUP_FLAG,
                                        TDATE,TRANS_AMOUNT,TRANS_CYCLE,TYPEOFCARD,V_FROM_DT,V_THRU_DT,WEB_PIN,WEB_PIN_FLAG,WEB_FLAG)
                                                                                                                                        (SELECT V_ACC,V_ACC,'','','A',ADC_NO,'356',ANNUAL_FEE_DT,(SELECT APP_NO FROM MIG_CUSTOMER_MASTER WHERE CIN=MIGCARD),
                                                                                                                                        ATM_ID,AUTH_DATE,AUTH_ID,'','',V_ORDERREFNO,BILL_DAY,BR_ID,BR_REC_DATE,'','','',CARD_NO,'',CARD_STATUS,CARD_TYPE,SYSDATE,'MIG',CIN,CLOSE_DATE,'',CMS_FLAG,'',DESPATCH_STAT,
                                                                                                                                        E_STAT,EMB_DATE,'','',GRP_ID,HOT_DATE,HOT_STATUS,'','',INS_FLAG,ISSUE_DATE,IT_EMB_DT,IT_REC_DATE,LAST_TXN_DATE,'',MAIL_DATE,'',MAKER_DT,MAKER_ID,MAX_AMOUNT,MAX_CYCLE,OLD_CARD_STATUS,
                                                                                                                                        V_PACKREFNO,'',PIN,PIN_REQ_DT,'',V_PRIM,PROC_DATE,V_PROD,
                                                                                                                                        '','','','','',REAUTH,'CA','','',REG_ID,'','',REN_EMB_STATUS,REN_FLAG,'',RNUMBER,S_NO,'','EC','',TDATE,TRANS_AMOUNT,TRANS_CYCLE,'',V_FROM_DT,V_THRU_DT,
                                                                                                                                        '','','N' FROM MIG_CARD_MASTER WHERE NVL(MIG_FLAG,'N')='N' AND CIN=MIGCARD);

                                                                        INSERT INTO CARD_MASTER_WK
                                                                        (ACC_NO,ACCOUNT_NO,ACCOUNT_TYPE,ACT_GRP,ACTIVATION_CODE,ACTIVATION_FLAG,ADC_NO,AMT_CCY,ANNUAL_DATE,APP_NO,ATM_ID,AUTH_DATE,AUTH_ID,AVG_BALANCE,BALANCE_AMT,
                                                                        BATCH_NO,BILL_DAY,BR_ID,BR_REC_DATE,BRANCH_CODE,BUSINESS_DATE,CARD_DESP_COURIER,CARD_NO,CARD_RETAINED_FLAG,CARD_STATUS,CARD_TYPE,CHECKER_DTTM,CHECKER_ID,CIN,
                                                                        CLOSE_DATE,CLOSING_DATE,CMS_FLAG,CONV_RATE_REFNO,DESPATCH_STAT,E_STAT,EMB_DATE,FETCH_CD,FILE_NUMBER,GRP_ID,HOT_DATE,HOT_STATUS,INITIAL_AMT,INITIAL_CCY,INS_FLAG,
                                                                        ISSUE_DATE,IT_EMB_DT,IT_REC_DATE,LAST_TXN_DATE,LOAN_NO,MAIL_DATE,MAKER_DT,MAKER_DTTM,MAKER_ID,MAX_AMOUNT,MAX_CYCLE,OLD_STATUS,PACKREFNO,PARENTCARD,PIN,PIN_REQ_DT,
                                                                        PINMAILER_STATUS,PLASTIC_CODE,PRIM_FLAG,PROC_DATE,PRODUCT_TYPE,PROXY_NO,RE_AMT,RE_FLAG,RE_INIT_AMT,REASON,REAUTH,REC_STATUS,RECVD_BY,REF_NO,REG_ID,REJECT_CODE,
                                                                        REMARKS,REN_EMB_STATUS,REN_FLAG,REP_FLAG,REPIN_STATUS,RNUMBER,S_NO,SOLD_BY_USERID,STATUS_FLAG,SUP_FLAG,TDATE,TRANS_AMOUNT,TRANS_CYCLE,TYPEOFCARD,V_FROM_DT,
                                                                        V_THRU_DT,WEB_PIN,WEB_PIN_FLAG,WEB_FLAG)
                                                                                                                                        (SELECT V_ACC,V_ACC,'','','A','A',ADC_NO,'356',ANNUAL_FEE_DT,(SELECT APP_NO FROM MIG_CUSTOMER_MASTER WHERE CIN=MIGCARD),
                                                                                                                                        ATM_ID,AUTH_DATE,AUTH_ID,'','',V_ORDERREFNO,BILL_DAY,BR_ID,BR_REC_DATE,'','','',CARD_NO,'',CARD_STATUS,CARD_TYPE,SYSDATE,'MIG',CIN,CLOSE_DATE,
                                                                                                                                        '',CMS_FLAG,'',DESPATCH_STAT,E_STAT,EMB_DATE,'','',GRP_ID,HOT_DATE,HOT_STATUS,'','',INS_FLAG,ISSUE_DATE,IT_EMB_DT,IT_REC_DATE,LAST_TXN_DATE,
                                                                                                                                        '',MAIL_DATE,'',MAKER_DT,MAKER_ID,MAX_AMOUNT,MAX_CYCLE,OLD_CARD_STATUS,V_PACKREFNO,'',PIN,PIN_REQ_DT,'NP','',
                                                                                                                                        V_PRIM,PROC_DATE,V_PROD,'','','','','',REAUTH,'CA','','',REG_ID,'','',
                                                                                                                                        REN_EMB_STATUS,REN_FLAG,'','CA',RNUMBER,S_NO,'','EC','',TDATE,TRANS_AMOUNT,TRANS_CYCLE,'',V_FROM_DT,V_THRU_DT,'','','N' FROM MIG_CARD_MASTER
                                                                                                                                        WHERE NVL(MIG_FLAG,'N')='N' AND CIN=MIGCARD);

                                                                        UPDATE MIG_CARD_MASTER SET MIG_FLAG='Y' WHERE CARD_NO=MIGCARD;


                                        --COMMIT;

        EXCEPTION

                                                                        WHEN NO_DATA_FOUND THEN
                                                                                        DBMS_OUTPUT.PUT_LINE('DATA NOT AVAIALBLE WHILE PROCESSING CARD_MASTER ');
                                                                        WHEN OTHERS THEN
                                                                                        V_ERRMSG        := SUBSTR(SQLERRM,1,100);
                                                                                        DBMS_OUTPUT.PUT_LINE('ERROR CAUGHT WHILE PROCESSING CARD_MASTER ['||V_ERRMSG||']');

        END;


        BEGIN


                                        SELECT LPAD(CUST_ID.NEXTVAL,6,'0') INTO V_CUSTID FROM DUAL;

                                        BEGIN
                                                                        SELECT BNK_ACCTYPE INTO V_FINACCTYPE FROM MIG_CUSTOMER_MASTER WHERE CIN = MIGCARD;

                                                        IF V_FINACCTYPE in ('currentaccount','current','CA','CC','ca','cc','CURRENT')  THEN
                                                                        V_FINACCTYPE := 'Current';
                                                        ELSE
                                                                        V_FINACCTYPE := 'Saving';
                                                        END IF;

                                        EXCEPTION
                                                                        WHEN NO_DATA_FOUND THEN
                                                                                        DBMS_OUTPUT.PUT_LINE('DATA NOT AVAIALBLE WHILE PROCESSING CUSTOMER_MASTER ACCOUNT TYPE ');
                                                                        WHEN OTHERS THEN
                                                                                        V_ERRMSG        := SUBSTR(SQLERRM,1,100);
                                                                                        DBMS_OUTPUT.PUT_LINE('ERROR CAUGHT WHILE PROCESSING CUSTOMER_MASTER ACCOUNT TYPE ['||V_ERRMSG||']');
                                        END;

                                        BEGIN

                                                                        SELECT  MOBILE,EMAIL
                                                                        INTO    V_MOBILE,V_EMAIL
                                                                        FROM    MIG_MAIL_MASTER
                                                                        WHERE   MAIL_ID IN (SELECT  P_MAILID FROM MIG_CUSTOMER_MASTER WHERE CIN = MIGCARD );
                                        EXCEPTION
                                                                        WHEN NO_DATA_FOUND THEN
                                                                                        DBMS_OUTPUT.PUT_LINE('DATA NOT AVAIALBLE WHILE PROCESSING CUSTOMER_MASTER MOBILE,EMAIL ');
                                                                        WHEN OTHERS THEN
                                                                                        V_ERRMSG        := SUBSTR(SQLERRM,1,100);
                                                                                        DBMS_OUTPUT.PUT_LINE('ERROR CAUGHT WHILE PROCESSING CUSTOMER_MASTER MOBILE,EMAIL['||V_ERRMSG||']');
                                        END;

                                BEGIN

                                        SELECT DECODE(EMAIL_FLAG,'Y','YES','N','NO',EMAIL_FLAG) INTO V_EMAILFLAG  FROM MIG_ACCOUNTS_MASTER WHERE CIN =MIGCARD;

                                EXCEPTION
                                                                        WHEN NO_DATA_FOUND THEN
                                                                                        V_EMAILFLAG:='NO';
                                                                        WHEN OTHERS THEN
                                                                                        V_ERRMSG        := SUBSTR(SQLERRM,1,100);
                                                                                        DBMS_OUTPUT.PUT_LINE('ERROR CAUGHT WHILE PROCESSING MIG_ACCOUNTS_MASTER EMAIL['||V_ERRMSG||']');
                                END;

                                                        BEGIN
                                                                        SELECT  NVL(MM.ADD1,'NO_DATA')||'~'||NVL(MM.CITY,'NO_DATA')||'~'||NVL(MM.STATE,'NO_DATA')||'~'||
                                                                        NVL(MM.PIN,'NO_DATA'),CM.OCC_MAILID,CM.OCC_FAX,CM.OCC_PHONE
                                                                        INTO    V_TMPADDRESS,V_OFFMAIL,V_OFFFAX,V_OFFPH
                                                                        FROM    MIG_MAIL_MASTER MM, MIG_CUSTOMER_MASTER CM
                                                                        WHERE   MM.MAIL_ID = CM.M_MAILID AND  CM.CIN = MIGCARD ;

                                                        EXCEPTION
                                                                        WHEN NO_DATA_FOUND THEN
                                                                                        V_TMPADDRESS    := '~~~~';
                                                                                        V_OFFMAIL               := '';
                                                                                        V_OFFFAX                := '';
                                                                                        V_OFFPH                 := '';
                                                                                        DBMS_OUTPUT.PUT_LINE(' DATA NOT AVAILABLE FOR CUSTOMER OFFICE ADDRESS ');
                                                                        WHEN OTHERS THEN
                                                                                        V_ERRMSG        := SUBSTR(SQLERRM,1,100);
                                                                                        DBMS_OUTPUT.PUT_LINE('ERROR CAUGHT WHILE FETCHING CUSTOMER OFFICE ADDRESS ['||V_ERRMSG||']');
                                                        END;

                                                        V_OFFADDRESS    := V_TMPADDRESS;

                                                        BEGIN

                                                                        SELECT  NVL(MM.ADD1,'NO_DATA')||'~'||NVL(MM.CITY,'NO_DATA')||'~'||NVL(MM.STATE,'NO_DATA')||'~'||NVL(MM.PH1,'NO_DATA')||'~'||
                                                                        NVL(MM.PIN,'NO_DATA')||'~'||NVL(CM.VOTER_ID,'NO_DATA')||'~'||NVL(CM.RESIDENCE,'NO_DATA')||'~'||NVL(CM.LEAVE_WITH,'NO_DATA')
                                                                        INTO    V_TMPADDRESS
                                                                        FROM    MIG_MAIL_MASTER MM, MIG_CUSTOMER_MASTER CM
                                                                        WHERE   MM.MAIL_ID = CM.C_MAILID AND  CM.CIN = MIGCARD ;

                                                        EXCEPTION
                                                                        WHEN NO_DATA_FOUND THEN
                                                                                        V_TMPADDRESS    := '~~~~~~~~';
                                                                                        DBMS_OUTPUT.PUT_LINE(' DATA NOT AVAILABLE FOR CUSTOMER  RESIDENCE ADDRESS');
                                                                        WHEN OTHERS THEN
                                                                                        V_ERRMSG        := SUBSTR(SQLERRM,1,100);
                                                                                        DBMS_OUTPUT.PUT_LINE('ERROR CAUGHT WHILE FETCHING CUSTOMER RESIDENCE ADDRESS ['||V_ERRMSG||']');
                                                        END;

                                                        V_ADDRESS       := '|O|'||V_TMPADDRESS;

                                                        BEGIN

                                                                        SELECT  NVL(MM.ADD1,'NO_DATA')||'~'||NVL(MM.CITY,'NO_DATA')||'~'||NVL(MM.STATE,'NO_DATA')||'~'||NVL(MM.PH1,'NO_DATA')||'~'||NVL(MM.PIN,'NO_DATA')||'~'||
                                                                                                                                        NVL(CM.VOTER_ID,'NO_DATA')||'~'||NVL(CM.RESIDENCE,'NO_DATA')||'~'||NVL(CM.LEAVE_WITH,'NO_DATA')
                                                                        INTO    V_TMPADDRESS
                                                                        FROM    MIG_MAIL_MASTER MM, MIG_CUSTOMER_MASTER CM
                                                                        WHERE   MM.MAIL_ID = CM.P_MAILID AND  CM.CIN = MIGCARD ;

                                                        EXCEPTION
                                                                        WHEN NO_DATA_FOUND THEN
                                                                                        V_TMPADDRESS    := '~~~~~~~~';
                                                                                        DBMS_OUTPUT.PUT_LINE(' DATA NOT AVAILABLE FOR CUSTOMER PERMINANT ADDRESS');
                                                                        WHEN OTHERS THEN
                                                                                        V_ERRMSG        := SUBSTR(SQLERRM,1,100);
                                                                                        DBMS_OUTPUT.PUT_LINE('ERROR CAUGHT WHILE FETCHING CUSTOMER PERMINANT ADDRESS ['||V_ERRMSG||']');
                                                        END;

                                                        V_ADDRESS       := V_ADDRESS||'|R|'||V_TMPADDRESS;


                                                                                                        BEGIN
                                                                                                                                        SELECT F_NAME||' '||L_NAME INTO V_USER_NAME FROM MIG_CUSTOMER_MASTER WHERE CIN = MIGCARD ;

                                                                                                        EXCEPTION

                                                                                                                                        WHEN NO_DATA_FOUND THEN
                                                                                                                                                        v_user_name     := '';
                                                                                                                                                        dbms_output.PUT_LINE('DATA NOT AVAIALBLE WHILE FETCHING CUSTOMER NAME ');
                                                                                                                                        WHEN OTHERS THEN
                                                                                                                                                        V_ERRMSG        := substr(SQLERRM,1,100);
                                                                                                                                                        dbms_output.PUT_LINE('ERROR CAUGHT WHILE FETCHING CUSTOMER NAME ['||V_ERRMSG||']');
                                                                                                        END ;


                                        INSERT INTO CUSTOMER_MASTER
                                        (ACCOUNT_TYPE,ADDRESS,ADDRESS_PROOF,AGENCY,ANNUAL_BUSINESS_INC,ANNUAL_SALARY_INC,APP_NO,APPLICABLE_DATE,APPLICATION_DATE,AUTOMOBILE,BANK,BANK_ACC_NUMBER,
                                        BANK_CUSTOMER_RELATION,BANK_LOAN,BIC,BOND_COMPANY,BRANCH_NAME,BRN_BIC,BROKERAGE_FIRM,BUSINESS_INCREMENT,BUSINESS_NAME,C_MAILID,CATG_CODE,CHECKER_DTTM,
                                        CHECKER_ID,CIN,CIN_STATUS,COMPANY_INSTITUTION,CORP_ADDRESS,CORP_TAX_ID,CORPORATE_CUST,CORPORATE_ID,CRDSTMT_DELIVERY,CREDITLIMIT,CREDITLIMIT_ONE,
                                        CURRENT_RESIDING_SINCE,CUST_CATEGORY,CUSTOMER_ID,CUSTOMER_NAME,DATE_OF_INCEPTION,DELIVERY_LOCATION,DEPARTMENT,DEPOSIT_HOUSE,DESIGNATION,DESIRED_NAME,
                                        DOB,DRIVING_LICENSE_ISSUE_PLACE,DRIVING_LICENSE_NO,ECONOMIC_SECTOR,EDU_QUALIFICATION,EMAIL_ID,EMPLOYEE_ID,EMPLOYER,EMPLOYMENT_DATE,EXCHANGE_HOUSE,
                                        EXIST_CUSTOMER,EXPERIENCE,F_NAME,FACTORING,FAMILY_NAME,FILE_ID,FINANCE_BUSINESS,FINANCE_SOCIETY,FINANCIAL_ADDRESS,FREQUENT_FLYER,FREQUENT_FLYER_FLAG,
                                        GENDER,GENERAL_WAREHOUSE,HOLD_OTHERCARDS,HOUSE_OTHERS,HOUSE_OTHERS_FLAG,IDENTIFICATION,IDENTITY_ISSUE_DATE,IDENTITY_ISSUE_PLACE,INSCRIPTION_NUMBER,
                                        INSURANCE_COMPANY,INSURANCE_PREMIUM,INTERNATIONAL,INVESTMENT,JOINING_DATE,KYC_FLAG,L_NAME,LOCAL,LOCATION,M_MAILID,M_NAME,MAIL_TO,MAKER_DTTM,MAKER_ID,
                                        MARITAL_STATUS,MARRIED_NAME,MOBILE_NO,MONTHLY_BILLS,MONTHLY_SALARY_INC,MOTHERS_MAIDEN_NAME,NAME_ON_ID,NATIONALITY,NATURE_OF_BUSINESS,NO_OF_CARDS,
                                        NO_OF_CHILDREN,NO_OF_DEPENDANTS,NO_OF_EMPLOYEES,NOOF_EARNEDPERSONS,NOTARIAL_DEED_DET,O_APP_NO,OBJECTIVE,OFF_SHORE,OFFICE_ADDRESS,OFFICE_EMAIL,
                                        OFFICE_FAX,OFFICE_PHONE,ORDER_REF_NO,ORIGIN_OF_INCOME,ORIGIN_OF_INCOME_OTHERS,OTHER_CARDS_DETAILS,OTHER_INCOME,OTHER_LOCATION,OTHERS_SPECIFY,
                                        P_BANK_BRANCH,P_MAILID,PAN_NO,PARENT_CIN,PASSPORT_COUNTRY,PASSPORT_EXP_DATE,PASSPORT_ISSUE_PLACE,PASSPORT_NO,PAYMENT_MODE,PERIOD_OF_STAY,
                                        PERMANANT_RESIDING_SINCE,PHONE_AH,PHONE_BH,PLACE_BIRTH,PO_BOX,POSITION_HOLD,PRESENT_RESIDENCE,PREVIOUS_ENTITY_DET,PREVIOUS_ENTITY_FLAG,
                                        PRIMARY_RELATION,PROFESSION_BUSINESS,PROPERTY_DETAILS,ADHAR_ID,RATION_CARD_NO,REC_STATUS,RECEIPTS,RECEIVING_ADDRESS,REF_NAME_ONE,
                                        REF_NAME_TWO,REF_ONE_ADDRESS,REF_PHONE_ONE,REF_PHONE_TWO,REF_TWO_ADDRESS,REGIONAL_OFFICE,RELATION,REMARKS,RENT_INCOME,RENT_PAID,RENT_PAYMENT,RES_STATUS,
                                        RO_SAN_REF_NO,SALARY_INC,SEC_ACCESS_CODE,SEC_QUESTION,SEC_QUESTION_ANSWER,SECONDARY_ID,SECURITY_BUSSINESS,SKIP_SCORE,SKIP_SCORE_REASON,SMS_ALERTS,
                                        SPOUSE_DETAILS,TAX_IDENTIFICATION,TOTAL_INC_PER_MONTH,TOTAL_SPENDING_PER_MONTH,TRADE_HOUSE,TXN_REF_NO,TYPE_OF_ORG,VEHICLE_MAKE,VEHICLE_MODEL,VEHICLE_NO,
                                        VEHICLE_PROVIDEDBY,VEHICLE_TYPE,VEHICLE_YEAR,VIP_FLAG,VOTER_ID_NO,WORK_EXPERIENCE,WEB_FLAG)
                                                                        (SELECT V_FINACCTYPE,V_Address,OTHPROF,'','',ANNUALSAL_INC,APP_NO,'',MAKER_DATE,TYPE_OF_VEHICLE,'',FIN_ACC_NO,'',BANK_LOAN,'','',
                                                                        '','','',ANNUALBUS_INC,BUS_AS,C_MAILID,DECODE(SALUT,'MR.','MR.','MRS.','MRS.','MS.','MS.','DR.','DR.','MISS.','MISS.'),AUTH_DATE,AUTH_ID,CIN,
                                                                        'A','','','','','',V_EMAILFLAG,CREDIT_LIMIT,ACC_LIMIT,'','',V_CUSTID,DESIRED_NAME,'',DECODE(MAIL_TO,'OFFICE ADDRESS','OFFICE ADDRESS',
                                                                        'CURRENT ADDRESS','CURRENT ADDRESS','PRESENT ADDRESS','PRESENT ADDRESS'),'','',DESIGNATION,DESIRED_NAME,DOB,'','','',EDU_BACK,V_EMAIL,CUST_EMP_ID,COMP_NAME,'','','Y','',F_NAME,'','','','','','',
                                                                        '','N',DECODE(SEX,'M','MALE','F','FEMALE',SEX),'','','','','PASSPORT',PASS_NUM,'','','','','','','','',L_NAME,'','',M_MAILID,M_NAME,MAIL_TO,MAKER_DATE,MAKER_ID,
                                                                        DECODE(MAR_STAT,'M','MARRIED','S','SINGLE','W','WIDOWER','D','DIVORCED','SINGLE'),SPOUSE_NAME,
                                                                        V_MOBILE,'',MONTHLY_INC,MOTHER_NAME,DESIRED_NAME,NATIONALITY,BUS_NATURE,'','',NO_OF_DEPD,'','','','','','',V_OffAddress,V_OffMail,V_OffFax,V_OffPH,V_ORDERREFNO,'',OTHER_INC_SOURCE,
                                                                        OTH_CR_CARD_NO1,OTHERINCOME,'',OTHER_SPECIFY,'',P_MAILID,PAN_NO,P_CIN,'','','','','','','','','','','','','','','','',
                                                                        PROFESSION,'','','','CA','',CRDSTMT_DELIVERY,REF_NAME1,REF_NAME2,'',REF_PHONE1,'','','',RELATIONSHIP,'',RENT_INC,RENT_PAYMENT,RENT_PAYMENT,
                                                                        '','','','','','',V_ACC,'','','','',SPOUSE_DOB,'',OTH_MONTHLY_INC+MONTHLY_INC,'','',V_TXNREFNO,'',MAKE_VEHICLE,'',VEHICLE_NO,'',TYPE_OF_VEHICLE,'',
                                                                        DECODE(VIP_FLAG,'Y','YES','N','NO'),'','','N' FROM MIG_CUSTOMER_MASTER WHERE CIN=MIGCARD AND NVL(MIG_FLAG,'N')='N');

                                                        INSERT INTO CUSTOMER_MASTER_WK
                                                        (ACCOUNT_TYPE,ADDRESS,ADDRESS_PROOF,AGENCY,ANNUAL_BUSINESS_INC,ANNUAL_SALARY_INC,APP_NO,APPLICATION_DATE,AUTOMOBILE,BANK,BANK_ACC_NUMBER,BANK_CUSTOMER_RELATION,
                                                        BANK_LOAN,BIC,BOND_COMPANY,BRANCH_NAME,BRN_BIC,BROKERAGE_FIRM,BUSINESS_INCREMENT,BUSINESS_NAME,C_MAILID,CATG_CODE,CHECKER_DTTM,CHECKER_ID,CIN,CIN_STATUS,
                                                        COMPANY_INSTITUTION,CORP_ADDRESS,CORP_TAX_ID,CORPORATE_CUST,CORPORATE_ID,CRDSTMT_DELIVERY,CREDITLIMIT,CREDITLIMIT_ONE,CURRENT_RESIDING_SINCE,CUST_CATEGORY,
                                                        CUSTOMER_ID,CUSTOMER_NAME,DATE_OF_INCEPTION,DELIVERY_LOCATION,DEPARTMENT,DEPOSIT_HOUSE,DESIGNATION,DESIRED_NAME,DOB,DRIVING_LICENSE_ISSUE_PLACE,
                                                        DRIVING_LICENSE_NO,ECONOMIC_SECTOR,EDU_QUALIFICATION,EMAIL_ID,EMPLOYEE_ID,EMPLOYER,EMPLOYMENT_DATE,EXCHANGE_HOUSE,EXIST_CUSTOMER,EXPERIENCE,F_NAME,
                                                        FACTORING,FAMILY_NAME,FILE_ID,FINANCE_BUSINESS,FINANCE_SOCIETY,FINANCIAL_ADDRESS,FREQUENT_FLYER,FREQUENT_FLYER_FLAG,GENDER,GENERAL_WAREHOUSE,HOLD_OTHERCARDS,
                                                        HOUSE_OTHERS,HOUSE_OTHERS_FLAG,IDENTIFICATION,IDENTITY_ISSUE_DATE,IDENTITY_ISSUE_PLACE,INSCRIPTION_NUMBER,INSURANCE_COMPANY,INTERNATIONAL,INVESTMENT,
                                                        JOINING_DATE,KYC_FLAG,L_NAME,LOCAL,LOCATION,M_MAILID,M_NAME,MAIL_TO,MAKER_DTTM,MAKER_ID,MARITAL_STATUS,MARRIED_NAME,MOBILE_NO,MONTHLY_BILLS,MONTHLY_SALARY_INC,
                                                        MOTHERS_MAIDEN_NAME,NAME_ON_ID,NATIONALITY,NATURE_OF_BUSINESS,NO_OF_CARDS,NO_OF_CHILDREN,NO_OF_DEPENDANTS,NO_OF_EMPLOYEES,NOOF_EARNEDPERSONS,NOTARIAL_DEED_DET,
                                                        O_APP_NO,OBJECTIVE,OFF_SHORE,OFFICE_ADDRESS,OFFICE_EMAIL,OFFICE_FAX,OFFICE_PHONE,ORDER_REF_NO,ORIGIN_OF_INCOME,ORIGIN_OF_INCOME_OTHERS,OTHER_CARDS_DETAILS,
                                                        OTHER_INCOME,OTHER_LOCATION,OTHERS_SPECIFY,P_BANK_BRANCH,P_MAILID,PAN_NO,PARENT_CIN,PASSPORT_COUNTRY,PASSPORT_EXP_DATE,PASSPORT_ISSUE_PLACE,PASSPORT_NO,
                                                        PAYMENT_MODE,PERIOD_OF_STAY,PERMANANT_RESIDING_SINCE,PHONE_AH,PHONE_BH,PLACE_BIRTH,PO_BOX,POSITION_HOLD,PRESENT_RESIDENCE,PREVIOUS_ENTITY_DET,
                                                        PREVIOUS_ENTITY_FLAG,PRIMARY_RELATION,PROFESSION_BUSINESS,PROPERTY_DETAILS,ADHAR_ID,RATION_CARD_NO,REC_STATUS,RECEIPTS,RECEIVING_ADDRESS,
                                                        REF_NAME_ONE,REF_NAME_TWO,REF_ONE_ADDRESS,REF_PHONE_ONE,REF_PHONE_TWO,REF_TWO_ADDRESS,REGIONAL_OFFICE,RELATION,REMARKS,RENT_INCOME,RENT_PAID,RENT_PAYMENT,
                                                        RES_STATUS,RO_SAN_REF_NO,SALARY_INC,SEC_ACCESS_CODE,SEC_QUESTION,SEC_QUESTION_ANSWER,SECONDARY_ID,SECURITY_BUSSINESS,SKIP_SCORE,SKIP_SCORE_REASON,SMS_ALERTS,
                                                        SPOUSE_DETAILS,TAX_IDENTIFICATION,TOTAL_INC_PER_MONTH,TOTAL_SPENDING_PER_MONTH,TRADE_HOUSE,TXN_REF_NO,TYPE_OF_ORG,VEHICLE_MAKE,VEHICLE_MODEL,VEHICLE_NO,
                                                        VEHICLE_PROVIDEDBY,VEHICLE_TYPE,VEHICLE_YEAR,VIP_FLAG,VOTER_ID_NO,WORK_EXPERIENCE,WEB_FLAG)
                                                                     (SELECT V_FINACCTYPE,V_Address,OTHPROF,'','',ANNUALSAL_INC,APP_NO,MAKER_DATE,TYPE_OF_VEHICLE,'',FIN_ACC_NO,'',BANK_LOAN,'','',
                                                                     '','','',ANNUALBUS_INC,BUS_AS,C_MAILID,DECODE(SALUT,'MR.','MR.','MRS.','MRS.','MS.','MS.','DR.','DR.','MISS.','MISS.'),AUTH_DATE,AUTH_ID,CIN,
                                                                     'A','','','','','',V_EMAILFLAG,CREDIT_LIMIT,ACC_LIMIT,'','',V_CUSTID,DESIRED_NAME,'',DECODE(MAIL_TO,'OFFICE ADDRESS','OFFICE ADDRESS',
                                                                     'CURRENT ADDRESS','CURRENT ADDRESS','PRESENT ADDRESS','PRESENT ADDRESS'),'','',DESIGNATION,DESIRED_NAME,DOB,'','','',EDU_BACK,V_EMAIL,CUST_EMP_ID,COMP_NAME,'','','Y','',F_NAME,'','','','','','',
                                                                     '','N',DECODE(SEX,'M','MALE','F','FEMALE',SEX),'','','','','PASSPORT',PASS_NUM,'','','','','','','',L_NAME,'','',M_MAILID,M_NAME,MAIL_TO,MAKER_DATE,MAKER_ID,
                                                                     DECODE(MAR_STAT,'M','MARRIED','S','SINGLE','W','WIDOWER','D','DIVORCED','SINGLE'),SPOUSE_NAME,
                                                                     V_MOBILE,'',MONTHLY_INC,MOTHER_NAME,DESIRED_NAME,NATIONALITY,BUS_NATURE,'','',NO_OF_DEPD,'','','','','','',V_OffAddress,V_OffMail,V_OffFax,V_OffPH,V_ORDERREFNO,'',OTHER_INC_SOURCE,
                                                                     OTH_CR_CARD_NO1,OTHERINCOME,'',OTHER_SPECIFY,'',P_MAILID,PAN_NO,P_CIN,'','','','','','','','','','','','','','','','',
                                                                     PROFESSION,'','','','CA','',CRDSTMT_DELIVERY,REF_NAME1,REF_NAME2,'',REF_PHONE1,'','','',RELATIONSHIP,'',RENT_INC,RENT_PAYMENT,RENT_PAYMENT,
                                                                     '','','','','','',V_ACC,'','','','',SPOUSE_DOB,'',OTH_MONTHLY_INC+MONTHLY_INC,'','',V_TXNREFNO,'',MAKE_VEHICLE,'',VEHICLE_NO,'',TYPE_OF_VEHICLE,'',
                                                                     DECODE(VIP_FLAG,'Y','YES','N','NO'),'','','N' FROM MIG_CUSTOMER_MASTER WHERE CIN=MIGCARD AND NVL(MIG_FLAG,'N')='N');

                                                        INSERT INTO CUSTOMER_MASTER_TEMP
                                                        (ACCOUNT_TYPE,ADDRESS,ADDRESS_PROOF,AGENCY,ANNUAL_BUSINESS_INC,ANNUAL_SALARY_INC,APP_NO,APPLICATION_DATE,AUTOMOBILE,BANK,BANK_ACC_NUMBER,BANK_CUSTOMER_RELATION,
                                                        BANK_LOAN,BIC,BOND_COMPANY,BRANCH_NAME,BRN_BIC,BROKERAGE_FIRM,BUSINESS_INCREMENT,BUSINESS_NAME,C_MAILID,CATG_CODE,CHECKER_DTTM,CHECKER_ID,CIN,CIN_STATUS,
                                                        COMPANY_INSTITUTION,CORP_ADDRESS,CORP_TAX_ID,CORPORATE_CUST,CORPORATE_ID,CRDSTMT_DELIVERY,CREDITLIMIT,CREDITLIMIT_ONE,CURRENT_RESIDING_SINCE,CUST_CATEGORY,
                                                        CUSTOMER_ID,CUSTOMER_NAME,DATE_OF_INCEPTION,DELIVERY_LOCATION,DEPARTMENT,DEPOSIT_HOUSE,DESIGNATION,DESIRED_NAME,DOB,DRIVING_LICENSE_ISSUE_PLACE,
                                                        DRIVING_LICENSE_NO,ECONOMIC_SECTOR,EDU_QUALIFICATION,EMAIL_ID,EMPLOYEE_ID,EMPLOYER,EMPLOYMENT_DATE,EXCHANGE_HOUSE,EXIST_CUSTOMER,EXPERIENCE,F_NAME,
                                                        FACTORING,FAMILY_NAME,FILE_ID,FINANCE_BUSINESS,FINANCE_SOCIETY,FINANCIAL_ADDRESS,FREQUENT_FLYER,FREQUENT_FLYER_FLAG,GENDER,GENERAL_WAREHOUSE,HOLD_OTHERCARDS,
                                                        HOUSE_OTHERS,HOUSE_OTHERS_FLAG,IDENTIFICATION,IDENTITY_ISSUE_DATE,IDENTITY_ISSUE_PLACE,INSCRIPTION_NUMBER,INSURANCE_COMPANY,INTERNATIONAL,INVESTMENT,
                                                        JOINING_DATE,KYC_FLAG,L_NAME,LOCAL,LOCATION,M_MAILID,M_NAME,MAIL_TO,MAKER_DTTM,MAKER_ID,MARITAL_STATUS,MARRIED_NAME,MOBILE_NO,MONTHLY_BILLS,MONTHLY_SALARY_INC,
                                                        MOTHERS_MAIDEN_NAME,NAME_ON_ID,NATIONALITY,NATURE_OF_BUSINESS,NO_OF_CARDS,NO_OF_CHILDREN,NO_OF_DEPENDANTS,NO_OF_EMPLOYEES,NOOF_EARNEDPERSONS,NOTARIAL_DEED_DET,
                                                        O_APP_NO,OBJECTIVE,OFF_SHORE,OFFICE_ADDRESS,OFFICE_EMAIL,OFFICE_FAX,OFFICE_PHONE,ORDER_REF_NO,ORIGIN_OF_INCOME,ORIGIN_OF_INCOME_OTHERS,OTHER_CARDS_DETAILS,
                                                        OTHER_INCOME,OTHER_LOCATION,OTHERS_SPECIFY,P_BANK_BRANCH,P_MAILID,PAN_NO,PARENT_CIN,PASSPORT_COUNTRY,PASSPORT_EXP_DATE,PASSPORT_ISSUE_PLACE,PASSPORT_NO,
                                                        PAYMENT_MODE,PERIOD_OF_STAY,PERMANANT_RESIDING_SINCE,PHONE_AH,PHONE_BH,PLACE_BIRTH,PO_BOX,POSITION_HOLD,PRESENT_RESIDENCE,PREVIOUS_ENTITY_DET,
                                                        PREVIOUS_ENTITY_FLAG,PRIMARY_RELATION,PROFESSION_BUSINESS,PROPERTY_DETAILS,ADHAR_ID,RATION_CARD_NO,REC_STATUS,RECEIPTS,RECEIVING_ADDRESS,
                                                        REF_NAME_ONE,REF_NAME_TWO,REF_ONE_ADDRESS,REF_PHONE_ONE,REF_PHONE_TWO,REF_TWO_ADDRESS,REGIONAL_OFFICE,RELATION,REMARKS,RENT_INCOME,RENT_PAID,RENT_PAYMENT,
                                                        RES_STATUS,RO_SAN_REF_NO,SALARY_INC,SEC_ACCESS_CODE,SEC_QUESTION,SEC_QUESTION_ANSWER,SECONDARY_ID,SECURITY_BUSSINESS,SKIP_SCORE,SKIP_SCORE_REASON,SMS_ALERTS,
                                                        SPOUSE_DETAILS,TAX_IDENTIFICATION,TOTAL_INC_PER_MONTH,TOTAL_SPENDING_PER_MONTH,TRADE_HOUSE,TXN_REF_NO,TYPE_OF_ORG,VEHICLE_MAKE,VEHICLE_MODEL,VEHICLE_NO,
                                                        VEHICLE_PROVIDEDBY,VEHICLE_TYPE,VEHICLE_YEAR,VIP_FLAG,VOTER_ID_NO,WORK_EXPERIENCE,WEB_FLAG)
                                                                        (SELECT V_FINACCTYPE,V_Address,OTHPROF,'','',ANNUALSAL_INC,APP_NO,MAKER_DATE,TYPE_OF_VEHICLE,'',FIN_ACC_NO,'',BANK_LOAN,'','',
                                                                        '','','',ANNUALBUS_INC,BUS_AS,C_MAILID,DECODE(SALUT,'MR.','MR.','MRS.','MRS.','MS.','MS.','DR.','DR.','MISS.','MISS.'),AUTH_DATE,AUTH_ID,CIN,
                                                                        'A','','','','','',V_EMAILFLAG,CREDIT_LIMIT,ACC_LIMIT,'','',V_CUSTID,DESIRED_NAME,'',DECODE(MAIL_TO,'OFFICE ADDRESS','OFFICE ADDRESS',
                                                                        'CURRENT ADDRESS','CURRENT ADDRESS','PRESENT ADDRESS','PRESENT ADDRESS'),'','',DESIGNATION,DESIRED_NAME,DOB,'','','',EDU_BACK,V_EMAIL,CUST_EMP_ID,COMP_NAME,'','','Y','',F_NAME,'','','','','','',
                                                                        '','N',DECODE(SEX,'M','MALE','F','FEMALE',SEX),'','','','','PASSPORT',PASS_NUM,'','','','','','','',L_NAME,'','',M_MAILID,M_NAME,MAIL_TO,MAKER_DATE,MAKER_ID,
                                                                        DECODE(MAR_STAT,'M','MARRIED','S','SINGLE','W','WIDOWER','D','DIVORCED','SINGLE'),SPOUSE_NAME,
                                                                        V_MOBILE,'',MONTHLY_INC,MOTHER_NAME,DESIRED_NAME,NATIONALITY,BUS_NATURE,'','',NO_OF_DEPD,'','','','','','',V_OffAddress,V_OffMail,V_OffFax,V_OffPH,V_ORDERREFNO,'',OTHER_INC_SOURCE,
                                                                        OTH_CR_CARD_NO1,OTHERINCOME,'',OTHER_SPECIFY,'',P_MAILID,PAN_NO,P_CIN,'','','','','','','','','','','','','','','','',
                                                                        PROFESSION,'','','','CA','',CRDSTMT_DELIVERY,REF_NAME1,REF_NAME2,'',REF_PHONE1,'','','',RELATIONSHIP,'',RENT_INC,RENT_PAYMENT,RENT_PAYMENT,
                                                                        '','','','','','',V_ACC,'','','','',SPOUSE_DOB,'',OTH_MONTHLY_INC+MONTHLY_INC,'','',V_TXNREFNO,'',MAKE_VEHICLE,'',VEHICLE_NO,'',TYPE_OF_VEHICLE,'',
                                                                        DECODE(VIP_FLAG,'Y','YES','N','NO'),'','','N' FROM MIG_CUSTOMER_MASTER WHERE CIN=MIGCARD AND NVL(MIG_FLAG,'N')='N');


                                        UPDATE MIG_CUSTOMER_MASTER SET MIG_FLAG='Y' WHERE CIN=MIGCARD;

                                        --COMMIT;
        EXCEPTION

                                                                        WHEN NO_DATA_FOUND THEN
                                                                                        DBMS_OUTPUT.PUT_LINE('DATA NOT AVAIALBLE WHILE PROCESSING CUSTOMER_MASTER ');
                                                                        WHEN OTHERS THEN
                                                                                        V_ERRMSG        := SUBSTR(SQLERRM,1,100);
                                                                                        DBMS_OUTPUT.PUT_LINE('ERROR CAUGHT WHILE PROCESSING CUSTOMER_MASTER ['||V_ERRMSG||']');

        END;

        BEGIN
                                                        INSERT INTO SI_TB
                                                        (ACC_NO,ACC_TYPE,APP_NO,AUTH_DATE,AUTH_ID,BANK_NAME,BR_ID,BR_NAME,C_ACC_NO,CARD_NO,CIN,CORP_GRP_ID,CORP_ID,CR_CURR,DEL_FLG,
                                                        DR_CURR,ENTRY_DT,FROM_DT,LAST_PAY_DT,MAKER_DATE,MAKER_ID,MAX_AMT,PAY_DAY,PAY_DET,PERCENTAGE,REC_STATUS,REFNO,STANDING_FLAG,STATUS_FLG,TO_DT)
                                                                                                                        (SELECT ACC_NO,ACC_TYPE,(SELECT APP_NO FROM MIG_CUSTOMER_MASTER WHERE CIN=MIGCARD),AUTH_DATE,AUTH_ID,BANK_NAME,BR_ID,BR_NAME,C_ACC_NO,CARD_NO,CIN,CORP_GRP_ID,CORP_ID,CR_CURR,DEL_FLG,DR_CURR,ENTRY_DT,
                                                                                                                        FROM_DT,LAST_PAY_DT,MAKER_DATE,MAKER_ID,MAX_AMT,PAY_DAY,PAY_DET,'','CA',REFNO,'Yes',STATUS_FLG,TO_DT FROM MIG_SI_TB WHERE CIN=MIGCARD AND NVL(MIG_FLAG,'N')='N');

                                                        INSERT INTO SI_TB_TEMP
                                                        (ACC_NO,ACC_TYPE,APP_NO,AUTH_DATE,AUTH_ID,BANK_NAME,BR_ID,BR_NAME,C_ACC_NO,CARD_NO,CIN,CORP_GRP_ID,CORP_ID,CR_CURR,DEL_FLG,
                                                        DR_CURR,ENTRY_DT,FROM_DT,LAST_PAY_DT,MAKER_DATE,MAKER_ID,MAX_AMT,PAY_DAY,PAY_DET,PERCENTAGE,REC_STATUS,REFNO,STANDING_FLAG,STATUS_FLG,TO_DT)
                                                                                                                        (SELECT ACC_NO,ACC_TYPE,(SELECT APP_NO FROM MIG_CUSTOMER_MASTER WHERE CIN=MIGCARD),AUTH_DATE,AUTH_ID,BANK_NAME,BR_ID,BR_NAME,C_ACC_NO,CARD_NO,CIN,CORP_GRP_ID,CORP_ID,CR_CURR,DEL_FLG,DR_CURR,ENTRY_DT,
                                                                                                                        FROM_DT,LAST_PAY_DT,MAKER_DATE,MAKER_ID,MAX_AMT,PAY_DAY,PAY_DET,'','CA',REFNO,'Yes',STATUS_FLG,TO_DT FROM MIG_SI_TB WHERE CIN=MIGCARD AND NVL(MIG_FLAG,'N')='N');

                                                        UPDATE MIG_SI_TB SET MIG_FLAG = 'Y' WHERE CIN =MIGCARD;

        EXCEPTION

                                                                        WHEN NO_DATA_FOUND THEN
                                                                                        DBMS_OUTPUT.PUT_LINE('DATA NOT AVAIALBLE WHILE PROCESSING SI_TB ');
                                                                        WHEN OTHERS THEN
                                                                                        V_ERRMSG        := SUBSTR(SQLERRM,1,100);
                                                                                        DBMS_OUTPUT.PUT_LINE('ERROR CAUGHT WHILE PROCESSING SI_TB ['||V_ERRMSG||']');
        END;

        BEGIN

                                                                                                        SELECT COUNT(*) INTO C_CNT FROM USER_ID_MAPPING WHERE LOGIN_USER_ID=V_CARD;

                                                        IF(C_CNT=0) THEN
                                                                                                                        V_SYSTEM_ID:=CREDITCOMMONUTILPKG.FGETSYSTEMUSERID;
                                                                                                                        V_USER_GROUPS:='CREDITCUSTOMER';
                                                                                                                        V_USER_TYPE:='C';
                                                                                                                        V_USER_STATUS:='R';

                                                                                                                        INSERT INTO USER_ID_MAPPING (LOGIN_USER_ID,SYSTEM_USER_ID,CIN_NO,MAKER_ID,MAKER_DTTM) VALUES
                                                                                                                        (V_CARD,V_SYSTEM_ID,MIGCARD,'MIGUSER',SYSDATE);

                                                                                                                        INSERT INTO USER_MASTER (USER_ID, USER_NAME, USER_GROUPS, USER_STATUS, USER_TYPE, MAKER_ID, MAKER_DTTM,MOBILE, EMAIL, ENTITY,LANGUAGE_CD)
                                                                                                                        VALUES (V_SYSTEM_ID, v_user_name, V_USER_GROUPS, V_USER_STATUS, V_USER_TYPE, 'MIGUSER', SYSDATE, v_Mobile, v_Email,'','EN');

                                                                                                                        INSERT INTO PIN_MASTER (USER_ID, USER_PASSWORD, CHANNEL, LAST_PASSWD_CHANGE, INCORRECT_PASSWD_CNT, PASSWD_CNT_DATE, CUM_PASSWD_CNT, MAKER_ID, MAKER_DTTM, SECRET_CODE) VALUES
                                                                                                                        (V_SYSTEM_ID, '', 'IVR', SYSDATE, 0, SYSDATE, 0, 'MIGUSER', SYSDATE,'');

                                                        END IF;
                                                                EXCEPTION
                                                                        WHEN NO_DATA_FOUND THEN
                                                                                        DBMS_OUTPUT.PUT_LINE('DATA NOT AVAILABLE WHILE PROCESSING USER_ID_MAPPING TABLES');
                                                                                                                                                                        
                                                                        WHEN OTHERS THEN
                                                                                        V_ERRMSG        := SUBSTR(SQLERRM,1,100);
                                                                                        DBMS_OUTPUT.PUT_LINE('ERROR CAUGHT WHILE PROCESSING USER_ID_MAPPING TABLES ['||V_ERRMSG||']');

        END;

        BEGIN
                                                                                                                        SELECT COUNT(*) INTO C_CNT FROM USER_ID_MAPPING WHERE MAKER_ID=V_CARD;

                                                        IF(C_CNT=0) THEN

                                                                                                                        SELECT USER_ID INTO V_USER FROM MIG_USER_AUTH WHERE CARD_NO=V_CARD;

                                                                                                                        INSERT INTO USER_ID_MAPPING (LOGIN_USER_ID,SYSTEM_USER_ID,CIN_NO,MAKER_ID,MAKER_DTTM)
                                                                                                                        VALUES (v_user,V_SYSTEM_ID,MIGCARD,v_card,SYSDATE);

                                                                                                                        INSERT INTO PIN_MASTER (USER_ID, USER_PASSWORD, CHANNEL, LAST_PASSWD_CHANGE, INCORRECT_PASSWD_CNT, PASSWD_CNT_DATE, CUM_PASSWD_CNT, MAKER_ID, MAKER_DTTM, SECRET_CODE) VALUES
                                                                                                                        (V_SYSTEM_ID, '', 'WEB', SYSDATE, 0, SYSDATE, 0, 'MIGUSER', SYSDATE,'');


                                                        END IF;

        EXCEPTION
                                                                        WHEN NO_DATA_FOUND THEN
                                                                                        DBMS_OUTPUT.PUT_LINE('DATA NOT AVAILABLE WHILE PROCESSING MIG_USER_AUTH TABLES');

                                                                        WHEN OTHERS THEN
                                                                                        V_ERRMSG        := SUBSTR(SQLERRM,1,100);
                                                                                        DBMS_OUTPUT.PUT_LINE('ERROR CAUGHT WHILE PROCESSING MIG_USER_AUTH TABLES ['||V_ERRMSG||']');

        END;


                                                        BEGIN
                                                                                        SELECT BR_ID INTO V_BRANCHCODE FROM MIG_CARD_MASTER WHERE CIN = MIGCARD;

                                                                                        SELECT SUBSTR(V_PROD,1,3)||''||'PLA' INTO V_PLACODE FROM DUAL;
/**
                                                                                        SELECT DECODE(GRP_ID,'1','GOLD STAFF PRODUCT','2','GOLD CUSTOMER PRODUCT','3','CLASSIC STAFF PRODUCT','4','CLASSIC CUSTOMER PRODUCT','5','GLOBAL BHARAT CARD',
                                                                                        '6','CLASSIC BHARATH','7','VISA BUSINESS PRODUCT','8','VISA BUSINESS CARD','SUPERVISOR CARD') INTO V_PRD_NAME FROM CARD_GRP_TB ;
**/

                                                                                        SELECT DECODE(V_BIN,'43280901','GOLD STAFF PRODUCT','43280902','GOLD CUSTOMER PRODUCT','43280801','CLASSIC STAFF PRODUCT','43280802','CLASSIC CUSTOMER PRODUCT','43280903','GLOBAL BHARAT CARD',
                                                                                        '43280803','CLASSIC BHARATH','42847901','VISA BUSINESS PRODUCT','42847900','VISA BUSINESS CARD','SUPERVISOR CARD') INTO V_PRD_NAME FROM DUAL;

                                                                                        INSERT INTO CARD_ORDER_DETAILS (ORDER_REF_NO, BRANCH_ID, DISPATCHED_QUANTITY, AGENT_ID, PRD_ID, CURRENCY, PRD_NAME, PLASTIC_CODE,
                                                                                        ORDERED_QUANTITY, ORDERED_DATE, STATUS_FLAG,USER_ID, MAKER_ID, MAKER_DTTM, REC_STATUS, AGENCY_NAME,
                                                                                        INS_FLAG,RECEIVED_QUANTITY,EMBOSS_NAME,THIRD_LINE_NAME,PLASTIC_NAME,PLASTIC_TYPE,CARD_TYPE_NAME)
                                                                                        VALUES (V_ORDERREFNO, V_BRANCHCODE, 0, V_BRANCHCODE, V_PROD, '356', V_PRD_NAME,V_PLACODE, 1, SYSDATE, 'CR', V_USER, 'MIGUSER',
                                                                                        SYSDATE,'MA', 'MIGUSER','P',1,v_user_name,v_user_name,V_PLACODE,V_PLACODE,'NEW CARD');

        EXCEPTION

                                                                                        WHEN NO_DATA_FOUND THEN
                                                                                                        DBMS_OUTPUT.PUT_LINE('DATA NOT AVAIALBLE WHILE PROCESSING CARD_ORDER_DETAILS');
                                                                                        WHEN OTHERS THEN
                                                                                                        V_ERRMSG        := SUBSTR(SQLERRM,1,100);
                                                                                                        DBMS_OUTPUT.PUT_LINE('ERROR CAUGHT WHILE PROCESSING CARD_ORDER_DETAILS ['||V_ERRMSG||']');

        END ;

        BEGIN
                                                                                        SELECT GenTxnRefnoPkg.GenTxnRefno('INVOCE','INVOICE') INTO V_INVOICEREFNO FROM DUAL;

                                                                                        INSERT INTO INVOICE_MASTER
                                                                                                                        (INVOICE_REF_NO, BATCH_NO, STATUS_FLAG, MAKER_ID, MAKER_DATE,AGENT_ID ) VALUES
                                                                                                                        (V_INVOICEREFNO, V_ORDERREFNO, 'CR', 'MIGUSER', SYSDATE,V_BRANCHCODE);

                                                                                        INSERT INTO INVOICE_TRANS
                                                                                                                        (INVOICE_REF_NO, ORDER_REF_NO, MAKER_ID, MAKER_DATE) VALUES
                                                                                                                        (V_INVOICEREFNO, V_ORDERREFNO, 'MIGMKR', SYSDATE);

        EXCEPTION
                                                                                        WHEN NO_DATA_FOUND THEN
                                                                                                        DBMS_OUTPUT.PUT_LINE('DATA NOT AVAIALBLE WHILE PROCESSING INVOICE_TABLES');
                                                                                        WHEN OTHERS THEN
                                                                                                        V_ERRMSG        := SUBSTR(SQLERRM,1,100);
                                                                                                        DBMS_OUTPUT.PUT_LINE('ERROR CAUGHT WHILE PROCESSING INVOICE_TABLES ['||V_ERRMSG||']');
        END ;

                                                          --      DBMS_OUTPUT.PUT_LINE('PROCESSED CIN IS '||'-'||MIGCARD||' PROCESSED ACC '||V_ACC);

        END LOOP;
                                --    DBMS_OUTPUT.PUT_LINE('TOTAL ROWS :'||V_ROW);

        CLOSE ACCT_CUR;

        open acc_cursor;

        loop

        fetch acc_cursor into v_acc,v_cin,v_card,v_noh ;

        if acc_cursor%notfound then exit;

        end if;

        dbms_output.put_line('processed acc_no '||v_acc);

        BEGIN

        dbms_output.put_line('noh is '||v_noh);

        BEGIN

                                                                        SELECT SUBSTR(V_CARD,1,8) INTO V_BIN FROM MIG_ACCOUNTS_MASTER WHERE CIN=V_CIN;

                                                                        SELECT DECODE(V_BIN,'43280901','GOLD STAFF PRODUCT','43280902','GOLD CUSTOMER PRODUCT','43280801','CLASSIC STAFF PRODUCT','43280802','CLASSIC CUSTOMER PRODUCT','43280903','GLOBAL BHARAT CARD',
                                                                        '43280803','CLASSIC BHARATH','42847901','VISA BUSINESS PRODUCT','42847900','VISA BUSINESS CARD','SUPERVISOR CARD') INTO V_PRD_NAME FROM DUAL;

                                                                        SELECT DECODE(V_BIN,'43280901','GLDSTF','43280902','GLDCST','43280801','CLASTF','43280802','CLACST','43280903','GLBCRD',
                                                                        '43280803','CLABRD','42847901','VISPRD','42847900','VISCRD','NOPPRD') INTO V_PROD FROM DUAL;

        EXCEPTION
                                                                        WHEN NO_DATA_FOUND THEN
                                                                                        dbms_output.PUT_LINE('DATA NOT AVAIALBLE WHILE PROCESSING MIG_CARD_GRP_TB-MIG_ACCOUNTS_MASTER');
                                                                        WHEN OTHERS THEN
                                                                                        V_ERRMSG        := substr(SQLERRM,1,100);
                                                                                        dbms_output.PUT_LINE('ERROR CAUGHT WHILE PROCESSING MIG_CARD_GRP_TB-MIG_ACCOUNTS_MASTER ['||V_ERRMSG||']');
        END ;

                                                                        insert into card_account_master
                                                                        (CARD_ACCT,CARD_ACCT_CCY,CARD_ACCT_STATUS,CARD_ACCT_BAL,LAST_TXN_REF_NO,LAST_TXN_DTTM,MAKER_ID,MAKER_DTTM,CHECKER_ID,CHECKER_DTTM,PRD_CODE,PRIM_FLAG,PRD_NAME,
                                                                        REC_STATUS,REMARKS,OLD_STATUS,CUST_REF_NO,CHARGE_CODE,DEF_FLAG,ACCOUNT_TYPE,USAGE_CODE,PROF_CODE,DEL_COUNT,SUSP_FLAG,LAST_ST_DT,NEXT_ST_DT,BILL_DAY,EMAIL_FLAG,
                                                                        LAST_INV_DT,ORDER_REF_NO,PLASTIC_CODE,CIN,TXN_REF_NO,NOC,NOH,APP_CODE,CHARGE_TO_DT,CHRGE_FROM_DT,OVRLMT_FLAG,DEL_BLOCK,ACC_TYPE,BCATEG_CODE,WEB_FLAG)
                                                                        (select ACC_NO,'356',ACC_STATUS,'','','',MAKER_ID,MAKER_DATE,AUTH_ID,AUTH_DATE,V_PROD,PRIM_FLAG,V_PRD_NAME,'CA','MIG','','',CH_CODE,DEL_FLAG,ACC_TYPE,'',
                                                                        PROF_ID,DEL_COUNT,'',LAST_BILL_DATE,NEXT_BILL_DATE,BILL_DAY,EMAIL_FLAG,'',(select ORDER_REF_NO from customer_master where cin=v_cin),'',CIN,(select TXN_REF_NO from customer_master where cin=v_cin),
                                                                        NOC,NOH,'CREDIT','','','','',ACC_TYPE,'','N' from mig_accounts_master where nvl(mig_flag,'N')='N' and acC_no=v_acc and noh='1');

        EXCEPTION
                                                                        WHEN NO_DATA_FOUND THEN
                                                                                        dbms_output.PUT_LINE('DATA NOT AVAIALBLE WHILE PROCESSING CARD_ACCOUNT_MASTER');
                                                                        WHEN OTHERS THEN
                                                                                        V_ERRMSG        := substr(SQLERRM,1,100);
                                                                                        dbms_output.PUT_LINE('ERROR CAUGHT WHILE PROCESSING CARD_ACCOUNT_MASTER ['||V_ERRMSG||']');
        END ;

        --commit;

        /**===============================================================================**/


                                                                                        select count(*) into v_cnt from mig_used_tbl where account_no=v_acc;

        if v_cnt>0 then

                                                                                        v_row:=sql%rowcount;

                                                                                        select CR_LIMIT,cash_limit,te_limit into v_creditlmt,v_cashlmt,v_telmt  from mig_accounts_master where acC_no=v_acc and noh='1';


                                                                                        select sum(nvl(USED_CREDIT_LINE,0)),sum(nvl(USED_CASH_LINE,0)),sum(nvl(USED_TE_LINE,0)) into v_UsdCrLmt,v_UsdCsLmt,v_UsdTeLmt
                                                                                        from mig_used_tbl where account_no = v_acc ;


                                                                                                        v_AvlCrLmt      := to_number(nvl(v_creditlmt,0)) - v_UsdCrLmt;
                                                                                                        v_AvlCsLmt      := to_number(nvl(v_creditlmt,0)) - v_UsdCsLmt;
                                                                                                        v_AvlTeLmt      := to_number(nvl(v_creditlmt,0)) - v_UsdTeLmt;

                                                                                        select count(*) into b_cnt from mig_bill_fee_tbl where acc_no=v_acc and txn_type in('DEP','REFUN');
        if b_cnt>0 then
                                                                                        select sum(nvl(bal_amt,0)) into v_cashinhand from mig_bill_fee_tbl where acc_no=v_acc and txn_type in('DEP','REFUN');
                                                                                        else
                                                                                        v_cashinhand:=0;
        end if;


                                                                                        select count(*) into t_cnt from cr_lmt_txn where REFNO=v_acc ;

        if t_cnt=0 then
                                                                                        select  LIMIT_SEQ.nextval into v_LmtId from dual;

                                                                                        insert into cr_lmt_txn
                                                                                        (CRLMT_ID,CRLMT_TYPE,REFNO,PARENT_ID,PRD_CODE,LMT_CCY,CREDIT_LIMIT,CASH_LIMIT,TE_LIMIT,CREDIT_BAL,CASH_BAL,TE_BAL,REC_STATUS,
                                                                                        MAKER_DT,MAKER_ID,CHECKER_DT,CHECKER_ID,CASH_IN_HAND,WEB_FLAG) values
                                                                                        (v_LmtId,'ACC',v_acc,'',V_PROD,'356',v_creditlmt,v_cashlmt,v_telmt,v_AvlCrLmt,v_AvlCsLmt,v_AvlTeLmt,'CA',
                                                                                        current_date,'MIG',current_date,'',v_cashinhand,'N');

                                                                                        v_balance:=nvl(v_AvlCrLmt,0)+nvl(v_cashinhand,0);

                                                                                        update carD_account_master set card_acct_bal=v_balance where card_acct=v_acc;

        end if;

                                                        dbms_output.put_line('noh is for card'||v_noh);



                                                                                                                        select CR_LIMIT,cash_limit,te_limit into v_creditlmt,v_cashlmt,v_telmt  from mig_accounts_master where card_no=v_card and acc_no=v_acc;

                                                                                                                        select nvl(TRIM(used_credit_line),0),nvl(TRIM(used_cash_line),0),(nvl(TRIM(used_te_line),0))
                                                                                                                        into v_UsdCrLmt,v_UsdCsLmt,v_UsdTeLmt
                                                                                                                        from mig_used_tbl where card_no = v_card;

                                                                                                                        select count(*) into d_cnt from mig_bill_fee_tbl where acc_no=v_acc and txn_type in('DEP','REFUN');
        if d_cnt>0 then
                                                                                                                        select sum(nvl(bal_amt,0)) into v_cashinhand1 from mig_bill_fee_tbl where card_no=v_card and txn_type in('DEP','REFUN');

                                                                                                                        else
                                                                                                                                                                        v_cashinhand1:=0;
                                                                                                                        end if;

                                                                                                                        v_AvlCrLmt      := to_number(nvl(v_creditlmt,0)) - v_UsdCrLmt;
                                                                                                                        v_AvlCsLmt      := to_number(nvl(v_creditlmt,0)) - v_UsdCsLmt;
                                                                                                                        v_AvlTeLmt      := to_number(nvl(v_creditlmt,0)) - v_UsdTeLmt;
                                                                                                                        v_balance:=nvl(v_AvlCrLmt,0)+nvl(v_cashinhand1,0);


                                                                        insert into card_account_master_wk
                                                                        (CARD_ACCT,CIN,ACCOUNT_TYPE,CARD_ACCT_CCY,CARD_ACCT_STATUS,CARD_ACCT_BAL,LAST_TXN_REF_NO,LAST_TXN_DTTM,MAKER_ID,MAKER_DTTM,
                                                                        CHECKER_ID,CHECKER_DTTM,PRD_CODE,PRIM_FLAG,PRD_NAME,REC_STATUS,REMARKS,OLD_STATUS,CUST_REF_NO,CHARGE_CODE,DEF_FLAG,PLASTIC_CODE,
                                                                        CARD_NO,ORDER_REF_NO,NOH,NOC,TXN_REF_NO,PROF_CODE,USAGE_CODE,BILL_DAY,DEL_COUNT,EMAIL_FLAG,LAST_INV_DT,LAST_ST_DT,NEXT_ST_DT,
                                                                        SUSP_FLAG,APP_CODE,CHRGE_FROM_DT,CHARGE_TO_DT,OVRLMT_FLAG,BCATEG_CODE,WEB_FLAG)
                                                                        (select ACC_NO,CIN,ACC_TYPE,'356',ACC_STATUS,'','','',MAKER_ID,MAKER_DATE,AUTH_ID,AUTH_DATE,V_PROD,PRIM_FLAG,V_PRD_NAME,'CA','MIG','','',CH_CODE,
                                                                        DEL_FLAG,'',v_card,(select ORDER_REF_NO from customer_master where cin=v_cin),NOH,NOC,(select TXN_REF_NO from customer_master where cin=v_cin),
                                                                        PROF_ID,'',BILL_DAY,DEL_COUNT,EMAIL_FLAG,'',LAST_BILL_DATE,NEXT_BILL_DATE,'','CREDIT','','','','','N' from mig_accounts_master
                                                                        where nvl(mig_flag,'N')='N' and acc_no=v_acc and card_no=v_card);

                                                                        update card_account_master_wk set card_acct_bal=nvl(v_balance,0) where card_acct=v_acc;

                                                                        insert into cardacct_card_link
                                                                        (ACC_TYPE,ACCOUNT_TYPE,APP_CODE,CAMPAIGN_DATE,CARD_ACCT,CARD_ACCT_BAL,CARD_ACCT_CCY,CARD_ACCT_STATUS,CARD_NO,CHARGE_CODE,CHARGE_TO_DT,CHECKER_DTTM,CHECKER_ID,
                                                                        CHRGE_FROM_DT,CIN,CLASS_CODE,CREDIT_BALANCE,CREDIT_LIMIT,CUST_REF_NO,DEF_FLAG,DEL_COUNT,IB_DISPLAY,LAST_ST_DT,LAST_TXN_DTTM,LAST_TXN_REF_NO,MAKER_DTTM,MAKER_ID,
                                                                        NEXT_ST_DT,NOC,NOH,OLD_CAMPAIGN_CODE,OLD_STATUS,PRD_CODE,PRIM_FLAG,PROF_CODE,REC_STATUS,REMARKS,USAGE_CODE)
                                                                        (select ACC_TYPE,ACC_TYPE,'CREDIT','',ACC_NO,'','356','',CARD_NO,CH_CODE,'',AUTH_DATE,AUTH_ID,'',CIN,'','','','',
                                                                        DEL_FLAG,DEL_COUNT,'',LAST_BILL_DATE,'','',MAKER_DATE,MAKER_ID,NEXT_BILL_DATE,NOC,NOH,'','',V_PROD,PRIM_FLAG,PROF_ID,'CA','MIG',''
                                                                        from mig_accounts_master where nvl(mig_flag,'N')='N' and acc_no=v_acc and card_no=v_card);

                                                                        update cardacct_card_link set card_acct_bal=v_balance where card_acct=v_acc;

                                                                        select count(*) into t_cnt from cr_lmt_txn where REFNO=v_card ;

        if(t_cnt=0) then
                                                                        select  LIMIT_SEQ.nextval into v_LmtId from dual;
                                                                        insert into cr_lmt_txn
                                                                        (CRLMT_ID,CRLMT_TYPE,REFNO,PARENT_ID,PRD_CODE,LMT_CCY,CREDIT_LIMIT,CASH_LIMIT,TE_LIMIT,CREDIT_BAL,CASH_BAL,TE_BAL,REC_STATUS,
                                                                        MAKER_DT,MAKER_ID,CHECKER_DT,CHECKER_ID,CASH_IN_HAND,WEB_FLAG) values
                                                                        (v_LmtId,'CARD',v_card,'',V_PROD,'356',v_creditlmt,v_cashlmt,v_telmt,v_AvlCrLmt,v_AvlCsLmt,v_AvlTeLmt,'CA',
                                                                        current_date,'MIG',current_date,'',v_cashinhand1,'N');
        end if;


        else
                                                                        select CR_LIMIT,cash_limit,te_limit into v_creditlmt,v_cashlmt,v_telmt  from mig_accounts_master where card_no=v_card and acc_no=v_acc;

                                                                        insert into card_account_master_wk
                                                                        (CARD_ACCT,CIN,ACCOUNT_TYPE,CARD_ACCT_CCY,CARD_ACCT_STATUS,CARD_ACCT_BAL,LAST_TXN_REF_NO,LAST_TXN_DTTM,MAKER_ID,MAKER_DTTM,
                                                                        CHECKER_ID,CHECKER_DTTM,PRD_CODE,PRIM_FLAG,PRD_NAME,REC_STATUS,REMARKS,OLD_STATUS,CUST_REF_NO,CHARGE_CODE,DEF_FLAG,PLASTIC_CODE,
                                                                        CARD_NO,ORDER_REF_NO,NOH,NOC,TXN_REF_NO,PROF_CODE,USAGE_CODE,BILL_DAY,DEL_COUNT,EMAIL_FLAG,LAST_INV_DT,LAST_ST_DT,NEXT_ST_DT,
                                                                        SUSP_FLAG,APP_CODE,CHRGE_FROM_DT,CHARGE_TO_DT,OVRLMT_FLAG,BCATEG_CODE,WEB_FLAG)
                                                                        (select ACC_NO,CIN,ACC_TYPE,'356',ACC_STATUS,'','','',MAKER_ID,MAKER_DATE,AUTH_ID,AUTH_DATE,'GLDSTF',PRIM_FLAG,'','CA','MIG','','',CH_CODE,
                                                                        DEL_FLAG,'',v_card,(select ORDER_REF_NO from customer_master where cin=v_cin),NOH,NOC,(select TXN_REF_NO from customer_master where cin=v_cin),
                                                                        PROF_ID,'',BILL_DAY,DEL_COUNT,EMAIL_FLAG,'',LAST_BILL_DATE,NEXT_BILL_DATE,'','CREDIT','','','','','N' from mig_accounts_master
                                                                        where nvl(mig_flag,'N')='N' and acc_no=v_acc and card_no=v_card);

                                                                        update card_account_master_wk set card_acct_bal=nvl(v_balance,0) where card_acct=v_acc;

                                                                        insert into cardacct_card_link
                                                                        (ACC_TYPE,ACCOUNT_TYPE,APP_CODE,CAMPAIGN_DATE,CARD_ACCT,CARD_ACCT_BAL,CARD_ACCT_CCY,CARD_ACCT_STATUS,CARD_NO,CHARGE_CODE,CHARGE_TO_DT,CHECKER_DTTM,CHECKER_ID,
                                                                        CHRGE_FROM_DT,CIN,CLASS_CODE,CREDIT_BALANCE,CREDIT_LIMIT,CUST_REF_NO,DEF_FLAG,DEL_COUNT,IB_DISPLAY,LAST_ST_DT,LAST_TXN_DTTM,LAST_TXN_REF_NO,MAKER_DTTM,MAKER_ID,
                                                                        NEXT_ST_DT,NOC,NOH,OLD_CAMPAIGN_CODE,OLD_STATUS,PRD_CODE,PRIM_FLAG,PROF_CODE,REC_STATUS,REMARKS,USAGE_CODE)
                                                                        (select ACC_TYPE,ACC_TYPE,'CREDIT','',ACC_NO,'','356','',CARD_NO,CH_CODE,'',AUTH_DATE,AUTH_ID,'',CIN,'','','','',
                                                                        DEL_FLAG,DEL_COUNT,'',LAST_BILL_DATE,'','',MAKER_DATE,MAKER_ID,NEXT_BILL_DATE,NOC,NOH,'','','GLDSTF',PRIM_FLAG,PROF_ID,'CA','MIG',''
                                                                        from mig_accounts_master where nvl(mig_flag,'N')='N' and acc_no=v_acc and card_no=v_card);

                                                                        update cardacct_card_link set card_acct_bal=v_balance where card_acct=v_acc;


        end if;

                                                                        update mig_accounts_master set mig_flag='Y' where card_no=v_card;

                                                                        update mig_used_tbl set mig_flag='Y' where card_no=v_card;

        --commit;

        end loop;

                                                                        dbms_output.put_line('total rows processed '||v_row);

        close acc_cursor;

        end;

        /


