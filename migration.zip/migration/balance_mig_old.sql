set serveroutput on

declare
v_cin  varchar2(20);
v_card varchar2(20);
v_acc varchar2(20);
v_cnt number(2);
d_cnt number(20);
t_cnt number(20);
b_cnt number(20);
v_LmtId varchar2(20);
v_creditlmt varchar2(20);
v_cashlmt varchar2(20);
v_telmt varchar2(20);
v_cashinhand varchar2(20);
v_cashinhand1 varchar2(20);
v_noh varchar2(2);
c_cnt number(2);
cam_cnt number(2);
vUSED_CREDIT_LINE  varchar2(20);
v_UsdCrLmt  varchar2(20);
v_UsdCsLmt  varchar2(20);
v_AvlTeLmt varchar2(20);
v_UsdTeLmt varchar2(20);
v_AvlCrLmt varchar2(20);
v_AvlCsLmt varchar2(20);
V_BALANCE varchar2(20);
v_row varchar2(20);
V_ERRMSG VARCHAR2(4000):=NULL;
V_PRD_NAME varchar2(50);
V_PROD varchar2(10);
V_BIN varchar2(10);

cursor acc_cursor is select distinct acC_no from mig_accounts_master where nvl(mig_flag,'N')='N' order by acC_no;

begin

open acc_cursor;

loop

fetch acc_cursor into v_acc;

if acc_cursor%notfound then exit;

end if;

dbms_output.put_line('processed acc_no '||v_acc);

BEGIN			
				select card_no,cin,noh into v_card,v_cin,v_noh from mig_accounts_master where acc_no=v_acc and noh='1';
	
BEGIN	
				
				SELECT SUBSTR(V_CARD,1,8) INTO V_BIN FROM MIG_ACCOUNTS_MASTER WHERE CIN=V_CIN;

				SELECT DECODE(V_BIN,'43280901','GOLD STAFF PRODUCT','43280902','GOLD CUSTOMER PRODUCT','43280801','CLASSIC STAFF PRODUCT','43280802','CLASSIC CUSTOMER PRODUCT','43280903','GLOBAL BHARAT CARD',
				'43280803','CLASSIC BHARATH','42847901','VISA BUSINESS PRODUCT','42847900','VISA BUSINESS CARD','SUPERVISOR CARD') INTO V_PRD_NAME FROM DUAL;
				
				SELECT DECODE(V_BIN,'43280901','GLDSTF','43280902','GLDCST','43280801','CLASTF','43280802','CLACST','43280903','GLBCRD',
				'43280803','CLABRD','42847901','VISPRD','42847900','VISCRD','NOPPRD') INTO V_PROD FROM DUAL;

EXCEPTION
				WHEN NO_DATA_FOUND THEN					
					dbms_output.PUT_LINE('DATA NOT AVAIALBLE WHILE PROCESSING MIG_CARD_GRP_TB');
				WHEN OTHERS THEN
					V_ERRMSG	:= substr(SQLERRM,1,100);
					dbms_output.PUT_LINE('ERROR CAUGHT WHILE PROCESSING MIG_CARD_GRP_TB ['||V_ERRMSG||']');
END ;
				
				insert into card_account_master
				(CARD_ACCT,CARD_ACCT_CCY,CARD_ACCT_STATUS,CARD_ACCT_BAL,LAST_TXN_REF_NO,LAST_TXN_DTTM,MAKER_ID,MAKER_DTTM,CHECKER_ID,CHECKER_DTTM,PRD_CODE,PRIM_FLAG,PRD_NAME,
				REC_STATUS,REMARKS,OLD_STATUS,CUST_REF_NO,CHARGE_CODE,DEF_FLAG,ACCOUNT_TYPE,USAGE_CODE,PROF_CODE,DEL_COUNT,SUSP_FLAG,LAST_ST_DT,NEXT_ST_DT,BILL_DAY,EMAIL_FLAG,
				LAST_INV_DT,ORDER_REF_NO,PLASTIC_CODE,CIN,TXN_REF_NO,NOC,NOH,APP_CODE,CHARGE_TO_DT,CHRGE_FROM_DT,OVRLMT_FLAG,DEL_BLOCK,ACC_TYPE,BCATEG_CODE)
				(select ACC_NO,'356',ACC_STATUS,'','','',MAKER_ID,MAKER_DATE,AUTH_ID,AUTH_DATE,V_PROD,PRIM_FLAG,V_PRD_NAME,'CA','MIG','','',CH_CODE,DEL_FLAG,ACC_TYPE,'',
				PROF_ID,DEL_COUNT,'',LAST_BILL_DATE,NEXT_BILL_DATE,BILL_DAY,EMAIL_FLAG,'',(select ORDER_REF_NO from customer_master where cin=v_cin),'',CIN,(select TXN_REF_NO from customer_master where cin=v_cin),
				NOC,NOH,'CREDIT','','','','',ACC_TYPE,'' from mig_accounts_master where nvl(mig_flag,'N')='N' and acC_no=v_acc and noh='1');

EXCEPTION
				WHEN NO_DATA_FOUND THEN					
					dbms_output.PUT_LINE('DATA NOT AVAIALBLE WHILE PROCESSING CARD_ACCOUNT_MASTER');
				WHEN OTHERS THEN
					V_ERRMSG	:= substr(SQLERRM,1,100);
					dbms_output.PUT_LINE('ERROR CAUGHT WHILE PROCESSING CARD_ACCOUNT_MASTER ['||V_ERRMSG||']');
END ;

--commit;

/**===============================================================================**/


					select count(*) into v_cnt from mig_used_tbl where account_no=v_acc;

if v_cnt>0 then

					v_row:=sql%rowcount;

					select CR_LIMIT,cash_limit,te_limit into v_creditlmt,v_cashlmt,v_telmt  from mig_accounts_master where acC_no=v_acc and noh='1';


					select sum(nvl(USED_CREDIT_LINE,0)),sum(nvl(USED_CASH_LINE,0)),sum(nvl(USED_TE_LINE,0)) into v_UsdCrLmt,v_UsdCsLmt,v_UsdTeLmt 
					from mig_used_tbl where account_no = v_acc ;


						v_AvlCrLmt	:= to_number(nvl(v_creditlmt,0)) - v_UsdCrLmt;
						v_AvlCsLmt	:= to_number(nvl(v_creditlmt,0)) - v_UsdCsLmt;
						v_AvlTeLmt	:= to_number(nvl(v_creditlmt,0)) - v_UsdTeLmt;

					select count(*) into b_cnt from mig_bill_fee_tbl where acc_no=v_acc and txn_type in('DEP','REFUN');
if b_cnt>0 then
					select sum(nvl(bal_amt,0)) into v_cashinhand from mig_bill_fee_tbl where acc_no=v_acc and txn_type in('DEP','REFUN');
					else 
					v_cashinhand:=0;
end if;


					select count(*) into t_cnt from cr_lmt_txn where REFNO=v_acc ;

if t_cnt=0 then 
					select	LIMIT_SEQ.nextval into v_LmtId from dual;

					insert into cr_lmt_txn 
					(CRLMT_ID,CRLMT_TYPE,REFNO,PARENT_ID,PRD_CODE,LMT_CCY,CREDIT_LIMIT,CASH_LIMIT,TE_LIMIT,CREDIT_BAL,CASH_BAL,TE_BAL,REC_STATUS,
					MAKER_DT,MAKER_ID,CHECKER_DT,CHECKER_ID,CASH_IN_HAND) values
					(v_LmtId,'ACC',v_acc,'',V_PROD,'356',v_creditlmt,v_cashlmt,v_telmt,v_AvlCrLmt,v_AvlCsLmt,v_AvlTeLmt,'CA',
					current_date,'MIG',current_date,'',v_cashinhand);

					v_balance:=nvl(v_AvlCrLmt,0)+nvl(v_cashinhand,0);

					update carD_account_master set card_acct_bal=v_balance where card_acct=v_acc;

end if; 


			for v_noh in 1..3
			
		loop
		
if(v_noh>0) then
		
							select count(*) into c_cnt from mig_accounts_master where noh=v_noh and acc_no=v_acc;
				
if c_cnt>0 then
							
							select card_no,cin into v_card,v_cin from mig_accounts_master where noh=v_noh and acc_no=v_acc;							
							
							select nvl(TRIM(used_credit_line),0),nvl(TRIM(used_cash_line),0),(nvl(TRIM(used_te_line),0)) 
							into v_UsdCrLmt,v_UsdCsLmt,v_UsdTeLmt 
							from mig_used_tbl where card_no = v_card;
										
							select count(*) into d_cnt from mig_bill_fee_tbl where acc_no=v_acc and txn_type in('DEP','REFUN');
if d_cnt>0 then
							select sum(nvl(bal_amt,0)) into v_cashinhand1 from mig_bill_fee_tbl where card_no=v_card and txn_type in('DEP','REFUN');
							
							else 
										v_cashinhand1:=0;
							end if;
							
							v_AvlCrLmt	:= to_number(nvl(v_creditlmt,0)) - v_UsdCrLmt;
							v_AvlCsLmt	:= to_number(nvl(v_creditlmt,0)) - v_UsdCsLmt;
							v_AvlTeLmt	:= to_number(nvl(v_creditlmt,0)) - v_UsdTeLmt;
							v_balance:=nvl(v_AvlCrLmt,0)+nvl(v_cashinhand1,0);
							

				insert into card_account_master_wk
				(CARD_ACCT,CIN,ACCOUNT_TYPE,CARD_ACCT_CCY,CARD_ACCT_STATUS,CARD_ACCT_BAL,LAST_TXN_REF_NO,LAST_TXN_DTTM,MAKER_ID,MAKER_DTTM,
				CHECKER_ID,CHECKER_DTTM,PRD_CODE,PRIM_FLAG,PRD_NAME,REC_STATUS,REMARKS,OLD_STATUS,CUST_REF_NO,CHARGE_CODE,DEF_FLAG,PLASTIC_CODE,
				CARD_NO,ORDER_REF_NO,NOH,NOC,TXN_REF_NO,PROF_CODE,USAGE_CODE,BILL_DAY,DEL_COUNT,EMAIL_FLAG,LAST_INV_DT,LAST_ST_DT,NEXT_ST_DT,
				SUSP_FLAG,APP_CODE,CHRGE_FROM_DT,CHARGE_TO_DT,OVRLMT_FLAG,BCATEG_CODE)
				(select ACC_NO,CIN,ACC_TYPE,'356',ACC_STATUS,'','','',MAKER_ID,MAKER_DATE,AUTH_ID,AUTH_DATE,V_PROD,PRIM_FLAG,V_PRD_NAME,'CA','MIG','','',CH_CODE,
				DEL_FLAG,'',v_card,(select ORDER_REF_NO from customer_master where cin=v_cin),NOH,NOC,(select TXN_REF_NO from customer_master where cin=v_cin),
				PROF_ID,'',BILL_DAY,DEL_COUNT,EMAIL_FLAG,'',LAST_BILL_DATE,NEXT_BILL_DATE,'','CREDIT','','','','' from mig_accounts_master 
				where nvl(mig_flag,'N')='N' and acc_no=v_acc and card_no=v_card);
				
				update card_account_master_wk set card_acct_bal=nvl(v_balance,0) where card_acct=v_acc;
				
				insert into cardacct_card_link
				(ACC_TYPE,ACCOUNT_TYPE,APP_CODE,CAMPAIGN_DATE,CARD_ACCT,CARD_ACCT_BAL,CARD_ACCT_CCY,CARD_ACCT_STATUS,CARD_NO,CHARGE_CODE,CHARGE_TO_DT,CHECKER_DTTM,CHECKER_ID,
				CHRGE_FROM_DT,CIN,CLASS_CODE,CREDIT_BALANCE,CREDIT_LIMIT,CUST_REF_NO,DEF_FLAG,DEL_COUNT,IB_DISPLAY,LAST_ST_DT,LAST_TXN_DTTM,LAST_TXN_REF_NO,MAKER_DTTM,MAKER_ID,
				NEXT_ST_DT,NOC,NOH,OLD_CAMPAIGN_CODE,OLD_STATUS,PRD_CODE,PRIM_FLAG,PROF_CODE,REC_STATUS,REMARKS,USAGE_CODE)
				(select ACC_TYPE,ACC_TYPE,'CREDIT','',ACC_NO,'','356','',CARD_NO,CH_CODE,'',AUTH_DATE,AUTH_ID,'',CIN,'','','','',
				DEL_FLAG,DEL_COUNT,'',LAST_BILL_DATE,'','',MAKER_DATE,MAKER_ID,NEXT_BILL_DATE,NOC,NOH,'','',V_PROD,PRIM_FLAG,PROF_ID,'CA','MIG','' 
				from mig_accounts_master where nvl(mig_flag,'N')='N' and acc_no=v_acc and card_no=v_card);
				
				update cardacct_card_link set card_acct_bal=v_balance where card_acct=v_acc;
				
				select count(*) into t_cnt from cr_lmt_txn where REFNO=v_card ;
							
if(t_cnt=0) then
				select	LIMIT_SEQ.nextval into v_LmtId from dual;				
				insert into cr_lmt_txn 
				(CRLMT_ID,CRLMT_TYPE,REFNO,PARENT_ID,PRD_CODE,LMT_CCY,CREDIT_LIMIT,CASH_LIMIT,TE_LIMIT,CREDIT_BAL,CASH_BAL,TE_BAL,REC_STATUS,
				MAKER_DT,MAKER_ID,CHECKER_DT,CHECKER_ID,CASH_IN_HAND) values
				(v_LmtId,'CARD',v_card,'',V_PROD,'356',v_creditlmt,v_cashlmt,v_telmt,v_AvlCrLmt,v_AvlCsLmt,v_AvlTeLmt,'CA',
				current_date,'MIG',current_date,'',v_cashinhand1);
end if;
							
end if;
								
end if;
	
		end loop;	


else

for v_noh in 1..3

		loop
		
if(v_noh>0) then
				select count(*) into c_cnt from mig_accounts_master where noh=v_noh and acc_no=v_acc;
				
if c_cnt>0 then
							
				select card_no into v_card from mig_accounts_master where noh=v_noh and acc_no=v_acc;	
							
				insert into card_account_master_wk
				(CARD_ACCT,CIN,ACCOUNT_TYPE,CARD_ACCT_CCY,CARD_ACCT_STATUS,CARD_ACCT_BAL,LAST_TXN_REF_NO,LAST_TXN_DTTM,MAKER_ID,MAKER_DTTM,
				CHECKER_ID,CHECKER_DTTM,PRD_CODE,PRIM_FLAG,PRD_NAME,REC_STATUS,REMARKS,OLD_STATUS,CUST_REF_NO,CHARGE_CODE,DEF_FLAG,PLASTIC_CODE,
				CARD_NO,ORDER_REF_NO,NOH,NOC,TXN_REF_NO,PROF_CODE,USAGE_CODE,BILL_DAY,DEL_COUNT,EMAIL_FLAG,LAST_INV_DT,LAST_ST_DT,NEXT_ST_DT,
				SUSP_FLAG,APP_CODE,CHRGE_FROM_DT,CHARGE_TO_DT,OVRLMT_FLAG,BCATEG_CODE)
				(select ACC_NO,CIN,ACC_TYPE,'356',ACC_STATUS,'','','',MAKER_ID,MAKER_DATE,AUTH_ID,AUTH_DATE,'GLDSTF',PRIM_FLAG,'','CA','MIG','','',CH_CODE,
				DEL_FLAG,'',v_card,(select ORDER_REF_NO from customer_master where cin=v_cin),NOH,NOC,(select TXN_REF_NO from customer_master where cin=v_cin),
				PROF_ID,'',BILL_DAY,DEL_COUNT,EMAIL_FLAG,'',LAST_BILL_DATE,NEXT_BILL_DATE,'','CREDIT','','','','' from mig_accounts_master 
				where nvl(mig_flag,'N')='N' and acc_no=v_acc and card_no=v_card);
				
				update card_account_master_wk set card_acct_bal=nvl(v_balance,0) where card_acct=v_acc;
				
				insert into cardacct_card_link
				(ACC_TYPE,ACCOUNT_TYPE,APP_CODE,CAMPAIGN_DATE,CARD_ACCT,CARD_ACCT_BAL,CARD_ACCT_CCY,CARD_ACCT_STATUS,CARD_NO,CHARGE_CODE,CHARGE_TO_DT,CHECKER_DTTM,CHECKER_ID,
				CHRGE_FROM_DT,CIN,CLASS_CODE,CREDIT_BALANCE,CREDIT_LIMIT,CUST_REF_NO,DEF_FLAG,DEL_COUNT,IB_DISPLAY,LAST_ST_DT,LAST_TXN_DTTM,LAST_TXN_REF_NO,MAKER_DTTM,MAKER_ID,
				NEXT_ST_DT,NOC,NOH,OLD_CAMPAIGN_CODE,OLD_STATUS,PRD_CODE,PRIM_FLAG,PROF_CODE,REC_STATUS,REMARKS,USAGE_CODE)
				(select ACC_TYPE,ACC_TYPE,'CREDIT','',ACC_NO,'','356','',CARD_NO,CH_CODE,'',AUTH_DATE,AUTH_ID,'',CIN,'','','','',
				DEL_FLAG,DEL_COUNT,'',LAST_BILL_DATE,'','',MAKER_DATE,MAKER_ID,NEXT_BILL_DATE,NOC,NOH,'','','GLDSTF',PRIM_FLAG,PROF_ID,'CA','MIG','' 
				from mig_accounts_master where nvl(mig_flag,'N')='N' and acc_no=v_acc and card_no=v_card);
				
				update cardacct_card_link set card_acct_bal=v_balance where card_acct=v_acc;
				
end if;

end if;
		end loop;
end if;

				update mig_accounts_master set mig_flag='Y' where acc_no=v_acc;

				update mig_used_tbl set mig_flag='Y' where account_no=v_acc;

--commit;

end loop;

				dbms_output.put_line('total rows processed '||v_row);

close acc_cursor;

end;

/
