create or replace PROCEDURE REP(from_date in date, to_date in date) as
        a1 VARCHAR2(10);
        a2 VARCHAR2(10);
        a3 VARCHAR2(10);
        a4 VARCHAR2(10);
        a5 VARCHAR2(10);
        a6 VARCHAR2(10);
        a7 VARCHAR2(10);
        a8 VARCHAR2(10);
        a9 VARCHAR2(10);
        a10 VARCHAR2(10);
        a11 VARCHAR2(10);
        a12 VARCHAR2(10);
        a13 VARCHAR2(10);
        a14 VARCHAR2(10);
        a15 VARCHAR2(10);
        a16 VARCHAR2(10);
        a17 VARCHAR2(10);
        a18 VARCHAR2(10);
        a19 VARCHAR2(10);
        a20 VARCHAR2(10);
        a21 VARCHAR2(10);
        a22 VARCHAR2(10);
        a23 VARCHAR2(10);
        a24 VARCHAR2(10);
        b1 number;
        b2 number;
        b3 number;
        b4 number;
        b5 number;
        b6 number(22,4);
        b7 number;
        b8 number(22,4);
        b9 number;
        b9a number(22,4);
        b10 number;
        b11 number(22,4);
        b12a number;
        b12 number(22,4);
        b13a number;
        b13 number(22,4);
        b14 number;
        b15 number(22,4);
        b16 number;
        b17 number(22,4);
        b18 number;
        b19 number(22,4);
        b20 number;
        b21 number(22,4);
        b22 number;
        b23 number(22,4);
        b24 number;
        b25 number(22,4);
        b26 number;
        b27 number(22,4);
        b28 number;
        b29 number(22,4);
        b30 number;
        b31 number(22,4);
        b32 number;
        b33 number(22,4);
        b34 number;
        b35 number(22,4);
        b36 number;
        b37 number(22,4);
        b38 number;
        b39 number(22,4);
        In_date date;
        s1 date;
        CURSOR A  is
        select
        substr(card_no,1,6), count(acc_no)
        from
         accounts_master
        where
         acc_status='O'  and
         trunc(maker_date) >= from_date and
         trunc(maker_date) <= to_date and
         card_no is not null
        group by
        substr(card_no,1,6);
       Begin
        --dbms_output.put_line('procedure started');
        OPEN A;
        LOOP
                FETCH A INTO a1,b1;
        EXIT  WHEN  A%NOTFOUND;
                --dbms_output.put_line('a1='||a1);
                --dbms_output.put_line('b1='||b1);
        BEGIN
                SELECT
                        MAX(BILL_DATE)
                INTO
                        S1
                FROM
                        STMT_TBL
                WHERE
                        SUBSTR(BILL_CARD_NO,1,6)=a1 AND
                        BILL_DATE BETWEEN FROM_DATE AND TO_DATE;
						
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('Billdate nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('Billdate un known eroro'||SQLERRM);
        END;
        b1:=0;
        BEGIN
                select
                        count(acc_no)
                into
                        b1
                from
                        accounts_master
                where
                        acc_status='O'  and
                        substr(card_no,1,6)=a1 and
						trunc(maker_date)<=TO_DATE and
                        card_no is not null
                group by
                        substr(card_no,1,6);
                --dbms_output.put_line('b1='||b1);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('1nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('1un known eroro'||SQLERRM);
        END;
        b2:=0;
        BEGIN
                select
                        substr(card_no,1,6),count(card_no)
                into
                        a2,b2
                from
                        card_master
                where
                        card_status='I' and
                        substr(card_no,1,6)=a1 and
						trunc(v_from_dt)<=TO_DATE
                group by
                        substr(card_no,1,6);
                --dbms_output.put_line('a2='||a2);
                --dbms_output.put_line('b2='||b2);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('2nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('2un known eroro'||SQLERRM);
        END;
        b3:=0;
        BEGIN
                select
                        substr(bill_card_no,1,6),
                        count( account_no)
                into
                        a3,b3
                from
                        stmt_tbl st
                where
                        bill_flag='G' and
                        bill_card_no in (select card_no from accounts_master where acc_no=st.account_no and noh=1) and
                        substr(bill_card_no,1,6) =a1 and
                        BILL_DATE BETWEEN FROM_DATE AND TO_DATE
                group by
                        substr(bill_card_no,1,6);
                --dbms_output.put_line('a3='||a3);
                --dbms_output.put_line('b3='||b3);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('3nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('3un known eroro'||SQLERRM);
        END;
        b4:=0;
        BEGIN
                select
                        substr(bill_card_no,1,6),
                        count( account_no)
                into
                        a4,b4
                from
                        stmt_tbl st
                where
                        bill_flag='G' and
                        outstanding>0 and
                        bill_card_no in (select card_no from accounts_master where acc_no=st.account_no and  noh=1) and
                        substr(bill_card_no,1,6)=a1    and
                        BILL_DATE BETWEEN FROM_DATE AND TO_DATE
                group by
                        substr(bill_card_no,1,6);
                --dbms_output.put_line('a4='||a4);
                --dbms_output.put_line('b4='||b4);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('4nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('4un known eroro'||SQLERRM);
        END;
        b5:=0;
        b6:=0;
        BEGIN
                select
                        substr(bill_card_no,1,6),
                        count( rownum),
                        sum(abs(local_amt))
                into
                        a5,b5,b6
                from
                        bill_fee_tbl
                where
                        txn_type='REFUN' and
                        trunc(in_date) >=from_date and
                        trunc(in_date) <=to_date and
                        substr(bill_card_no,1,6)=a1
                group by
                        substr(bill_card_no,1,6);
                --dbms_output.put_line('a5='||a5);
                --dbms_output.put_line('b5='||b5);
                --dbms_output.put_line('b6='||b6);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('5nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('5un known eroro'||SQLERRM);
        END;
        b7:=0;
        BEGIN
                select
                        substr(bill_card_no,1,6),
                        count(distinct bill_card_no)
                into
                        a6,b7
                from
                        stmt_tbl st,
                        accounts_master am
                where
                        trunc(bill_date)=trunc(s1) and
                        st.account_no=am.acc_no and
                        del_count < 2 and
                        am.noh=1 and
                        substr(bill_card_no,1,6)=a1
                group by
                        substr(bill_card_no,1,6);
                --dbms_output.put_line('a6='||a6);
                --dbms_output.put_line('b7='||b7);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('6nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('6un known eroro'||SQLERRM);
        END;
        b8:=0;
        BEGIN
                select
                        substr(bill_card_no,1,6),
                        sum(outstanding)
                into
                        a7,b8
                from
                        stmt_tbl st,
                        accounts_master am
                where
                        trunc(bill_date)=trunc(s1) and
                        st.account_no=am.acc_no and
                        am.noh=1 and
                        del_count < 2 and
                        substr(bill_card_no,1,6)=a1
                group by
                        substr(bill_card_no,1,6);
                --dbms_output.put_line('a7='||a7);
                --dbms_output.put_line('b8='||b8);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('7nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('7un known eroro'||SQLERRM);
        END;
        b9:=0;
        b9a:=0;
        BEGIN
                select
                        substr(bill_card_no,1,6),
                        count(distinct bill_card_no),
                        sum(outstanding)
                into
                        a8,b9,b9a
                from
                        stmt_tbl st,
                        accounts_master am
                where
                        trunc(bill_date)=trunc(s1) and
                        st.account_no=am.acc_no and
                        am.noh=1 and
                        del_count>=2 and
                        substr(bill_card_no,1,6)=a1
                group by
                        substr(bill_card_no,1,6);
                --dbms_output.put_line('a8='||a8);
                --dbms_output.put_line('b9='||b9);
                --dbms_output.put_line('b9a='||b9a);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('8nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('8un known eroro'||SQLERRM);
        END;
        b10:=0;
        b11:=0;
        BEGIN
                select
                        substr(bill_card_no,1,6),
                        count(account_no),
                        sum((select nvl(outstanding,0) from stmt_tbl
                                where   account_no=st.account_no and
                                bill_date=st.bill_date and
                                rownum<2
                        ))
                into
                        a9,b10,b11
                from
                        stmt_tbl st
                where
                        trunc(bill_date)=trunc(s1) and
                        substr(bill_card_no,1,6)=a1 and
                        account_no in (select acc_no from accounts_master where noh=1) and
                        (
                                nvl((select
                                nvl(outstanding,0) from stmt_tbl
                                where
                                        account_no=st.account_no and
                                        bill_date=st.prev_bill_date and
                                rownum<2),0)
                        )
                        >
                        (
                                nvl((select
                                sum(abs(local_amt)) from bill_Fee_tbl
                                where
                                        acc_no=st.account_no and
                                        txn_type in ('DEP','REFUN','RCHRG_CA','RCHRG_PUR') and
                                        trunc(settle_date) > trunc(st.prev_bill_date) and
                                        trunc(settle_date) < = trunc((select grace_date from stmt_tbl
                                        where account_no=st.account_no and
                                        bill_date=st.prev_bill_Date and
                                        rownum<2))
                                ),0)
                        )
                group by
                        substr(bill_card_no,1,6);
                --dbms_output.put_line('a9='||a9);
                --dbms_output.put_line('b10='||b10);
                --dbms_output.put_line('b11='||b11);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('9nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('9un known eroro'||SQLERRM);
        END;
        b12:=0;
        b12a:=0;
        BEGIN
                select
                        substr(Bill_card_no,1,6),
                        (sum( CUR_CA_INT)+
                        sum(CUR_PUR_INT)+
                        sum(CUR_CAFEE_INT)+
                        sum(FEE_INT)+
                        sum(CUR_CHRG_INT)+
                        sum(CUR_GOVT_FEE_INT)),
                        count(distinct bill_card_no)
                into
                        a10,b12,b12a
                from
                        stmt_tbl
                where
                        bill_date between from_date and to_date and
                        substr(bill_card_no,1,6)=a1
                group by
                        substr(bill_card_no,1,6);
                --dbms_output.put_line('a10='||a10);
                --dbms_output.put_line('b12='||b12);
                --dbms_output.put_line('b12a='||b12a);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('10nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('10un known eroro'||SQLERRM);
        END;
        b13:=0;
        b13a:=0;
        BEGIN
                select
                        substr(bill_card_no,1,6),
                        sum(abs(local_amt)),
                        count(bill_card_no)
                into
                        a11,b13,b13a
                from
                        bill_fee_tbl
                where
                        bill_date between from_date and to_date  and
                        txn_type in ('DEP') and
                        bill_date is not null and
                        substr(bill_card_no,1,6)=a1
                group by
                        substr(bill_card_no,1,6);
                --dbms_output.put_line('a11='||a11);
                --dbms_output.put_line('b13='||b13);
                --dbms_output.put_line('b13a='||b13a);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('11nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('11un known eroro'||SQLERRM);
        END;
        b14:=0;
        b15:=0;
        BEGIN
                select
                        substr(card_no,1,6),
                        sum(settlement_amt),
                        count(rownum)
                into
                        a12,b15,b14
                from
                        crd_host
                where
                        settlement_flag='T' and
                        (trunc(settle_date) between from_date and to_date) and
                        txn_ccy <> '356' and
                        proc_code like '00%' and
                        src_agent_type='VIB'and
                        reversal_flag='N' and
                        response_code='00' and
                        substr(card_no,1,6)=a1
                group by
                        substr(card_no,1,6);
                --dbms_output.put_line('a12='||a12);
                --dbms_output.put_line('b14='||b14);
                --dbms_output.put_line('b15='||b15);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('12nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('12un known eroro'||SQLERRM);
        END;
        b16:=0;
        b17:=0;
        BEGIN
                select
                        substr(card_no,1,6),
                        sum(settlement_amt),
                        count(rownum)
                into
                        a13,b17,b16
                from
                        manu_host
                where
                        settlement_flag='T' and
                        (trunc(settle_date) between from_date and to_date) and
                        txn_ccy <> '356' and
                        proc_code like '00%' and
                        substr(card_no,1,6)=a1
                group by
                        substr(card_no,1,6);
                --dbms_output.put_line('a13='||a13);
                --dbms_output.put_line('b16='||b16);
                --dbms_output.put_line('b17='||b17);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('13nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('13un known eroro'||SQLERRM);
        END;
        b18:=0;
        b19:=0;
        BEGIN
                select
                        substr(card_no,1,6),
                        sum(settlement_amt),
                        count(rownum)
                into
                        a14,b19,b18
                from
                        crd_host
                where
                        settlement_flag='T' and
                        (trunc(settle_date) between from_date and to_date) and
                        txn_ccy = '356' and
                        proc_code like '00%' and
                        src_agent_type='VIB'and
                        reversal_flag='N' and
                        response_code='00' and
                        substr(card_no,1,6)=a1
                group by
                        substr(card_no,1,6);
                --dbms_output.put_line('a14='||a14);
                --dbms_output.put_line('b18='||b18);
                --dbms_output.put_line('b19='||b19);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('14nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('14un known eroro'||SQLERRM);
        END;
        b20:=0;
        b21:=0;
        BEGIN
                select
                        substr(card_no,1,6),
                        sum(settlement_amt),
                        count(rownum)
                into
                        a15,b21,b20
                from
                        manu_host
                where
                        settlement_flag='T' and
                        (trunc(settle_date) between from_date and to_date) and
                        txn_ccy = '356' and
                        proc_code like '00%' and
                        substr(card_no,1,6)=a1
                group by
                        substr(card_no,1,6);
                --dbms_output.put_line('a15='||a15);
                --dbms_output.put_line('b20='||b20);
                --dbms_output.put_line('b21='||b21);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('15nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('15un known eroro'||SQLERRM);
        END;
        b22:=0;
        b23:=0;
        BEGIN
                select
                        substr(card_no,1,6),
                        sum(settlement_amt),
                        count(rownum)
                into
                        a16,b23,b22
                from
                        crd_host
                where
                        settlement_flag='T' and
                        (trunc(settle_date) between from_date and to_date) and
                        txn_ccy <> '356' and
                        proc_code like '01%' and
                        src_agent_type='VIB'and
                        reversal_flag='N' and
                        response_code='00' and
                        substr(card_no,1,6)=a1
                group by
                        substr(card_no,1,6);
                --dbms_output.put_line('a16='||a16);
                --dbms_output.put_line('b22='||b22);
                --dbms_output.put_line('b23='||b23);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('16nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('16un known eroro'||SQLERRM);
        END;
        b24:=0;
        b25:=0;
        BEGIN
                select
                        substr(card_no,1,6),
                        sum(settlement_amt),
                        count(rownum)
                into
                        a17,b25,b24
                from
                        manu_host
                where
                        settlement_flag='T' and
                        (trunc(settle_date) between from_date and to_date) and
                        txn_ccy <> '356' and
                        proc_code like '01%' and
                        substr(card_no,1,6)=a1
                group by
                        substr(card_no,1,6);
                --dbms_output.put_line('a17='||a17);
                --dbms_output.put_line('b24='||b24);
                --dbms_output.put_line('b25='||b25);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('17nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('17un known eroro'||SQLERRM);
        END;
        b26:=0;
        b27:=0;
        BEGIN
                select
                        substr(card_no,1,6),
                        sum(settlement_amt),
                        count(rownum)
                into
                        a18,b27,b26
                from
                        crd_host
                where
                        settlement_flag='T' and
                        (trunc(settle_date) between from_date and to_date) and
                        txn_ccy = '356' and
                        proc_code like '01%' and
                        src_agent_type='VIB'and
                        reversal_flag='N' and
                        response_code='00' and
                        substr(card_no,1,6)=a1
                group by
                        substr(card_no,1,6);
                --dbms_output.put_line('a18='||a18);
                --dbms_output.put_line('b26='||b26);
                --dbms_output.put_line('b27='||b27);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('18nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('18un known eroro'||SQLERRM);
        END;
        b28:=0;
        b29:=0;
        BEGIN
                select
                        substr(card_no,1,6),
                        sum(settlement_amt),
                        count(rownum)
                into
                        a19,b29,b28
                from
                        manu_host
                where
                        settlement_flag='T' and
                        (trunc(settle_date) between from_date and to_date) and
                        txn_ccy = '356' and
                        proc_code like '01%' and
                        substr(card_no,1,6)=a1
                group by
                        substr(card_no,1,6);
                --dbms_output.put_line('a19='||a19);
                --dbms_output.put_line('b28='||b28);
                --dbms_output.put_line('b29='||b29);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('19nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('19un known eroro'||SQLERRM);
        END;
        b30:=0;
        b31:=0;
        BEGIN
                select
                        substr(card_no,1,6),
                        sum(settlement_amt),
                        count(rownum)
                into
                        a20,b31,b30
                from
                        crd_host
                where
                        settlement_flag='T' and
                        (trunc(settle_date) between from_date and to_date) and
                        proc_code like '01%' and
                        src_agent_type='IBA'and
                        reversal_flag='N' and
                        response_code='00' and
                        substr(card_no,1,6)=a1
                group by
                        substr(card_no,1,6);
                --dbms_output.put_line('a20='||a20);
                --dbms_output.put_line('b30='||b30);
                --dbms_output.put_line('b31='||b31);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('20nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('20un known eroro'||SQLERRM);
        END;
        b32:=0;
        b33:=0;
        BEGIN
                select
                        substr(card_no,1,6),
                        sum(settlement_amt),
                        count(rownum)
                into
                        a21,b33,b32
                from
                        crd_host
                where
                        settlement_flag='T' and
                        (trunc(settle_date) between from_date and to_date) and
                        proc_code like '01%' and
                        reversal_flag='N' and
                        response_code='00' and
                        chrg_type ='6011' and
                        substr(card_no,1,6)=a1
                group by
                        substr(card_no,1,6);
                --dbms_output.put_line('a21='||a21);
                --dbms_output.put_line('b32='||b32);
                --dbms_output.put_line('b33='||b33);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('21nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('21un known eroro'||SQLERRM);
        END;
        b34:=0;
        b35:=0;
        BEGIN
                select
                        substr(card_no,1,6),
                        sum(settlement_amt),
                        count(rownum)
                into
                        a22,b35,b34
                from
                        manu_host
                where
                        settlement_flag='T' and
                        (trunc(settle_date) between from_date and to_date) and
                        proc_code like '01%' and
                        chrg_type ='6011' and
                        substr(card_no,1,6)=a1
                group by
                        substr(card_no,1,6);
                --dbms_output.put_line('a22='||a22);
                --dbms_output.put_line('b34='||b34);
                --dbms_output.put_line('b35='||b35);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('22nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('22un known eroro'||SQLERRM);
        END;
        b36:=0;
        b37:=0;
        BEGIN
                select
                        substr(card_no,1,6),
                        sum(settlement_amt),
                        count(rownum)
                into
                        a23,b37,b36
                from
                        crd_host
                where
                        settlement_flag='T' and
                        (trunc(settle_date) between from_date and to_date) and
                        proc_code like '01%' and
                        reversal_flag='N' and
                        response_code='00' and
                        chrg_type <> '6011' and
                        substr(card_no,1,6)=a1
                group by
                        substr(card_no,1,6);
                --dbms_output.put_line('a23='||a23);
                --dbms_output.put_line('b36='||b36);
                --dbms_output.put_line('b37='||b37);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('23nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('23un known eroro'||SQLERRM);
        END;
        b38:=0;
        b39:=0;
        BEGIN
                select
                        substr(card_no,1,6),
                        sum(settlement_amt),
                        count(rownum)
                into
                        a24,b39,b38
                from
                        manu_host
                where
                        settlement_flag='T' and
                        (trunc(settle_date) between from_date and to_date) and
                        proc_code like '01%' and
                        chrg_type <> '6011' and
                        substr(card_no,1,6)=a1
                group by
                        substr(card_no,1,6);
                --dbms_output.put_line('a24='||a24);
                --dbms_output.put_line('b38='||b38);
                --dbms_output.put_line('b39='||b39);
        EXCEPTION
                when NO_DATA_FOUND THEN
                dbms_output.put_line('24nodata found'||SQLERRM);
                when OTHERS THEN
                dbms_output.put_line('24un known eroro'||SQLERRM);
        END;
                b36 := b36+b38;
                b37 := b37+b39;
                b32 := b32+b34;
                b33 := b33+b35;
                b26 := b26+b28;
                b27 := b27+b29;
                b22 := b22+b24;
                b23 := b23+b25;
                b14 := b14+b16;
                b15 := b15+b17;
                b18 := b18+b20;
                b19 := b19+b21;
        BEGIN
                --dbms_output.put_line(a1||'  '||b1||'  '||b2||'  '||b3||'  '||b4||'  '||b5||'  '||b6||'  '||b7||'  '||b8||'  '||b9||'  '||b10||'  '||b11||'  '||b12||'  '||b13||'  '||b14||'  '||b15||'  '||b16||'  '||b17||'  '||b18||'  '||b19||'  '||b20||'  '||b21||'  '||b22||'  '||b23||'  '||b24||'  '||b25||'  '||b26||'  '||b27||'  '||b28||'  '||b29||'  '||b30||'  '||b31||'  '||b32||'  '||b33||'  '||b34||'  '||b35||'  '||b36||'  '||b37||'  '||b38||'  '||b39);
                INSERT INTO QUART_REP VALUES(a1,b1,b2,b3,b4,b5,b6,b7,b8,b9,b9a,b10,b11,b12a,b12,b13a,b13,b14,b15,b18,b19,0,0,b22,b23,b26,b27,b30,b31,b32,b33,b36,b37,to_date(from_date,'DD-MON-YY'),to_date(to_date,'DD-MON-YY'),sysdate);
                --dbms_output.put_line('rec inserted for:'||a1);
        EXCEPTION
                when OTHERS THEN
                dbms_output.put_line('un known eroro'||SQLERRM);
        END;
        END LOOP;
       Close A;
       COMMIT;
       EXCEPTION
        when NO_DATA_FOUND THEN
        dbms_output.put_line('nodata found'||SQLERRM);
        when OTHERS THEN
        dbms_output.put_line('un known eroro'||SQLERRM);
       End;
/

