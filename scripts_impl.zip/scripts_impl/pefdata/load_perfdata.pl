#!/fras/perl/bin/perl

=head1 NAME

load_perfdata.pl - Loads performance data into the eBSD Opsnet database

=head1 SYNOPSIS

load_perfdata.pl [options]

 Options:
   --dbname=STRING  -d     Database name
   --dbconf=STRING         FIS::DBI config file
   --file=FILE      -f     CSV containing data to load
   --killfile=FILE         When exists, exits load early
   --pname=STRING          Prepends STRING to process title
   --help           -h -?  Usage
   --archive        -a     Archive directories
   --logconf        -l     Log4j-style log config
   --verbose        -v     Verboseness level
   --unique         -u     Ensure data deduplication

=head1 OPTIONS

=over 12

=item B<--dbname>

The database name, as defined in FIS::DBI, for the data to be inserted
to.

Default: 'ebsd_report_data'

=item B<--dbconf>

EXplicitly provide a FIS::DBI configuration file to the object. If not provided defaults to base behavior.

=item B<--file>

The location of the CSV file(s) containing data to load. Required fields
are 'timestamp', 'table', 'seriesid', and 'value', though order is
unimportant. Timestamps must be MySQL formatted strings.

Optional fields are 'no_latest_metric'. When provided and true ('1', 'yes', etc.)
the latest_metric table will not be maintained. When missing, or when provided
and false ('', '0', etc.) the series will be updated in the latest_metric table.

Multiple file arguments can be given to process multiple files.
Additionally, wildcard characters will be expanded out into a list of
files to operate on.

=item B<--archive>

The locations, in order, that the script will attempt to archive files
with failed database loads to. The script will attempt to create the
defined path if it does not exist.

Default: '/fras/perfdata/archive/', '~/perfdata/'

=item B<--unique>

When enabled, the script will ensure that timestamps inserted into
series data tables are not duplicated. In effect, instead of performing
an update for every data record input, it will perform a select to see
if there are results for the timestamp and series id and then insert if
not.

=item B<--logconf>

Location of a log4j-style configuration file defining logging
configuation.

Default: '/fras/perfdata/bin/logging.conf'

=item B<--killfile>

The location of the a kill file(s) indicating the process should exit cleanly.
The process will periodically check if file exists and when seen exit.
Multiple killfile arguments can be given to look at multiple locations to
determine exit logic.

By default this is not defined and the logic is not enabled.

=item B<--pname>

When given, the script will prepend the provided string to the process title
used in ps.

=item B<--verbose>

When no L<--logconf> is provided and one or more verbose flags are
provided, logging is configured to log to screen.

=over 2

=item 1: Error level

=item 2: Warn level

=item 3: Info level

=item 4: Debug level

=back

=item B<--help>

Print this help and exit.

=back

=head1 DESCRIPTION

B<load_perfdata.pl> will read the given input file load the contents
into the eBSD Opsnet report database.

=head1 LOGGING

Logging is performed via L<Log::Log4perl>. The following categories are used:

=over 4

=item log4perl.logger.fis.ebsd.app.load_perfdata.app - General application flow messages.

=item log4perl.logger.fis.ebsd.app.load_perfdata.archive - Messages relating to the archiving process.

=item log4perl.logger.fis.ebsd.app.load_perfdata.indata - Messages relating to data reading process.

=item log4perl.logger.fis.ebsd.app.load_perfdata.db - Messages relating to database communication.

=item log4perl.logger.fis.ebsd.app.load_perfdata.queuesize - Messages tracking remaining file queue size when load loop ends prematurely.

=back

=cut

use strict;
use warnings;
use 5.014;

use FIS::DBI;
use Text::CSV::Slurp;
use Getopt::Long;
use Path::Class;
use Pod::Usage;
use DateTime::Format::MySQL;
use Sys::Hostname;
use Log::Log4perl qw/:easy/;
use TryCatch;
use File::Glob qw/:glob/;
use Data::Printer;

###########################
### Init
###########################

### Option parsing
my $opts = { file           => [],
             killfile       => [],
             archive_dirs   => [ '/fras/perfdata/archive/', '~/perfdata/' ],
             logconf        => '/fras/perfdata/bin/logging.conf',
             dsn            => 'ebsd_report_data',
             debug          => 0,
             unique         => 0,
           };

GetOptions ( 'help|?'            => \$opts->{help},
             'dbname|d=s'        => \$opts->{dsn},
             'dbconf=s'          => \$opts->{dbconf},
             'killfile=s@'       => \$opts->{killfile},
             'pname=s'           => \$opts->{pname},
             'file|f=s@'         => \$opts->{file},
             'archive|a=s@'      => \$opts->{archive_dirs},
             'logconf|l=s'       => \$opts->{logconf},
             'unique|u'          => \$opts->{unique},
             'verbose|v+'        => \$opts->{debug},  ### debug levels - 0 = off (default), 1 = error, 2 = warn, 3 = info, 4 = debug.
                                                      ### Ignored if a logconf is provided.
           ) or pod2usage(0);

pod2usage(1) if $opts->{help};

@{$opts->{file}} or do {say 'Input file(s) required!' and exit 1};

### Initialize logging subsystem
init_logger();

### Rename process title if pname arg provided
if ($opts->{pname}) {
    $0 = join(' ', $opts->{pname}, $0);
}

###########################
### Main app
###########################

### Database globals -- statement handles containing prepared statements
my %db_constructor = ( db_name => $opts->{dsn},
                       mode => 'rw',
                       attr => { RaiseError => 0,
                                 HandleError => sub {
                                     local *__ANON__ = 'dbi_handle_error';
                                     logger('db')->error($_[0]);
                                   },
                               },
                     );
if ($opts->{dbconf}) {
    $db_constructor{config_file} = $opts->{dbconf};
}
my ($dbh, $latest_metric_sth, $latest_metric_timestamp_sth, %table_sths);
try {
    $dbh = FIS::DBI->new(%db_constructor)->get_dbh;
    $dbh->{mysql_auto_reconnect} = 1;
    logger('app')->info("opts is '$opts'");
    logger('app')->info("dbh is '$dbh'");
    $latest_metric_sth = $dbh->prepare('UPDATE report_latest_metric SET timestamp = ?, value = ? WHERE seriesid = ?');
    $latest_metric_timestamp_sth = $dbh->prepare('SELECT timestamp from report_latest_metric WHERE seriesid = ?');
}
catch($e) {
    logger('db')->fatal("Unable to prepare database connections: $e");
}

logger('app')->debug('Options hash: ' . np($opts));

### Main loop
### continue reloading until successful, unless short circuited by killfile check.
my $load_success = 0;

while (!$load_success) {
    my $endtime = DateTime->now->add(minutes => 1)->epoch;
    $load_success = load_files($endtime);
    last if killfiles_present(); ### end while if load exited prematurely due to killfile
}

### returns true/false if killfile(s) exist. Returns list of killfiles present on fs.
sub killfiles_present {
    return grep {-e $_ } @{$opts->{killfile}};
}

### Load all files matching input. Returns true if all files loaded and
### false if ended prematurely
sub load_files {
    my ($endtime) = @_;

    my $proccount = 0;
    my @filelist = get_filelist();
    for my $file (@filelist) {
        logger('app')->info("Processing file '$file'");
        store_file($file) and logger('app')->info("File $file loaded into database");
        $proccount++;

        ### Check for premature exit conditions
        if (   ( $endtime and $endtime < DateTime->now->epoch ) ## we've hit endtime
            or ( my @killfiles_seen = killfiles_present() )     ## or killfile exists
           ) {
            my $reason;
            if ($endtime and $endtime < DateTime->now->epoch) {
                $reason = "Reached end time $endtime";
            }
            elsif ( @killfiles_seen ) {
                $reason = 'Killfile(s) exist: ' . join ', ', @killfiles_seen;
            }

            logger('app')->info("Ending file queue load prematurely: $reason");
            logger('queuesize')->info('Remaining file queue size: ' . (@filelist - $proccount));
            return 0; #false
        }
    }
    logger('app')->info("All files in queue completed");
    return 1; #true
}

### glob file args out, aggregate all files to one list, sort result new->old and
### return to caller as list
sub get_filelist  {
    my @filelist;

    ### Iterate over input --file args...
    for my $input (@{$opts->{file}}) {
        ### Use glob() to expand wildcards out...
        for my $file (map { file($_) } bsd_glob($input)){ ### inflate to a Path::Class::File object immediately
            push @filelist, $file;
        }
    }

    ## sort by create time new->old
    @filelist = sort {$b->stat->mtime <=> $a->stat->mtime } @filelist;

    return @filelist;
}

### Read file, insert contents into db. If errors encountered, handles it by
### copying file to a local directory for later inserting. Returns true if
### load succeeded and false if it failed.
sub store_file {
    my ($file) = @_;

    if (my $data = load_file($file)) {
        for my $record (@$data) {
            my $store_latest_metric = 1;
            if (exists $record->{no_latest_metric} and $record->{no_latest_metric}) {
                $store_latest_metric = 0;
            }

            insert_value($record->{table}, $record->{seriesid}, $record->{value}, $record->{timestamp}, $store_latest_metric) or do {
                logger('app')->fatal("DB insert failed; aborting load of $file");
                archive_file($file) or logger('app')->fatal("Unable to archive $file!");
                return ();
            };
        }
    }
    else {
        logger('app')->fatal("File parsing failed; aborting load of $file");
        if (-e $file) {
            archive_file($file) or logger('app')->fatal("Unable to archive $file!");
        }
        return ();
    }

    ### File processing complete
    $file->remove or do {
        logger('app')->warn("Unable to delete loaded $file: $!");
        return ();
    };

    return 1;
}

### Inserts value & timestamp IDed by series into passed table. Also updates
### latest metric table if passed a newer value for the series than the table
### has stored. Returns false if errors loading data and true if data is loaded.
sub insert_value {
    my ($table, $seriesid, $value, $timestamp, $store_latest_metric) = @_;

    ### Create prepared insert statement for table and stash it
    if (!$table) {
        return ();
    }
    if (!$table_sths{$table}{insert} ) {
        $table_sths{$table}{insert} = $dbh->prepare("INSERT into $table ( TimeStamp, Value, SeriesID ) VALUES ( ?, ?, ? )") or do {
            logger('db')->error("Preparing insert into $table failed: " .  $table_sths{$table}{insert}->errstr);
            return ();
        };
    }

    ### If in unique record mode and one is not cached, create a prepared select as well
    if ($opts->{unique} and !$table_sths{$table}{select} ) {
        $table_sths{$table}{select} = $dbh->prepare("SELECT count(*) from $table WHERE TimeStamp = ? AND SeriesID = ?") or do {
            logger('db')->error("Preparing select from $table failed: " .  $table_sths{$table}{select}->errstr);
            return ();
        };
    }

    ### If in unique mode, check to see if a row exists for series and timestamp.
    ### If it does, this will short circuit the insert into both series table and
    ### latest metric table.
    if ($opts->{unique}) {
        my ($rowcount) = $dbh->selectrow_array($table_sths{$table}{select}, {}, $timestamp, $seriesid);
        if ($rowcount) {  ### If we have rows...
            logger('db')->debug("Skipping data insert; data already exists for series: $seriesid, timestamp: $timestamp");
            return 1;
        }
    }

    ### Insert the values
    logger('db')->debug("Inserting into $table: series: $seriesid, timestamp: $timestamp, value: $value");
    $table_sths{$table}{insert}->execute( $timestamp, $value, $seriesid ) or do {
        logger('db')->error("Insert into $table failed: " .  $table_sths{$table}{insert}->errstr);
        return ();
    };

    ### Update the latest metric table if we have a newer time
    if ($store_latest_metric) {
        my $rec_dt = DateTime::Format::MySQL->parse_datetime($timestamp);
        my $latest_dt = get_latest_metric_dt($seriesid);
        logger('db')->debug("Current record time: $rec_dt, Latest metric time: $latest_dt");
        if($rec_dt > $latest_dt) {
            logger('db')->debug("Inserting into report_latest_metric: series: $seriesid, timestamp: $timestamp, value: $value");
            $latest_metric_sth->execute( $timestamp, $value, $seriesid ) or do {
                logger('db')->error('Insert into report_latest_metric failed: ' .  $latest_metric_sth->errstr);
                return ();
            };
        }
    }
    else {
        logger('db')->debug("Series not configured to update latest metric");
    }

    return 1;
}

### Returns timestamp as DateTime object that the DB has recorded for the time of the
### latest value in the latest metrics table. If errors are encountered returns midnight 1/1/1970
sub get_latest_metric_dt {
    my ($seriesid) = @_;

    my $row = $dbh->selectrow_hashref($latest_metric_timestamp_sth, undef, $seriesid) or do {
        my $errstr = $latest_metric_timestamp_sth->errstr ? $latest_metric_timestamp_sth->errstr : "$seriesid not in latest_metric table";
        logger('db')->error('Select from report_latest_metric failed: ' .  $errstr);
        return DateTime->from_epoch(epoch => 0);
    };

    if ($row->{timestamp}) {
        try {
            my $dt = DateTime::Format::MySQL->parse_datetime($row->{timestamp});
            return $dt;
        }
        catch($err) {
            logger('db')->warn("Unable to parse latest_metric timestamp for series $seriesid: $row->{timestamp} caused $err");
            return DateTime->from_epoch(epoch => 0);
        }
    }
    else {
        return DateTime->from_epoch(epoch => 0);
    }
}

### Read input CSV. Returns arrayref of record hashrefs. First line read is used for keys.
### Returns false if errors encountered.
sub load_file {
    my ($file, $recursing) = @_;
    unless (-e $file) {
        logger('indata')->error("Error loading $file: does not exist") ;
        return ();
    }

    ### Try to load file
    my $data;
    try {
        $data = Text::CSV::Slurp->load( file => $file );
    }
    catch ($e) {
        logger('indata')->error("Error loading $file: $e");
        if (!$recursing and $e eq '00') {
            ### This is a Test::CSV readline() error.
            sleep(1);
            return load_file($file, 1);
        }
        else {
            return ();
        }
    }

    ### Validate contents
    unless (     @$data >= 1
             and exists $data->[0]{timestamp}
             and exists $data->[0]{table}
             and exists $data->[0]{seriesid}
             and exists $data->[0]{value}
           ) {
        logger('indata')->error("Error loading $file: invalid contents");
        return ();
    }

    return $data;
}

### Attempts to archive the file to the archive directories configured in the options
### hash, in order. Returns true and stops on first success. If all archiving actions
### fail returns false.
sub archive_file {
    my ($file) = @_;

    logger('archive')->info("Archiving $file");

    for my $dir (@{$opts->{archive_dirs}}) {
        ### Inflate to Path::Class::Dir
        $dir = dir($dir);

        ### Check to see if we're operating out of the archive. If so, just return success.
        if ($file->dir->absolute eq $dir->absolute) {
            logger('archive')->info("Source file $file is already in destination archive $dir, skipping archiving.");
            return 1;
        }

        ### Move the file to the archive. Return success and stop if any move succeeds
        move_file($file, $dir) and return 1;
    }

    ### All backups failed...
    return ();
}

### Moves source file to destination directory. Returns true/false if successful or not
sub move_file {
    my ($srcfile, $destdir) = @_;

    ### Dest file formatted as p01jbrpt01_20140423T180639_18260.dat
    ###                        <hostname>_<  timestamp  >_<pid>.dat
    ### Time is always UTC
    ### When multiple files are archived at the same second, the file will have _1, _2, _3, ... appended after the pid
    my $dt = DateTime->now();
    my $destfilename = join('_', hostname(), DateTime->now->format_cldr('yyyyMMddTHHmmss'), $$);
    my $i = 0;
    my $destfile;
    while ( $i < 50 ) { ### Loop 50 times max. If we're archiving 50 times/sec with all the i/o
                        ### and socket actions in place required for failure leading to archiving
                        ### the system is /seriously/ fast. Ensures preventing infinite loop.
        my $suffix = $i ? "_$i" : '';
        $destfile = file( $destdir, $destfilename . $suffix . '.dat' );
        $i++;
        !-e $destfile and last; ### If destfile doesn't exist exit the loop
    }

    ### Check to make sure the destination exists
    if (!-e $destfile->dir) {
        logger('archive')->info("Destination dir " . $destfile->dir . " does not exist, creating it.");
        try {
            $destfile->dir->mkpath;
        }
        catch($err) {
            logger('archive')->error("Error creating directory: $err");
            return ();
        }
    }

    ### Using copy_to instead of move_to to preserve a copy of the file somewhere
    $srcfile->copy_to($destfile) or do {
        logger('archive')->error("Unable to copy $srcfile: $!");
        return ();
    };

    ### Only run when copy_to returned success
    $srcfile->remove or do {
        logger('archive')->error("Unable to delete archived $srcfile: $!");
        return ();
    };

    logger('archive')->info("Successfully archived $srcfile to $destfile");
    return 1;
}

### Initialize logging system
sub init_logger {
    ### If a log configuration is found, and debug was not set, use it
    if (        $opts->{logconf}
         and -e $opts->{logconf}
         and  ! $opts->{debug}
       ) {
        Log::Log4perl->init($opts->{logconf});
    }
    ### Otherwise fall through to easy_init a screen logger based on the verboseness level
    ### Logging off if no config found and no verboseness set
    else {
        my ($min, $max) = ( 0, 4 );
        my %levels;
        @levels{$min .. $max} = ( $OFF, $ERROR, $WARN, $INFO, $DEBUG );
        my $log_level = $opts->{debug};
        if ($log_level < $min) {
            $log_level = $min;
        }
        elsif ($log_level > $max) {
            $log_level = $max;
        }
        Log::Log4perl->easy_init($levels{$log_level});
    }
}

### Shorthand shim sub to get a logger
### Always returns a Log::Log4perl logger object
sub logger {
    my ($category) = @_;
    if ($category) {
        return Log::Log4perl->get_logger('fis.ebsd.app.load_perfdata.' . $category);
    }
    return Log::Log4perl->get_logger('fis.ebsd.app.load_perfdata');
}

