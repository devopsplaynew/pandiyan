<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
</head>
<body>
    <div id="chartDiv" style="width:100%; height:450px; margin:0 auto;"></div>

</body>
<script src="https://code.jscharting.com/2.9.0/jscharting.js"></script>
<script src="js/wssession.js"></script>
</html>
