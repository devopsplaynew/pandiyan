<!DOCTYPE HTML>
<html style="width:100%;height:100%;padding:0;margin:0;position:relative;text-align:center;">
<head><meta http-equiv="Content-Type" content="text/html; charset=us-ascii"></head><body style="background-color: white; position: relative; text-align: center; padding: 0; margin: 0;display: inline-block;"><div style="position: relative; text-align: center;">
<table style="background-color:#8cd98c; position: relative; text-align: center;" width="900px" cellspacing="0px" cellpadding="5px">
<tr><td colspan="2"><table style="background-color:#4d4d4d;" width="900px" cellspacing="0px" cellpadding="5px">
<tr><td width="10"></td><td width="100" align="left"></td><td width="900" align="right">
<head>
<script>
window.onload = function() {

var chart = new CanvasJS.Chart("chartContainer", {
        animationEnabled: true,
        title: {
                text: "EG EOD Status"
        },
        data: [{
                type: "pie",
                startAngle: 240,
                indexLabel: "{label} {y}",
                dataPoints: [
                        {y: 0, label: "Others"},
                        {y: 0, label: "Ended Not OK"},
                        {y: 0, label: "Executing"},
                        {y: 0, label: "Ended OK"}
                ]
        }]
});
chart.render();

}
</script>
</head>
<body>
<div id="chartContainer" style="height: 300px; width: 900px;background-color:#8cd98c; position: relative; text-align: center;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</table>
</html>
