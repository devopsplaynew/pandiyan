<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
</head>
<body>
    <div id="chartContainer_cebeod" style="width:100%; height:250px; margin:0 auto;"></div>
    <div id="chartContainer_egeod" style="width:100%; height:250px; margin:0 auto;"></div>
</body>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<script src="js/cebeod.js"></script>
<script src="js/egeod.js"></script>
</html>

