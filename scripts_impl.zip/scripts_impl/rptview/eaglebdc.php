<html style="width:100%;height:100%;padding:0;margin:0;position:relative;text-align:center;">
<head><meta http-equiv="Content-Type" content="text/html; charset=us-ascii"></head><body style="background-color: white; position: relative; text-align: center; padding: 0; margin: 0;display: inline-block;"><div style="position: relative; text-align: center;">
<table style="background-color:#ffcc99; position: relative; text-align: center;" width="1200px" cellspacing="0px" cellpadding="5px">
<tr><td colspan="7"><table style="background-color:#4d4d4d;" width="1200px" cellspacing="0px" cellpadding="5px">
<tr><td width="10"></td><td width="100" align="left"></td><td width="650" align="right">
<h1 style="font-family: Courier; color:orange;text-align: center; font-size: 20px">
BDC - Eagle View Report 04/28/2022 00:24:01 AM &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h1></td></tr>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier;font-weight: bold; color: Yellow; font-size: 13px; background-color:#ffcc99"><td align="center" width="300"><a href="https://splunk.fnfis.com/en-US/app/ceb/ceb_retail" style="text-decoration: none;">Splunk Retail Dashboard</a></td>
<td align="center" width="300"><a href="https://splunk.fnfis.com/en-US/app/ceb/ceb_ws" style="text-decoration: none;">Splunk Mobile Dashboard</a></td>
<td align="center" width="300"><a href="https://splunk.fnfis.com/en-US/app/ceb/ceb_sso_banks" style="text-decoration: none;">Splunk SSO Dashboard</a></td>
<td align="center" width="300"><a href="https://splunk.fnfis.com/en-US/app/ceb/ccb_error_monitoring" style="text-decoration: none;">Splunk CCB Monitoring</a></td></tr>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier;font-weight: bold; color: Yellow; font-size: 13px; background-color:#ffcc99"><td align="center" width="300"><a href="https://localhost:84/rptview/ws_active_session.php" style="text-decoration: none;">Mobile Active Sessions</a></td>
<td align="center" width="300"><a href="https://localhost:84/rptview/retail_activessn.php" style="text-decoration: none;">Retail Active Sessions</a></td>
<td align="center" width="300"><a href="https://localhost:84/rptview/responstime.php" style="text-decoration: none;">Retail JVM response time</a></td>
<td align="center" width="300"><a href="https://localhost:84/rptview/responstime.php" style="text-decoration: none;">OAC Dashboard</a></td></tr>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier;font-weight: bold; color: Yellow; font-size: 13px; background-color:#ffcc99"><td align="center" width="300"><a href="https://localhost:84/rptview/ofxcalls.php" style="text-decoration: none;">mbofx Calls</a></td>
<td align="center" width="300"><a href="https://localhost:84/rptview/idscalls.php" style="text-decoration: none;">IDS call hits</a></td>
<td align="center" width="300"><a href="https://localhost:84/rptview/ctmadashboard.php" style="text-decoration: none;">Batch JOb Status</a></td>
<td align="center" width="300"><a href="https://localhost:84/rptview/FAQ.php" style="text-decoration: none;">FAQ</a></td></tr>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier; color: Yellow; font-size: 17px; background-color:#808080"><td align="center" width="105">Server</td>
<td align="center" width="105">JVM</td><td align="center" width="110">CPU</td><td align="center" width="100">DISK</td><td align="center" width="110">MOUNT</td><td align="center" width="90">CONT-M</td><td align="center" width="90">FREE MEMORY</td></tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebap01 </td>
<td align=center width=90 bgcolor=green>NA      </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>45%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebap02 </td>
<td align=center width=90 bgcolor=green>NA      </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>85%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebap50 </td>
<td align=center width=90 bgcolor=green>NA      </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>49%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebap51 </td>
<td align=center width=90 bgcolor=green>NA      </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>69%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebap52 </td>
<td align=center width=90 bgcolor=green>NA      </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>37%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebap53 </td>
<td align=center width=90 bgcolor=green>NA      </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>66%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebwb02 </td>
<td align=center width=90 bgcolor=green>NA      </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>6%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebwb03 </td>
<td align=center width=90 bgcolor=green>NA      </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=#ff8080>5%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebwb04 </td>
<td align=center width=90 bgcolor=green>NA      </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=#ff8080>4%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebwb05 </td>
<td align=center width=90 bgcolor=green>NA      </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=#ff8080>3%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebws01 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>37%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebws02 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>40%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebws03 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>27%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebws04 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>31%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebws14 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>71%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebws15 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>61%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebws20 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>51%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebws21 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>62%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebws23 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=#ff8080>1%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebws24 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=#ff8080>0%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebws25 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=#ff8080>1%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebws26 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=#ff8080>1%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebws28 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=#ff8080>0%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebws29 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=#ff8080>0%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebws30 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=#ff8080>0%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebws31 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=#ff8080>1%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebws40 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>45%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftcebws41 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>39%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftidsap01 </td>
<td align=center width=90 bgcolor=green>NA      </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>35%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftidsap02 </td>
<td align=center width=90 bgcolor=green>NA      </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>65%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftidsws01 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>41%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftidsws02 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=#ff8080>1%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftoacap01 </td>
<td align=center width=90 bgcolor=green>NA      </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>16%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftoacap02 </td>
<td align=center width=90 bgcolor=green>NA      </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>50%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftoacwb01 </td>
<td align=center width=90 bgcolor=green>NA      </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=#ff8080>3%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftoacwb02 </td>
<td align=center width=90 bgcolor=green>NA      </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>32%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftoacwb03 </td>
<td align=center width=90 bgcolor=green>NA      </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=#ff8080>3%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftoacwb04 </td>
<td align=center width=90 bgcolor=green>NA      </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>19%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftoacws01 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>31%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftoacws02 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=green>37%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftofxws01 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=#ff8080>2%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftofxws02 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=#ff8080>2%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 15px; background-color:black">
<td td align=center width=90>bdc1rdftofxws03 </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>Good    </td>
<td align=center width=90 bgcolor=green>1.8.0_321</td>
<td align=center width=85 bgcolor=#ff8080>2%</td>
</tr>
</table>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><tr style="font-family: Courier;font-weight: bold; color: black; font-size: 13px; background-color:#ffcc99"><td align="center" width="775"><a href="https://localhost:84/rptview/lrpreport.html">Click here for Long Running Process View</a></td>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier; color: Yellow; font-size: 13px; background-color:#808080"><td align="center" width="110">SERVER</td>
<td align="center" width="335">PROCESS</td>
<td align="center" width="100">PID</td>
<td align="center" width="100">OWNER</td>
<td align="center" width="100">CPU</td>
<td align="center" width="100">UTIL</td></tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110></td>
<td td align=center width=335></td>
<td td align=center width=100></td>
<td td align=center width=100></td>
<td td align=center width=100></td>
<td align=center width=100></td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftidsws02 </td>
<td td align=center width=335>EG_IDS_Prd_bdc1rdftidsws02</td>
<td td align=center width=100>3802</td>
<td td align=center width=100>wasadmin</td>
<td td align=center width=100>7.4%</td>
<td align=center width=100> 16.1%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftofxws02 </td>
<td td align=center width=335>CEB_MBOFX_2_Prd_bdc1rdftofxws02</td>
<td td align=center width=100>123309</td>
<td td align=center width=100>wasadmin</td>
<td td align=center width=100>19.0%</td>
<td align=center width=100> 20.0%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftcebws29 </td>
<td td align=center width=335>CeBNG_Prd_BDC1RDFTCEBWS29_E_5</td>
<td td align=center width=100>34368</td>
<td td align=center width=100>wasadmin</td>
<td td align=center width=100>9.3%</td>
<td align=center width=100> 7.4%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftcebwb04 </td>
<td td align=center width=335>/opt/traps/bin/pmd</td>
<td td align=center width=100>1223</td>
<td td align=center width=100>root</td>
<td td align=center width=100>2.5%</td>
<td align=center width=100> 4.8%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftoacwb03 </td>
<td td align=center width=335>/opt/traps/bin/pmd</td>
<td td align=center width=100>64149</td>
<td td align=center width=100>root</td>
<td td align=center width=100>1.4%</td>
<td align=center width=100> 5.1%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftoacwb01 </td>
<td td align=center width=335>/opt/traps/bin/pmd</td>
<td td align=center width=100>129314</td>
<td td align=center width=100>root</td>
<td td align=center width=100>1.4%</td>
<td align=center width=100> 5.5%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftcebwb05 </td>
<td td align=center width=335>/opt/traps/bin/pmd</td>
<td td align=center width=100>85715</td>
<td td align=center width=100>root</td>
<td td align=center width=100>2.7%</td>
<td align=center width=100> 4.6%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftcebwb03 </td>
<td td align=center width=335>/opt/traps/bin/pmd</td>
<td td align=center width=100>1221</td>
<td td align=center width=100>root</td>
<td td align=center width=100>2.4%</td>
<td align=center width=100> 4.7%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftcebws26 </td>
<td td align=center width=335>CeBNG_Prd_BDC1RDFTCEBWS26_D_5</td>
<td td align=center width=100>36736</td>
<td td align=center width=100>wasadmin</td>
<td td align=center width=100>8.7%</td>
<td align=center width=100> 8.0%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftcebws28 </td>
<td td align=center width=335>CeBNG_Prd_BDC1RDFTCEBWS28_E_6</td>
<td td align=center width=100>34343</td>
<td td align=center width=100>wasadmin</td>
<td td align=center width=100>8.8%</td>
<td align=center width=100> 8.3%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftcebws31 </td>
<td td align=center width=335>CeBNG_Prd_BDC1RDFTCEBWS31_F_1</td>
<td td align=center width=100>96749</td>
<td td align=center width=100>wasadmin</td>
<td td align=center width=100>9.3%</td>
<td align=center width=100> 7.5%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftcebws30 </td>
<td td align=center width=335>CeBNG_Prd_BDC1RDFTCEBWS30_F_6</td>
<td td align=center width=100>68005</td>
<td td align=center width=100>wasadmin</td>
<td td align=center width=100>9.0%</td>
<td align=center width=100> 8.3%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftcebws23 </td>
<td td align=center width=335>CeBNG_Prd_BDC1RDFTCEBWS23_A_5</td>
<td td align=center width=100>15686</td>
<td td align=center width=100>wasadmin</td>
<td td align=center width=100>11.8%</td>
<td align=center width=100> 7.8%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftofxws03 </td>
<td td align=center width=335>CEB_MBOFX_2_Prd_bdc1rdftofxws03</td>
<td td align=center width=100>23467</td>
<td td align=center width=100>wasadmin</td>
<td td align=center width=100>21.2%</td>
<td align=center width=100> 22.1%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftcebws25 </td>
<td td align=center width=335>CeBNG_Prd_BDC1RDFTCEBWS25_C_6</td>
<td td align=center width=100>74516</td>
<td td align=center width=100>wasadmin</td>
<td td align=center width=100>11.5%</td>
<td align=center width=100> 7.8%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftofxws01 </td>
<td td align=center width=335>CEB_MBOFX_2_Prd_bdc1rdftofxws01</td>
<td td align=center width=100>23745</td>
<td td align=center width=100>wasadmin</td>
<td td align=center width=100>19.3%</td>
<td align=center width=100> 19.0%</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftcebws24 </td>
<td td align=center width=335>CeBNG_Prd_BDC1RDFTCEBWS24_C_2</td>
<td td align=center width=100>121122</td>
<td td align=center width=100>wasadmin</td>
<td td align=center width=100>10.3%</td>
<td align=center width=100> 8.6%</td>
</tr>
</table>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><tr style="font-family: Courier;font-weight: bold; color: black; font-size: 13px; background-color:#ffcc99"><td align="center" width="775">Retail ADM & BATCH Prob Calls</td>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="3px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="3px">
<tr style="font-family: Courier; color: Yellow; font-size: 10px; background-color:#808080"><td align="center" width="40">22A1</td>
<td align="center" width="40">22A2</td>
<td align="center" width="40">22A3</td>
<td align="center" width="40">22A4</td>
<td align="center" width="40">22A5</td>
<td align="center" width="40">22A6</td>
<td align="center" width="40">23A1</td>
<td align="center" width="40">23A2</td>
<td align="center" width="40">23A3</td>
<td align="center" width="40">23A4</td>
<td align="center" width="40">23A5</td>
<td align="center" width="40">23A6</td>
<td align="center" width="40">24C1</td>
<td align="center" width="40">24C2</td>
<td align="center" width="40">24C3</td>
<td align="center" width="40">24C4</td>
<td align="center" width="40">24C5</td>
<td align="center" width="40">24C6</td>
<td align="center" width="40">25C1</td>
<td align="center" width="40">25C2</td>
<td align="center" width="40">25C3</td>
<td align="center" width="40">25C4</td>
<td align="center" width="40">25C5</td>
<td align="center" width="40">25C6</td></tr>
<tr style="font-family: Courier; color: white; font-size: 9px; background-color:black">
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
</tr>
<tr style="font-family: Courier; color: Yellow; font-size: 10px; background-color:#808080"><td align="center" width="40">26D1</td>
<td td align="center" width="40">26D2</td>
<td align="center" width="40">26D3</td>
<td align="center" width="40">26D4</td>
<td align="center" width="40">26D5</td>
<td align="center" width="40">26D6</td>
<td align="center" width="40">27D1</td>
<td align="center" width="40">27D2</td>
<td align="center" width="40">27D3</td>
<td align="center" width="40">27D4</td>
<td align="center" width="40">27D5</td>
<td align="center" width="40">27D6</td>
<td align="center" width="40">28E1</td>
<td align="center" width="40">28E2</td>
<td align="center" width="40">28E3</td>
<td align="center" width="40">28E4</td>
<td align="center" width="40">28E5</td>
<td align="center" width="40">28E6</td>
<td align="center" width="40">29E1</td>
<td align="center" width="40">29E2</td>
<td align="center" width="40">29E3</td>
<td align="center" width="40">29E4</td>
<td align="center" width="40">29E5</td>
<td align="center" width="40">29E6</td></tr>
<tr style="font-family: Courier; color: white; font-size: 9px; background-color:black">
<td td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
</tr>
<table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="3px"> <tr style="font-family: Courier; color: Yellow; font-size: 10px; background-color:#808080"><td align="center" width="50">30F1</td>
<td align="center" width="90">30F2</td>
<td align="center" width="90">30F3</td>
<td align="center" width="90">30F4</td>
<td align="center" width="90">30F5</td>
<td align="center" width="90">30F6</td>
<td align="center" width="90">31F1</td>
<td align="center" width="90">31F2</td>
<td align="center" width="90">31F3</td>
<td align="center" width="90">31F4</td>
<td align="center" width="90">31F5</td>
<td align="center" width="90">31F6</td>
<td align="center" width="90">40C1ADM</td>
<td align="center" width="90">40D1ADM</td>
<td align="center" width="90">41C1ADM</td>
<td align="center" width="90">41D1ADM</td>
<td align="center" width="90">42BATCH</td>
<td align="center" width="90">43BATCH</td>
<td align="center" width="90">44BATCH</td>
<td align="center" width="90">45BATCH</td></tr>
<tr style="font-family: Courier; color: white; font-size: 9px; background-color:black">
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
<td align=center width=90 bgcolor=green>0</td>
</tr>
</table>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><tr style="font-family: Courier;font-weight: bold; color: black; font-size: 13px; background-color:#ffcc99"><td align="center" width="775">WS(Mobile) Prob Calls</td>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="3px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="3px">
<tr style="font-family: Courier; color: Yellow; font-size: 10px; background-color:#808080"><td align="center" width="40">Aggr_01A1</td>
<td align="center" width="40">Agg_01A2</td>
<td align="center" width="40">Agg_02A1</td>
<td align="center" width="40">Agg_02A2</td>
<td align="center" width="40">IBS_01A1</td>
<td align="center" width="40">IBS_01A2</td>
<td align="center" width="40">IBS_02A1</td>
<td align="center" width="40">IBS_02A2</td>
<td align="center" width="40">03D1</td>
<td align="center" width="40">03D2</td>
<td align="center" width="40">03D3</td>
<td align="center" width="40">03D4</td>
<td align="center" width="40">03D5</td>
<td align="center" width="40">03D6</td>
<td align="center" width="40">03D7</td>
<td align="center" width="40">03D8</td>
<td align="center" width="40">04D1</td>
<td align="center" width="40">04D2</td>
<td align="center" width="40">04D3</td>
<td align="center" width="40">04D4</td>
<td align="center" width="40">04D5</td>
<td align="center" width="40">04D6</td>
<td align="center" width="40">04D7</td>
<td align="center" width="40">04D8</td></tr>
<tr style="font-family: Courier; color: white; font-size: 9px; background-color:black">
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
<td align=center width=20 bgcolor=green>0</td>
</tr>
</table>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><tr style="font-family: Courier;font-weight: bold; color: black; font-size: 13px; background-color:#ffcc99"><td align="center" width="775">Https Service calls</td>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier; color: Yellow; font-size: 12px; background-color:#808080"><td align="center" width="45">HTTPS</td>
<td align="center" width="45">02A</td>
<td align="center" width="45">03A</td>
<td align="center" width="45">04A</td>
<td align="center" width="45">05A</td>
<td align="center" width="45">02C</td>
<td align="center" width="45">03C</td>
<td align="center" width="45">04C</td>
<td align="center" width="45">05C</td>
<td align="center" width="45">02D</td>
<td align="center" width="45">03D</td>
<td align="center" width="45">04D</td>
<td align="center" width="45">05D</td>
<td align="center" width="45">02E</td>
<td align="center" width="45">03E</td>
<td align="center" width="45">04E</td>
<td align="center" width="45">05E</td>
<td align="center" width="45">02F</td>
<td align="center" width="45">03F</td>
<td align="center" width="45">04F</td>
<td align="center" width="45">05F</td></tr>
<tr style="font-family: Courier; color: white; font-size: 10px; background-color:black">
<td td align=center width=45>PRE-EAM</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>1</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>1</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>1</td>
<td align=center width=40 bgcolor=green>1</td>
<td align=center width=40 bgcolor=green>1</td>
<td align=center width=40 bgcolor=green>3</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>3</td>
<td align=center width=40 bgcolor=green>1</td>
<td align=center width=40 bgcolor=green>1</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>0</td>
<td align=center width=40 bgcolor=green>2</td>
<td align=center width=40 bgcolor=green>1</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 10px; background-color:black">
<td td align=center width=45>POST-EAM</td>
<td align=center width=40 bgcolor=green>13</td>
<td align=center width=40 bgcolor=green>21</td>
<td align=center width=40 bgcolor=green>16</td>
<td align=center width=40 bgcolor=green>13</td>
<td align=center width=40 bgcolor=green>11</td>
<td align=center width=40 bgcolor=green>15</td>
<td align=center width=40 bgcolor=green>17</td>
<td align=center width=40 bgcolor=green>21</td>
<td align=center width=40 bgcolor=green>14</td>
<td align=center width=40 bgcolor=green>16</td>
<td align=center width=40 bgcolor=green>18</td>
<td align=center width=40 bgcolor=green>22</td>
<td align=center width=40 bgcolor=green>14</td>
<td align=center width=40 bgcolor=green>19</td>
<td align=center width=40 bgcolor=green>13</td>
<td align=center width=40 bgcolor=green>24</td>
<td align=center width=40 bgcolor=green>16</td>
<td align=center width=40 bgcolor=green>14</td>
<td align=center width=40 bgcolor=green>23</td>
<td align=center width=40 bgcolor=green>18</td>
</tr>
</table>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><tr style="font-family: Courier;font-weight: bold; color: black; font-size: 13px; background-color:#ffcc99"><td align="center" width="775">synthetic test login status</td>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier; color: Yellow; font-size: 13px; background-color:#808080"><td align="center" width="140">SYNTH LOGINS</td>
<td align="center" width="100">108</td>
<td align="center" width="100">10N</td>
<td align="center" width="100">10P</td>
<td align="center" width="100">10T</td>
<td align="center" width="100">12Y</td>
<td align="center" width="100">535</td></tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td align=center width=100>STATUS</td>
<td align=center width=100 bgcolor=green>Success</td>
<td align=center width=100 bgcolor=green>Success</td>
<td align=center width=100 bgcolor=green>Success</td>
<td align=center width=100 bgcolor=green>Success</td>
<td align=center width=100 bgcolor=green>Success</td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
</table>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><tr style="font-family: Courier;font-weight: bold; color: black; font-size: 13px; background-color:#ffcc99"><td align="center" width="775">Gigaspace primary Secondary service Status</td>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier; color: Yellow; font-size: 13px; background-color:#808080"><td align="center" width="120">SERVER</td>
<td align="center" width="60">PU1</td>
<td align="center" width="60">PU1_1</td>
<td align="center" width="60">PU2</td>
<td align="center" width="60">PU2_1</td>
<td align="center" width="60">PU3</td>
<td align="center" width="60">PU3_1</td>
<td align="center" width="60">PU4</td>
<td align="center" width="60">PU4_1</td>
<td align="center" width="60">PU5</td>
<td align="center" width="60">PU5_1</td></tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=120></td>
<td align=center width=60 bgcolor=green></td>
<td align=center width=60 bgcolor=green></td>
<td align=center width=60 bgcolor=green></td>
<td align=center width=60 bgcolor=green></td>
<td align=center width=60 bgcolor=green></td>
<td align=center width=60 bgcolor=green></td>
<td align=center width=60 bgcolor=green></td>
<td align=center width=60 bgcolor=green></td>
<td align=center width=60 bgcolor=green></td>
<td align=center width=60 bgcolor=green></td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=120>bdc1rdftcebap50 </td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>0</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=120>bdc1rdftcebap51 </td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>1</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=120>bdc1rdftcebap52 </td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>0</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=120>bdc1rdftcebap53 </td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>1</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>0</td>
<td align=center width=60 bgcolor=green>1</td>
</tr>
</table>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><tr style="font-family: Courier;font-weight: bold; color: black; font-size: 13px; background-color:#ffcc99"><td align="center" width="775">Horizon Banks telnet Validations</td>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier; color: Yellow; font-size: 13px; background-color:#808080"><td align="center" width="90"> IP </td>
<td align="center" width="50"> PORT </td>
<td align="center" width="400">HORIZON_BANKS</td>
<td align="center" width="45">FI</td>
<td align="center" width="50">LPAR</td>
<td align="center" width="100"> STATUS </td></tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.30</td>
<td td align=center width=50>8027</td>
<td td align=center width=400>State Bank of India (California)</td>
<td td align=center width=45>  10X </td>
<td td align=center width=50> HZNWP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.30</td>
<td td align=center width=50>8046</td>
<td td align=center width=400>GBC International Bank  </td>
<td td align=center width=45>  47T </td>
<td td align=center width=50>HZNWP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.30</td>
<td td align=center width=50>8052</td>
<td td align=center width=400>California Business Bank  </td>
<td td align=center width=45>  62T </td>
<td td align=center width=50>HZNWP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.30</td>
<td td align=center width=50>8053</td>
<td td align=center width=400>Lexicon Bank   </td>
<td td align=center width=45>  61T </td>
<td td align=center width=50>HZNWP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.30</td>
<td td align=center width=50>8077</td>
<td td align=center width=400>Nano Banc   </td>
<td td align=center width=45>  48T </td>
<td td align=center width=50>HZNWP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.30</td>
<td td align=center width=50>8081</td>
<td td align=center width=400>New Omni Bank, National Association</td>
<td td align=center width=45>  19T </td>
<td td align=center width=50>HZNWP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.30</td>
<td td align=center width=50>8162</td>
<td td align=center width=400>First Choice Bank  </td>
<td td align=center width=45>  11T </td>
<td td align=center width=50> HZNWP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.30</td>
<td td align=center width=50>8171</td>
<td td align=center width=400>Silvergate Bank   </td>
<td td align=center width=45>  11Y </td>
<td td align=center width=50> HZNWP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.30</td>
<td td align=center width=50>8175</td>
<td td align=center width=400>Infinity Bank   </td>
<td td align=center width=45>  18T </td>
<td td align=center width=50> HZNWP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.30</td>
<td td align=center width=50>8468</td>
<td td align=center width=400>First Commercial Bank (USA) </td>
<td td align=center width=45>  13U </td>
<td td align=center width=50> </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.30</td>
<td td align=center width=50>8702</td>
<td td align=center width=400>Commercial Bank of California </td>
<td td align=center width=45>  12R </td>
<td td align=center width=50> HZNWP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.33</td>
<td td align=center width=50>8049</td>
<td td align=center width=400>Chambers Bank   </td>
<td td align=center width=45>  42T </td>
<td td align=center width=50>HZNCP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.33</td>
<td td align=center width=50>8059</td>
<td td align=center width=400>American Bank, National Association </td>
<td td align=center width=45>  41T </td>
<td td align=center width=50>HZNCP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.33</td>
<td td align=center width=50>8063</td>
<td td align=center width=400>Capital Community Bank  </td>
<td td align=center width=45>  18U </td>
<td td align=center width=50>HZNWP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.33</td>
<td td align=center width=50>8066</td>
<td td align=center width=400>Allegiance Bank   </td>
<td td align=center width=45>  33T </td>
<td td align=center width=50>HZNCP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.33</td>
<td td align=center width=50>8103</td>
<td td align=center width=400>Texas National Bank  </td>
<td td align=center width=45>  11M </td>
<td td align=center width=50> HZNCP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.33</td>
<td td align=center width=50>8105</td>
<td td align=center width=400>Abby Bank   </td>
<td td align=center width=45>  49U </td>
<td td align=center width=50> </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.33</td>
<td td align=center width=50>8176</td>
<td td align=center width=400>Horizon Community Bank  </td>
<td td align=center width=45>  12I </td>
<td td align=center width=50> HZNCP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.33</td>
<td td align=center width=50>8179</td>
<td td align=center width=400>Community Bank of Louisiana </td>
<td td align=center width=45>  18G </td>
<td td align=center width=50>HZNCP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.33</td>
<td td align=center width=50>8335</td>
<td td align=center width=400>Merchants & Manufacturers Bank </td>
<td td align=center width=45>  33U </td>
<td td align=center width=50> </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.33</td>
<td td align=center width=50>8404</td>
<td td align=center width=400>InBank    </td>
<td td align=center width=45>  56T </td>
<td td align=center width=50>HZNCP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.33</td>
<td td align=center width=50>8409</td>
<td td align=center width=400>Fidelity Bank   </td>
<td td align=center width=45>  11Z </td>
<td td align=center width=50> HZNCP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.33</td>
<td td align=center width=50>8534</td>
<td td align=center width=400>Farmers & Stockmens Bank </td>
<td td align=center width=45>  19G </td>
<td td align=center width=50>HZNCP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.33</td>
<td td align=center width=50>8540</td>
<td td align=center width=400>Elkhorn Valley Bank & Trust</td>
<td td align=center width=45>  20G </td>
<td td align=center width=50>HZNCP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.33</td>
<td td align=center width=50>8731</td>
<td td align=center width=400>First Community Bank  </td>
<td td align=center width=45>  46T </td>
<td td align=center width=50> </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.33</td>
<td td align=center width=50>8739</td>
<td td align=center width=400>Dallas Capital Bank  </td>
<td td align=center width=45>  12A </td>
<td td align=center width=50> </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.39</td>
<td td align=center width=50>29160</td>
<td td align=center width=400>Marquette Bank   </td>
<td td align=center width=45>  65T </td>
<td td align=center width=50> </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.39</td>
<td td align=center width=50>29622</td>
<td td align=center width=400>M.Y. Safra Bank, FSB </td>
<td td align=center width=45>  87T </td>
<td td align=center width=50>HZNEP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.39</td>
<td td align=center width=50>2964</td>
<td td align=center width=400>National Capital Bank  </td>
<td td align=center width=45>  14U </td>
<td td align=center width=50>HZNEP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.39</td>
<td td align=center width=50>2970</td>
<td td align=center width=400>Citizens Trust Bank  </td>
<td td align=center width=45>  20U </td>
<td td align=center width=50>HZNEP1 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.42</td>
<td td align=center width=50>20013</td>
<td td align=center width=400>Amalgamated Bank   </td>
<td td align=center width=45>  10G </td>
<td td align=center width=50> HZNEP2 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.42</td>
<td td align=center width=50>20020</td>
<td td align=center width=400>First Community Bank  </td>
<td td align=center width=45>  12Z </td>
<td td align=center width=50> HZNEP2 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.42</td>
<td td align=center width=50>20040</td>
<td td align=center width=400>Provident State Bank, Inc. </td>
<td td align=center width=45>  17G </td>
<td td align=center width=50>HZNEP2 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.42</td>
<td td align=center width=50>20108</td>
<td td align=center width=400>Southern First Bank  </td>
<td td align=center width=45>  10Q </td>
<td td align=center width=50> HZNEP2 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.42</td>
<td td align=center width=50>20134</td>
<td td align=center width=400>Community First Bank  </td>
<td td align=center width=45>  20T </td>
<td td align=center width=50>HZNEP2 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.42</td>
<td td align=center width=50>20142</td>
<td td align=center width=400>Superior National Bank & Trust</td>
<td td align=center width=45>  11W </td>
<td td align=center width=50> HZNEP2 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.42</td>
<td td align=center width=50>20418</td>
<td td align=center width=400>Quontic Bank   </td>
<td td align=center width=45>  43T </td>
<td td align=center width=50> </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.48</td>
<td td align=center width=50>30013</td>
<td td align=center width=400>McHenry Savings Bank  </td>
<td td align=center width=45>  10K </td>
<td td align=center width=50> HZNCP2 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.48</td>
<td td align=center width=50>30028</td>
<td td align=center width=400>University Bank   </td>
<td td align=center width=45>  11E </td>
<td td align=center width=50> HZNCP2 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.48</td>
<td td align=center width=50>30033</td>
<td td align=center width=400>Security First Bank  </td>
<td td align=center width=45>  10U </td>
<td td align=center width=50> HZNCP2 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.48</td>
<td td align=center width=50>30035</td>
<td td align=center width=400>Clinton National Bank  </td>
<td td align=center width=45>  11C </td>
<td td align=center width=50> HZNCP2 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.48</td>
<td td align=center width=50>30043</td>
<td td align=center width=400>Security State Bank & Trust</td>
<td td align=center width=45>  70T </td>
<td td align=center width=50>HZNCP2 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.48</td>
<td td align=center width=50>30049</td>
<td td align=center width=400>Farmers State Bank  </td>
<td td align=center width=45>  84T </td>
<td td align=center width=50>HZNCP2 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.48</td>
<td td align=center width=50>30138</td>
<td td align=center width=400>Community First Bank  </td>
<td td align=center width=45>  11P </td>
<td td align=center width=50> HZNCP2 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.48</td>
<td td align=center width=50>30167</td>
<td td align=center width=400>First Community Bank  </td>
<td td align=center width=45>  45U </td>
<td td align=center width=50> </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.48</td>
<td td align=center width=50>30241</td>
<td td align=center width=400>MapleMark Bank   </td>
<td td align=center width=45>  38T </td>
<td td align=center width=50>HZNCP2 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.48</td>
<td td align=center width=50>30265</td>
<td td align=center width=400>First Citizens National Bank </td>
<td td align=center width=45>  12T </td>
<td td align=center width=50> </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.48</td>
<td td align=center width=50>30420</td>
<td td align=center width=400>Relyance Bank, National Association </td>
<td td align=center width=45>  85T </td>
<td td align=center width=50>HZNCP2 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.56</td>
<td td align=center width=50>40016</td>
<td td align=center width=400>Old Dominion National Bank </td>
<td td align=center width=45>  10I </td>
<td td align=center width=50> HZNEP4 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.56</td>
<td td align=center width=50>40022</td>
<td td align=center width=400>John Marshall Bank  </td>
<td td align=center width=45>  11I </td>
<td td align=center width=50> HZNEP4 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.56</td>
<td td align=center width=50>40031</td>
<td td align=center width=400>TC Federal Bank  </td>
<td td align=center width=45>  42U </td>
<td td align=center width=50> </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.56</td>
<td td align=center width=50>40145</td>
<td td align=center width=400>The Harbor Bank of Maryland</td>
<td td align=center width=45>  48U </td>
<td td align=center width=50> </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.56</td>
<td td align=center width=50>40321</td>
<td td align=center width=400>Providence Bank   </td>
<td td align=center width=45>  12C </td>
<td td align=center width=50> HZNEP4 </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=90>10.118.32.56</td>
<td td align=center width=50>40826</td>
<td td align=center width=400>Drummond Community Bank  </td>
<td td align=center width=45>  64T </td>
<td td align=center width=50> </td>
<td align=center width=100 bgcolor=green> Success</td>
</tr>
</table>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><tr style="font-family: Courier;font-weight: bold; color: black; font-size: 13px; background-color:#ffcc99"><td align="center" width="775">Successfull Logins in past 1 hour</td>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier; color: Yellow; font-size: 13px; background-color:#808080"><td align="center" width="485">APPLICATION</td>
<td align="center" width="165">VOLUMES(1hour)</td>
<td align="center" width="100"> STATUS </td></tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=485>Online Account Creation</td>
<td align=center width=165>	 1</td>
<td align=center width=100 bgcolor=green>GOOD</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 13px; background-color:black">
<td td align=center width=485>Consumer e-Banking</td>
<td align=center width=165>     25138</td>
<td align=center width=100 bgcolor=green>GOOD</td>
</tr>
</table>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><tr style="font-family: Courier;font-weight: bold; color: black; font-size: 13px; background-color:#ffcc99"><td align="center" width="775">OAC Service Status</td>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier; color: Yellow; font-size: 13px; background-color:#808080"><td align="center" width="110">SERVER</td>
<td align="center" width="525">APPLICATION SERVICE NAME</td>
<td align="center" width="100"> STATUS </td></tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftoacap01</td>
<td align=center width=525>_mi_server</td>
<td align=center width=100 bgcolor=#FFC300>NOT RUNNING</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftoacap01</td>
<td align=center width=525>appserver</td>
<td align=center width=100 bgcolor=#FFC300>NOT RUNNING</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftoacap01</td>
<td align=center width=525>_email_server</td>
<td align=center width=100 bgcolor=#FFC300>NOT RUNNING</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftoacap02</td>
<td align=center width=525>_mi_server</td>
<td align=center width=100 bgcolor=#FFC300>NOT RUNNING</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftoacap02</td>
<td align=center width=525>appserver</td>
<td align=center width=100 bgcolor=#FFC300>NOT RUNNING</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>bdc1rdftoacap02</td>
<td align=center width=525>_email_server</td>
<td align=center width=100 bgcolor=#FFC300>NOT RUNNING</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>pdc2rdftoacap01</td>
<td align=center width=525>_mi_server</td>
<td align=center width=100 bgcolor=green>RUNNING</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>pdc2rdftoacap01</td>
<td align=center width=525>appserver</td>
<td align=center width=100 bgcolor=green>RUNNING</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>pdc2rdftoacap01</td>
<td align=center width=525>_email_server</td>
<td align=center width=100 bgcolor=green>RUNNING</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>pdc2rdftoacap02</td>
<td align=center width=525>_mi_server</td>
<td align=center width=100 bgcolor=#FFC300>NOT RUNNING</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>pdc2rdftoacap02</td>
<td align=center width=525>appserver</td>
<td align=center width=100 bgcolor=#FFC300>NOT RUNNING</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=110>pdc2rdftoacap02</td>
<td align=center width=525>_email_server</td>
<td align=center width=100 bgcolor=#FFC300>NOT RUNNING</td>
</tr>
</table>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><tr style="font-family: Courier;font-weight: bold; color: black; font-size: 13px; background-color:#ffcc99"><td align="center" width="775">Ping VIP Validations</td>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=655>cebws-aggr.prod.local</td>
<td align=center width=120 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=655>CeBWS-comcore.prod.local</td>
<td align=center width=120 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=655>CeBWS-inhouse.prod.local</td>
<td align=center width=120 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=655>CeBWS.prod.local</td>
<td align=center width=120 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=655>CeBWS-prod-test.prod.local</td>
<td align=center width=120 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=655>voltage-pp-0000.prod.local</td>
<td align=center width=120 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=655>ceb-mbofx.prod.local</td>
<td align=center width=120 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=655>ih-prd.prod.local</td>
<td align=center width=120 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=655>ih2-prd.prod.local</td>
<td align=center width=120 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=655>ih-prd2.prod.local</td>
<td align=center width=120 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=655>ih2-prd2.prod.local</td>
<td align=center width=120 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=655>ih-excust-other.fisglobal.com</td>
<td align=center width=120 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=655>oacadmin.prod.local</td>
<td align=center width=120 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=655>oacrest.prod.local</td>
<td align=center width=120 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=655>oacservices.prod.local</td>
<td align=center width=120 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=655>egids-dr.prod.local</td>
<td align=center width=120 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=655>egids-prd.prod.local</td>
<td align=center width=120 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=655>veservices.prod.local</td>
<td align=center width=120 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=655>ii.prod.local</td>
<td align=center width=120 bgcolor=green>Success</td>
</tr>
</table>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><tr style="font-family: Courier;font-weight: bold; color: black; font-size: 13px; background-color:#ffcc99"><td align="center" width="775"><a href="https://localhost:84/rptview/certreport.html">Click here for slapi Certificate Expiry details View</a></td>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier; color: Yellow; font-size: 13px; background-color:#808080"><td align="center" width="115">Server</td>
<td align="center" width="400">Slapi Certificate</td>
<td align="center" width="100">Status</td></tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115></td>
<td align=center width=535></td>
<td align=center width=100 bgcolor=#FFC300></td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115></td>
<td align=center width=535></td>
<td align=center width=100 bgcolor=#FFC300></td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115></td>
<td align=center width=535></td>
<td align=center width=100 bgcolor=#FFC300></td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115></td>
<td align=center width=535></td>
<td align=center width=100 bgcolor=#FFC300></td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115> bdc1rdftcebws42 </td>
<td align=center width=535>083_041201114/LNB083-PRD_pubCert.pem</td>
<td align=center width=100 bgcolor=#FFC300>7days</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115> bdc1rdftcebws42 </td>
<td align=center width=535>279_104001808/CEB279BI-PRD_pubCert.pem</td>
<td align=center width=100 bgcolor=#FFC300>22days</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115> bdc1rdftcebws42 </td>
<td align=center width=535>510_061204654/CEB510BI-PRD_pubCert.pem</td>
<td align=center width=100 bgcolor=#FFC300>22days</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115> bdc1rdftcebws42 </td>
<td align=center width=535>606_061204463/CEB606BI-PRD_pubCert.pem</td>
<td align=center width=100 bgcolor=#FFC300>22days</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115> bdc1rdftcebws43 </td>
<td align=center width=535>083_041201114/LNB083-PRD_pubCert.pem</td>
<td align=center width=100 bgcolor=#FFC300>7days</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115> bdc1rdftcebws43 </td>
<td align=center width=535>279_104001808/CEB279BI-PRD_pubCert.pem</td>
<td align=center width=100 bgcolor=#FFC300>22days</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115> bdc1rdftcebws43 </td>
<td align=center width=535>510_061204654/CEB510BI-PRD_pubCert.pem</td>
<td align=center width=100 bgcolor=#FFC300>22days</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115> bdc1rdftcebws43 </td>
<td align=center width=535>606_061204463/CEB606BI-PRD_pubCert.pem</td>
<td align=center width=100 bgcolor=#FFC300>22days</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115> bdc1rdftcebws44 </td>
<td align=center width=535>083_041201114/LNB083-PRD_pubCert.pem</td>
<td align=center width=100 bgcolor=#FFC300>7days</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115> bdc1rdftcebws44 </td>
<td align=center width=535>279_104001808/CEB279BI-PRD_pubCert.pem</td>
<td align=center width=100 bgcolor=#FFC300>22days</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115> bdc1rdftcebws44 </td>
<td align=center width=535>510_061204654/CEB510BI-PRD_pubCert.pem</td>
<td align=center width=100 bgcolor=#FFC300>22days</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115> bdc1rdftcebws44 </td>
<td align=center width=535>606_061204463/CEB606BI-PRD_pubCert.pem</td>
<td align=center width=100 bgcolor=#FFC300>22days</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115> bdc1rdftcebws45 </td>
<td align=center width=535>083_041201114/LNB083-PRD_pubCert.pem</td>
<td align=center width=100 bgcolor=#FFC300>7days</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115> bdc1rdftcebws45 </td>
<td align=center width=535>279_104001808/CEB279BI-PRD_pubCert.pem</td>
<td align=center width=100 bgcolor=#FFC300>22days</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115> bdc1rdftcebws45 </td>
<td align=center width=535>510_061204654/CEB510BI-PRD_pubCert.pem</td>
<td align=center width=100 bgcolor=#FFC300>22days</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115> bdc1rdftcebws45 </td>
<td align=center width=535>606_061204463/CEB606BI-PRD_pubCert.pem</td>
<td align=center width=100 bgcolor=#FFC300>22days</td>
</tr>
</table>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><tr style="font-family: Courier;font-weight: bold; color: black; font-size: 13px; background-color:#ffcc99"><td align="center" width="775">OAC-IMS telnet Validations</td>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier; color: Yellow; font-size: 13px; background-color:#808080"><td align="center" width="45">IMSA</td>
<td align="center" width="45">IMSC</td>
<td align="center" width="45">IMSE</td>
<td align="center" width="45">IMSF</td>
<td align="center" width="45">IMSG</td>
<td align="center" width="45">IMSH</td>
<td align="center" width="45">IMSI</td>
<td align="center" width="45">IMSK</td>
<td align="center" width="45">IMSL</td>
<td align="center" width="45">IMSM</td>
<td align="center" width="45">IMSO</td>
<td align="center" width="45">IMSQ</td>
<td align="center" width="45">IMSR</td>
<td align="center" width="45">IMSS</td>
<td align="center" width="45">IMST</td>
<td align="center" width="45">IMSV</td></tr>
<tr style="font-family: Courier; color: white; font-size: 14px; background-color:green">
<td td align=center width=40> Good</td>
<td align=center width=40 bgcolor=green> Good</td>
<td align=center width=40 bgcolor=green> Good</td>
<td align=center width=40 bgcolor=green> Good</td>
<td align=center width=40 bgcolor=green> Good</td>
<td align=center width=40 bgcolor=green> Good</td>
<td align=center width=40 bgcolor=green> Good</td>
<td align=center width=40 bgcolor=green> Good</td>
<td align=center width=40 bgcolor=green> Good</td>
<td align=center width=40 bgcolor=green> Good</td>
<td align=center width=40 bgcolor=green> Good</td>
<td align=center width=40 bgcolor=green> Good</td>
<td align=center width=40 bgcolor=green> Good</td>
<td align=center width=40 bgcolor=green> Good</td>
<td align=center width=40 bgcolor=green> Good</td>
<td align=center width=40 bgcolor=green> Good</td>
</tr>
</table>
</table></td></tr><tr><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><td colspan="0"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="0px"><tr style="font-family: Courier; color: black;font-weight: bold; font-size: 13px; background-color:#ffcc99"><td align="center" width="775">FTP Validations</td>
</table></td></tr><tr><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><td colspan="8"><table style="background-color:#ffcc99;" width="1200px" cellspacing="0px" cellpadding="1px"><tr style="font-family: Courier; color: Yellow; font-size: 13px; background-color:#808080"><td align="center" width="115">FTP_NAME</td>
<td align="center" width="400"> FTP_SERVER </td>
<td align="center" width="100"> STATUS </td></tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>EAS-HOST       </td>
<td align=center width=535> pdc2repongap03           </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>EAS-HOST       </td>
<td align=center width=535> bdc1repongap03           </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>EAS-VIP        </td>
<td align=center width=535> ngeas-batch.prod.local   </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>EC             </td>
<td align=center width=535> BDC1REPOIECWS04          </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>EC             </td>
<td align=center width=535> BDC1REPOIECWS05          </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>EII            </td>
<td align=center width=535> iiprdfs01.prod.local     </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>EII            </td>
<td align=center width=535> bdc1rctoiiap01           </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>EII            </td>
<td align=center width=535> bdc1rctoiiap02           </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>EII            </td>
<td align=center width=535> bdc1rctoiiap03           </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>EII            </td>
<td align=center width=535> bdc1rctoiiap04           </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>EII            </td>
<td align=center width=535> pdc1rctoiiap01           </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>EII            </td>
<td align=center width=535> pdc1rctoiiap02           </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>EII            </td>
<td align=center width=535> pdc1rctoiiap03           </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>EII            </td>
<td align=center width=535> pdc1rctoiiap04           </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>IDS-ESP        </td>
<td align=center width=535> bdc1rdftidsap01          </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>IDS-ESP        </td>
<td align=center width=535> bdc1rdftidsap02          </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>IDS-ESP        </td>
<td align=center width=535> PDC2RDFTIDSAP01          </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>IDS-ESP        </td>
<td align=center width=535> PDC2RDFTIDSAP02          </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>IDS-VE         </td>
<td align=center width=535> pdc2rdftoacap01          </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>IDS-VE         </td>
<td align=center width=535> pdc2rdftoacap02          </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>IDS-VE         </td>
<td align=center width=535> bdc1rdftoacap01          </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>IDS-VE         </td>
<td align=center width=535> bdc1rdftoacap02          </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>OAC            </td>
<td align=center width=535> bdc1rdftoacap01          </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>OAC            </td>
<td align=center width=535> bdc1rdftoacap02          </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>EPP-BPM        </td>
<td align=center width=535> bpm-backoffice.fnfis.com </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>MOVEIT         </td>
<td align=center width=535> sftbdc.prod.local        </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
<tr style="font-family: Courier; color: white; font-size: 12px; background-color:black">
<td td align=center width=115>EPP            </td>
<td align=center width=535> sftp-prd-brbatch.prod.local </td>
<td align=center width=100 bgcolor=green>Success</td>
</tr>
</table>
