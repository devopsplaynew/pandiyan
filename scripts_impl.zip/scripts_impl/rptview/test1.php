<html>
<body>
<?php include 'https://localhost:84/rptview/ctmeod_ceb.php';?>
<?php include 'https://localhost:84/rptview/ctmeod_eg.php';?>
</body>
</html>
