<html>
<body>
<?php include '/fras/opsnet/rptview/ctmchart.php';?>
<?php include '/fras/opsnet/rptview/ctmarpt.php';?>
</body>
</html>

