<!DOCTYPE HTML>
<html>
<head>
<script>
window.onload = function() {

var chart = new CanvasJS.Chart("chartContainer", {
        animationEnabled: true,
        title: {
                text: "CeB EOD Status"
        },
        data: [{
                type: "pie",
                startAngle: 240,
                indexLabel: "{label} {y}",
                dataPoints: [
                        {y: 0, label: "Others"},
                        {y: 0, label: "Ended Not OK"},
                        {y: 0, label: "Executing"},
                        {y: 76, label: "Ended OK"}
                ]
        }]
});
chart.render();

}
</script>
</head>
<body>
<div id="chartContainer" style="height: 300px; width: 900px;background-color:#8cd98c; position: relative; text-align: center;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</html>
