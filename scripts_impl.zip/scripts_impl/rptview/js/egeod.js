window.onload = function() {

var chart_eod = new CanvasJS.Chart("chartContainer_egeod", {
        animationEnabled: true,
        title: {
                text: "EG EOD Status"
        },
        data: [{
                type: "pie",
                startAngle: 240,
                indexLabel: "{label} {y}",
                dataPoints: [
                        {y: 10, label: "Others"},
                        {y: 3, label: "Ended Not OK"},
                        {y: 394, label: "Executing"},
                        {y: 248, label: "Ended OK"}
                ]
        }]
});
chart_eod.render();

}

