window.onload = function() {

var chart_cebeod = new CanvasJS.Chart("chartContainer_cebeod", {
        animationEnabled: true,
        title: {
                text: "CeB EOD Status"
        },
        data: [{
                type: "pie",
                startAngle: 240,
                indexLabel: "{label} {y}",
                dataPoints: [
                        {y: 0, label: "Others1"},
                        {y: 0, label: "Ended Not OK1"},
                        {y: 0, label: "Executing1"},
                        {y: 19, label: "Ended OK1"}
                ]
        }]
});
chart_cebeod.render();

}
