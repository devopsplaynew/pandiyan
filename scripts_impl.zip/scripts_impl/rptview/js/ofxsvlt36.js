fetch('https://localhost:84/rptview/data/ofx_cals.csv')
        .then(function (response) {
                return response.text();
        })
        .then(function (text) {
                let series = csvToSeriesD(text);
                renderChartD(series);
        })
        .catch(function (error) {
                console.log(error);
        });

function csvToSeriesD(text) {
        const lifeExp = 'status';
        let dataAsJson = JSC.csv2Json(text);
        let OFX01_1_SERVLT_ACRQ = [], OFX01_2_SERVLT_ACRQ = [], OFX02_1_SERVLT_ACRQ = [], OFX02_2_SERVLT_ACRQ = [], OFX03_1_SERVLT_ACRQ = [], OFX03_2_SERVLT_ACRQ = [], OFX01_1_ERR_36 = [], OFX01_2_ERR_36 = [], OFX02_1_ERR_36 = [], OFX02_2_ERR_36 = [], OFX03_1_ERR_36 = [], OFX03_2_ERR_36 = [];

        dataAsJson.forEach(function (row) {
                        if (row.jvm === 'OFX01_1_SERVLT_ACRQ') {
                                OFX01_1_SERVLT_ACRQ.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX01_2_SERVLT_ACRQ') {
                                OFX01_2_SERVLT_ACRQ.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX02_1_SERVLT_ACRQ') {
                                OFX02_1_SERVLT_ACRQ.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX02_2_SERVLT_ACRQ') {
                                OFX02_2_SERVLT_ACRQ.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX03_1_SERVLT_ACRQ') {
                                OFX03_1_SERVLT_ACRQ.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX03_2_SERVLT_ACRQ') {
                                OFX03_2_SERVLT_ACRQ.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX01_1_ERR_36') {
                                OFX01_1_ERR_36.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX01_2_ERR_36') {
                                OFX01_2_ERR_36.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX02_1_ERR_36') {
                                OFX02_1_ERR_36.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX02_2_ERR_36') {
                                OFX02_2_ERR_36.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX03_1_ERR_36') {
                                OFX03_1_ERR_36.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX03_2_ERR_36') {
                                OFX03_2_ERR_36.push({x: row.times, y: row[lifeExp]});
                        }
        });
        return [
                {name: 'OFX01_1_SERVLT_ACRQ', points: OFX01_1_SERVLT_ACRQ},
                {name: 'OFX01_2_SERVLT_ACRQ', points: OFX01_2_SERVLT_ACRQ},
                {name: 'OFX02_1_SERVLT_ACRQ', points: OFX02_1_SERVLT_ACRQ},
                {name: 'OFX02_2_SERVLT_ACRQ', points: OFX02_2_SERVLT_ACRQ},
                {name: 'OFX03_1_SERVLT_ACRQ', points: OFX03_1_SERVLT_ACRQ},
                {name: 'OFX03_2_SERVLT_ACRQ', points: OFX03_2_SERVLT_ACRQ},
                {name: 'OFX01_1_ERR_36', points: OFX01_1_ERR_36},
                {name: 'OFX01_2_ERR_36', points: OFX01_2_ERR_36},
                {name: 'OFX02_1_ERR_36', points: OFX02_1_ERR_36},
                {name: 'OFX02_2_ERR_36', points: OFX02_2_ERR_36},
                {name: 'OFX03_1_ERR_36', points: OFX03_1_ERR_36},
                {name: 'OFX03_2_ERR_36', points: OFX03_2_ERR_36}
];
}

function renderChartD(series) {
        JSC.Chart('chartDivD', {
                series: series
        });
}


