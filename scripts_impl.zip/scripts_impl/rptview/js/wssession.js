fetch('https://localhost:84/rptview/data/ws_activessn.csv')
        .then(function (response) {
                return response.text();
        })
        .then(function (text) {
                let series = csvToSeries(text);
                renderChart(series);
        })
        .catch(function (error) {
                console.log(error);
        });

function csvToSeries(text) {
        const lifeExp = 'status';
        let dataAsJson = JSC.csv2Json(text);
        let WS01_A1 = [], WS01_A2 = [], IBS01_1 = [], IBS01_2 = [], WS02_A1 = [], WS02_A2 = [], IBS02_1 = [], IBS02_2 = [], WS03_D1 = [], WS03_D2 = [] ,WS03_D3 = [], WS03_D4 = [], WS03_D5 = [], WS03_D6 = [], WS04_D1 = [], WS04_D2 = [], WS04_D3 = [], WS04_D4 = [], WS04_D5 = [], WS04_D6 = [];

        dataAsJson.forEach(function (row) {

                        if (row.jvm === 'WS01_A1') {
                                WS01_A1.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS01_A2') {
                                WS01_A2.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'IBS01_1') {
                                IBS01_1.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'IBS01_2') {
                                IBS01_2.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS02_A1') {
                                WS02_A1.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS02_A2') {
                                WS02_A2.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'IBS02_1') {
                                IBS02_1.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'IBS02_2') {
                                IBS02_2.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS03_D1') {
                                WS03_D1.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS03_D2') {
                                WS03_D2.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS03_D3') {
                                WS03_D3.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS03_D4') {
                                WS03_D4.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS03_D5') {
                                WS03_D5.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS03_D6') {
                                WS03_D6.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS04_D1') {
                                WS04_D1.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS04_D2') {
                                WS04_D2.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS04_D3') {
                                WS04_D3.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS04_D4') {
                                WS04_D4.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS04_D5') {
                                WS04_D5.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS04_D6') {
                                WS04_D6.push({x: row.times, y: row[lifeExp]});
                        }
				
        });
        return [
                {name: 'WS01_A1', points: WS01_A1},
                {name: 'WS01_A2', points: WS01_A2},
                {name: 'IBS01_1', points: IBS01_1},
                {name: 'IBS01_2', points: IBS01_2},
                {name: 'WS02_A1', points: WS02_A1},
                {name: 'WS02_A2', points: WS02_A2},
                {name: 'IBS02_1', points: IBS02_1},
                {name: 'IBS02_2', points: IBS02_2},
                {name: 'WS03_D1', points: WS03_D1},
                {name: 'WS03_D2', points: WS03_D2},
                {name: 'WS03_D3', points: WS03_D3},
                {name: 'WS03_D4', points: WS03_D4},
                {name: 'WS03_D5', points: WS03_D5},
                {name: 'WS03_D6', points: WS03_D6},
		{name: 'WS04_D1', points: WS04_D1},
                {name: 'WS04_D2', points: WS04_D2},
                {name: 'WS04_D3', points: WS04_D3},
                {name: 'WS04_D4', points: WS04_D4},
                {name: 'WS04_D5', points: WS04_D5},
                {name: 'WS04_D6', points: WS04_D6}
];
}

function renderChart(series) {
        JSC.Chart('chartDiv', {
                series: series
        });
}


