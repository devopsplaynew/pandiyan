fetch('https://localhost:84/rptview/data/ofx_cals.csv')
        .then(function (response) {
                return response.text();
        })
        .then(function (text) {
                let series = csvToSeriesA(text);
                renderChartA(series);
        })
        .catch(function (error) {
                console.log(error);
        });

function csvToSeriesA(text) {
        const lifeExp = 'status';
        let dataAsJson = JSC.csv2Json(text);
        let OFX01_1_CNTWRE_IN = [], OFX01_2_CNTWRE_IN = [], OFX02_1_CNTWRE_IN = [], OFX02_2_CNTWRE_IN = [], OFX03_1_CNTWRE_IN = [], OFX03_2_CNTWRE_IN = [], OFX01_1_CNTWRE_OUT = [], OFX01_2_CNTWRE_OUT = [], OFX02_1_CNTWRE_OUT = [], OFX02_2_CNTWRE_OUT = [], OFX03_1_CNTWRE_OUT = [], OFX03_2_CNTWRE_OUT = [];

        dataAsJson.forEach(function (row) {
                        if (row.jvm === 'OFX01_1_CNTWRE_IN') {
                                OFX01_1_CNTWRE_IN.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX01_2_CNTWRE_IN') {
                                OFX01_2_CNTWRE_IN.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX02_1_CNTWRE_IN') {
                                OFX02_1_CNTWRE_IN.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX02_2_CNTWRE_IN') {
                                OFX02_2_CNTWRE_IN.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX03_1_CNTWRE_IN') {
                                OFX03_1_CNTWRE_IN.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX03_2_CNTWRE_IN') {
                                OFX03_2_CNTWRE_IN.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX01_1_CNTWRE_OUT') {
                                OFX01_1_CNTWRE_OUT.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX01_2_CNTWRE_OUT') {
                                OFX01_2_CNTWRE_OUT.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX02_1_CNTWRE_OUT') {
                                OFX02_1_CNTWRE_OUT.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX02_2_CNTWRE_OUT') {
                                OFX02_2_CNTWRE_OUT.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX03_1_CNTWRE_OUT') {
                                OFX03_1_CNTWRE_OUT.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX03_2_CNTWRE_OUT') {
                                OFX03_2_CNTWRE_OUT.push({x: row.times, y: row[lifeExp]});
                        }
        });
        return [
                {name: 'OFX01_1_CNTWRE_IN', points: OFX01_1_CNTWRE_IN},
                {name: 'OFX01_2_CNTWRE_IN', points: OFX01_2_CNTWRE_IN},
                {name: 'OFX02_1_CNTWRE_IN', points: OFX02_1_CNTWRE_IN},
                {name: 'OFX02_2_CNTWRE_IN', points: OFX02_2_CNTWRE_IN},
                {name: 'OFX03_1_CNTWRE_IN', points: OFX03_1_CNTWRE_IN},
                {name: 'OFX03_2_CNTWRE_IN', points: OFX03_2_CNTWRE_IN},
                {name: 'OFX01_1_CNTWRE_OUT', points: OFX01_1_CNTWRE_OUT},
                {name: 'OFX01_2_CNTWRE_OUT', points: OFX01_2_CNTWRE_OUT},
                {name: 'OFX02_1_CNTWRE_OUT', points: OFX02_1_CNTWRE_OUT},
                {name: 'OFX02_2_CNTWRE_OUT', points: OFX02_2_CNTWRE_OUT},
                {name: 'OFX03_1_CNTWRE_OUT', points: OFX03_1_CNTWRE_OUT},
                {name: 'OFX03_2_CNTWRE_OUT', points: OFX03_2_CNTWRE_OUT}
];
}

function renderChartA(series) {
        JSC.Chart('chartDivA', {
                series: series
        });
}
