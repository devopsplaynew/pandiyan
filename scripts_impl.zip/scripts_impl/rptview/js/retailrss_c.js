fetch('https://localhost:84/rptview/data/retail_rss.csv')
        .then(function (response) {
                return response.text();
        })
        .then(function (text) {
                let series = csvToSeries(text);
                renderChart(series);
        })
        .catch(function (error) {
                console.log(error);
        });

function csvToSeries(text) {
        const lifeExp = 'status';
        let dataAsJson = JSC.csv2Json(text);
        let WS24_C1 = [], WS24_C2 = [], WS24_C3 = [], WS24_C4 = [], WS24_C5 = [], WS24_C6 = [], WS25_C1 = [], WS25_C2 = [], WS25_C3 = [], WS25_C4 = [], WS25_C5 = [], WS25_C6 = [];

        dataAsJson.forEach(function (row) {
                        if (row.jvm === 'WS24_C1') {
                                WS24_C1.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS24_C2') {
                                WS24_C2.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS24_C3') {
                                WS24_C3.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS24_C4') {
                                WS24_C4.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS24_C5') {
                                WS24_C5.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS24_C6') {
                                WS24_C6.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS25_C1') {
                                WS25_C1.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS25_C2') {
                                WS25_C2.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS25_C3') {
                                WS25_C3.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS25_C4') {
                                WS25_C4.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS25_C5') {
                                WS25_C5.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS25_C6') {
                                WS25_C6.push({x: row.times, y: row[lifeExp]});
                        }
        });
        return [
                {name: 'WS24_C1', points: WS24_C1},
                {name: 'WS24_C2', points: WS24_C2},
                {name: 'WS24_C3', points: WS24_C3},
                {name: 'WS24_C4', points: WS24_C4},
                {name: 'WS24_C5', points: WS24_C5},
                {name: 'WS24_C6', points: WS24_C6},
                {name: 'WS25_C1', points: WS25_C1},
                {name: 'WS25_C2', points: WS25_C2},
                {name: 'WS25_C3', points: WS25_C3},
                {name: 'WS25_C4', points: WS25_C4},
                {name: 'WS25_C5', points: WS25_C5},
                {name: 'WS25_C6', points: WS25_C6}
];
}

function renderChart(series) {
        JSC.Chart('chartDivC', {
                series: series
        });
}

