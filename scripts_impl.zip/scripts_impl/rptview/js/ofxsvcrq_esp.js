fetch('https://localhost:84/rptview/data/ofx_cals.csv')
        .then(function (response) {
                return response.text();
        })
        .then(function (text) {
                let series = csvToSeries(text);
                renderChart(series);
        })
        .catch(function (error) {
                console.log(error);
        });

function csvToSeries(text) {
        const lifeExp = 'status';
        let dataAsJson = JSC.csv2Json(text);
        let OFX01_1_ESP_ACCTRQ = [], OFX01_2_ESP_ACCTRQ = [], OFX02_1_ESP_ACCTRQ = [], OFX02_2_ESP_ACCTRQ = [], OFX03_1_ESP_ACCTRQ = [], OFX03_2_ESP_ACCTRQ = [];

        dataAsJson.forEach(function (row) {
                        if (row.jvm === 'OFX01_1_ESP_ACCTRQ') {
                                OFX01_1_ESP_ACCTRQ.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX01_2_ESP_ACCTRQ') {
                                OFX01_2_ESP_ACCTRQ.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX02_1_ESP_ACCTRQ') {
                                OFX02_1_ESP_ACCTRQ.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX02_2_ESP_ACCTRQ') {
                                OFX02_2_ESP_ACCTRQ.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX03_1_ESP_ACCTRQ') {
                                OFX03_1_ESP_ACCTRQ.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'OFX03_2_ESP_ACCTRQ') {
                                OFX03_2_ESP_ACCTRQ.push({x: row.times, y: row[lifeExp]});
                        }
        });
        return [
               {name: 'OFX01_1_ESP_ACCTRQ', points: OFX01_1_ESP_ACCTRQ},
                {name: 'OFX01_2_ESP_ACCTRQ', points: OFX01_2_ESP_ACCTRQ},
                {name: 'OFX02_1_ESP_ACCTRQ', points: OFX02_1_ESP_ACCTRQ},
                {name: 'OFX02_2_ESP_ACCTRQ', points: OFX02_2_ESP_ACCTRQ},
                {name: 'OFX03_1_ESP_ACCTRQ', points: OFX03_1_ESP_ACCTRQ},
                {name: 'OFX03_2_ESP_ACCTRQ', points: OFX03_2_ESP_ACCTRQ}
];
}

function renderChart(series) {
        JSC.Chart('chartDivC', {
                series: series
        });
}


