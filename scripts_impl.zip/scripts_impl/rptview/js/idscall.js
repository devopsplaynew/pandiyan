fetch('https://localhost:84/rptview/data/idscalls.csv')
	.then(function (response) {
		return response.text();
	})
	.then(function (text) {
		let series = csvToSeries(text);
		renderChart(series);
	})
	.catch(function (error) {
		//Something went wrong
		console.log(error);
	});

function csvToSeries(text) {
	const lifeExp = 'status';
	let dataAsJson = JSC.csv2Json(text);
	let IDS01_1 = [], IDS01_2 = [], IDS02_1 = [], IDS02_2 = [];

	dataAsJson.forEach(function (row) {
		//add either to male, female, or discard.
//		if (row.race === 'All Races') {
                        if (row.jvm === 'IDS01_1') {
                                IDS01_1.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'IDS01_2') {
                                IDS01_2.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'IDS02_1') {
                                IDS02_1.push({x: row.times, y: row[lifeExp]});
			} else if (row.jvm === 'IDS02_2') {
                                IDS02_2.push({x: row.times, y: row[lifeExp]});
                        }

//		}
	});
	return [
                {name: 'IDS01_1', points: IDS01_1},
                {name: 'IDS01_2', points: IDS01_2},
		{name: 'IDS02_1', points: IDS02_1},
		{name: 'IDS02_2', points: IDS02_2}	
];
}

function renderChart(series) {
	JSC.Chart('chartDiv', {
		series: series
	});
}




