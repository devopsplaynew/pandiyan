fetch('https://localhost:84/rptview/data/ret_asn.csv')
        .then(function (response) {
                return response.text();
        })
        .then(function (text) {
                let series = csvToSeriesA(text);
                renderChartA(series);
        })
        .catch(function (error) {
                console.log(error);
        });

function csvToSeriesA(text) {
        const lifeExp = 'status';
        let dataAsJson = JSC.csv2Json(text);
        let WS22_A1 = [], WS22_A2 = [], WS22_A3 = [], WS22_A4 = [], WS22_A5 = [], WS22_A6 = [], WS23_A1 = [], WS23_A2 = [], WS23_A3 = [], WS23_A4 = [], WS23_A5 = [], WS23_A6 = [];

        dataAsJson.forEach(function (row) {
                        if (row.jvm === 'WS22_A1') {
                                WS22_A1.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS22_A2') {
                                WS22_A2.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS22_A3') {
                                WS22_A3.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS22_A4') {
                                WS22_A4.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS22_A5') {
                                WS22_A5.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS22_A6') {
                                WS22_A6.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS23_A1') {
                                WS23_A1.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS23_A2') {
                                WS23_A2.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS23_A3') {
                                WS23_A3.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS23_A4') {
                                WS23_A4.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS23_A5') {
                                WS23_A5.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS23_A6') {
                                WS23_A6.push({x: row.times, y: row[lifeExp]});
                        }
        });
        return [
                {name: 'WS22_A1', points: WS22_A1},
                {name: 'WS22_A2', points: WS22_A2},
                {name: 'WS22_A3', points: WS22_A3},
                {name: 'WS22_A4', points: WS22_A4},
                {name: 'WS22_A5', points: WS22_A5},
                {name: 'WS22_A6', points: WS22_A6},
                {name: 'WS23_A1', points: WS23_A1},
                {name: 'WS23_A2', points: WS23_A2},
                {name: 'WS23_A3', points: WS23_A3},
                {name: 'WS23_A4', points: WS23_A4},
                {name: 'WS23_A5', points: WS23_A5},
                {name: 'WS23_A6', points: WS23_A6}
];
}

function renderChartA(series) {
        JSC.Chart('chartDivA', {
                series: series
        });
}
