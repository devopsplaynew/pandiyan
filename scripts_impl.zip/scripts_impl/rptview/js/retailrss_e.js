fetch('https://localhost:84/rptview/data/retail_rss.csv')
        .then(function (response) {
                return response.text();
        })
        .then(function (text) {
                let series = csvToSeriesE(text);
                renderChartE(series);
        })
        .catch(function (error) {
                console.log(error);
        });

function csvToSeriesE(text) {
        const lifeExp = 'status';
        let dataAsJson = JSC.csv2Json(text);
        let WS28_E1 = [], WS28_E2 = [], WS28_E3 = [], WS28_E4 = [], WS28_E5 = [], WS28_E6 = [], WS29_E1 = [], WS29_E2 = [], WS29_E3 = [], WS29_E4 = [], WS29_E5 = [], WS29_E6 = [];

        dataAsJson.forEach(function (row) {
                        if (row.jvm === 'WS28_E1') {
                                WS28_E1.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS28_E2') {
                                WS28_E2.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS28_E3') {
                                WS28_E3.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS28_E4') {
                                WS28_E4.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS28_E5') {
                                WS28_E5.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS28_E6') {
                                WS28_E6.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS29_E1') {
                                WS29_E1.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS29_E2') {
                                WS29_E2.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS29_E3') {
                                WS29_E3.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS29_E4') {
                                WS29_E4.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS29_E5') {
                                WS29_E5.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS29_E6') {
                                WS29_E6.push({x: row.times, y: row[lifeExp]});
                        }
        });
        return [
                {name: 'WS28_E1', points: WS28_E1},
                {name: 'WS28_E2', points: WS28_E2},
                {name: 'WS28_E3', points: WS28_E3},
                {name: 'WS28_E4', points: WS28_E4},
                {name: 'WS28_E5', points: WS28_E5},
                {name: 'WS28_E6', points: WS28_E6},
                {name: 'WS29_E1', points: WS29_E1},
                {name: 'WS29_E2', points: WS29_E2},
                {name: 'WS29_E3', points: WS29_E3},
                {name: 'WS29_E4', points: WS29_E4},
                {name: 'WS29_E5', points: WS29_E5},
                {name: 'WS29_E6', points: WS29_E6}
];
}

function renderChartE(series) {
        JSC.Chart('chartDivE', {
                series: series
        });
}
