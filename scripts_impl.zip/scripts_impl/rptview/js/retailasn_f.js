fetch('https://localhost:84/rptview/data/ret_asn.csv')
        .then(function (response) {
                return response.text();
        })
        .then(function (text) {
                let series = csvToSeriesF(text);
                renderChartF(series);
        })
        .catch(function (error) {
                console.log(error);
        });

function csvToSeriesF(text) {
        const lifeExp = 'status';
        let dataAsJson = JSC.csv2Json(text);
        let WS30_F1 = [], WS30_F2 = [], WS30_F3 = [], WS30_F4 = [], WS30_F5 = [], WS30_F6 = [], WS31_F1 = [], WS31_F2 = [], WS31_F3 = [], WS31_F4 = [], WS31_F5 = [], WS31_F6 = [];

        dataAsJson.forEach(function (row) {
                        if (row.jvm === 'WS30_F1') {
                                WS30_F1.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS30_F2') {
                                WS30_F2.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS30_F3') {
                                WS30_F3.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS30_F4') {
                                WS30_F4.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS30_F5') {
                                WS30_F5.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS30_F6') {
                                WS30_F6.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS31_F1') {
                                WS31_F1.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS31_F2') {
                                WS31_F2.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS31_F3') {
                                WS31_F3.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS31_F4') {
                                WS31_F4.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS31_F5') {
                                WS31_F5.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS31_F6') {
                                WS31_F6.push({x: row.times, y: row[lifeExp]});
                        }
        });
        return [
                {name: 'WS30_F1', points: WS30_F1},
                {name: 'WS30_F2', points: WS30_F2},
                {name: 'WS30_F3', points: WS30_F3},
                {name: 'WS30_F4', points: WS30_F4},
                {name: 'WS30_F5', points: WS30_F5},
                {name: 'WS30_F6', points: WS30_F6},
                {name: 'WS31_F1', points: WS31_F1},
                {name: 'WS31_F2', points: WS31_F2},
                {name: 'WS31_F3', points: WS31_F3},
                {name: 'WS31_F4', points: WS31_F4},
                {name: 'WS31_F5', points: WS31_F5},
                {name: 'WS31_F6', points: WS31_F6}
];
}

function renderChartF(series) {
        JSC.Chart('chartDivF', {
                series: series
        });
}
