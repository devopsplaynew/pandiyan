fetch('https://localhost:84/rptview/data/test1data.csv')
	.then(function (response) {
		return response.text();
	})
	.then(function (text) {
		let series = csvToSeries(text);
		renderChart(series);
	})
	.catch(function (error) {
		//Something went wrong
		console.log(error);
	});

function csvToSeries(text) {
	const lifeExp = 'postlogin';
	let dataAsJson = JSC.csv2Json(text);
	//let male = [], female = [];
	let ws01A1 = [], ws01A2 = [] ws01A3 = [] ws01A4 = [] ws01A5 = [] ws01A6 = [];
dataAsJson.forEach(function (row) {
		//add either to male, female, or discard.
	
//{
			if (row.jvm === 'ws01A1') 
			{
					ws01A1.push({x: row.time, y: row[lifeExp]});
			} 
			else if (row.jvm === 'ws01A2') 
			{
					ws01A2.push({x: row.time, y: row[lifeExp]});
			}
			else if (row.jvm === 'ws01A3') 
			{
					ws01A3.push({x: row.time, y: row[lifeExp]});
			}
			else if (row.jvm === 'ws01A4') 
			{
					ws01A4.push({x: row.time, y: row[lifeExp]});
			}
			else if (row.jvm === 'ws01A5') 
			{
					ws01A5.push({x: row.time, y: row[lifeExp]});
			}
			else if (row.jvm === 'ws01A6') 
			{
					ws01A6.push({x: row.time, y: row[lifeExp]});
			}
//}	
	});
	

	return [
{name: 'ws01A1', points: ws01A1},
{name: 'ws01A2', points: ws01A2},
{name: 'ws01A3', points: ws01A3},
{name: 'ws01A4', points: ws01A4},
{name: 'ws01A5', points: ws01A5},
{name: 'ws01A6', points: ws01A6}	
];
}

function renderChart(series) {
	JSC.Chart('chartDiv', {
		series: series
	});
}


