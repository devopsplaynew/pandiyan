fetch('https://localhost:84/rptview/data/ret_asn.csv')
        .then(function (response) {
                return response.text();
        })
        .then(function (text) {
                let series = csvToSeriesD(text);
                renderChartD(series);
        })
        .catch(function (error) {
                console.log(error);
        });

function csvToSeriesD(text) {
        const lifeExp = 'status';
        let dataAsJson = JSC.csv2Json(text);
        let WS26_D1 = [], WS26_D2 = [], WS26_D3 = [], WS26_D4 = [], WS26_D5 = [], WS26_D6 = [], WS27_D1 = [], WS27_D2 = [], WS27_D3 = [], WS27_D4 = [], WS27_D5 = [], WS27_D6 = [];

        dataAsJson.forEach(function (row) {
                        if (row.jvm === 'WS26_D1') {
                                WS26_D1.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS26_D2') {
                                WS26_D2.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS26_D3') {
                                WS26_D3.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS26_D4') {
                                WS26_D4.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS26_D5') {
                                WS26_D5.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS26_D6') {
                                WS26_D6.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS27_D1') {
                                WS27_D1.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS27_D2') {
                                WS27_D2.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS27_D3') {
                                WS27_D3.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS27_D4') {
                                WS27_D4.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS27_D5') {
                                WS27_D5.push({x: row.times, y: row[lifeExp]});
                        } else if (row.jvm === 'WS27_D6') {
                                WS27_D6.push({x: row.times, y: row[lifeExp]});
                        }
        });
        return [
                {name: 'WS26_D1', points: WS26_D1},
                {name: 'WS26_D2', points: WS26_D2},
                {name: 'WS26_D3', points: WS26_D3},
                {name: 'WS26_D4', points: WS26_D4},
                {name: 'WS26_D5', points: WS26_D5},
                {name: 'WS26_D6', points: WS26_D6},
                {name: 'WS27_D1', points: WS27_D1},
                {name: 'WS27_D2', points: WS27_D2},
                {name: 'WS27_D3', points: WS27_D3},
                {name: 'WS27_D4', points: WS27_D4},
                {name: 'WS27_D5', points: WS27_D5},
                {name: 'WS27_D6', points: WS27_D6}
];
}

function renderChartD(series) {
        JSC.Chart('chartDivD', {
                series: series
        });
}
