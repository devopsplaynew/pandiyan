<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
</head>
<body>
    <div id="chartDivA" style="width:100%; height:250px; margin:0 auto;"></div>
    <div id="chartDivC" style="width:100%; height:250px; margin:0 auto;"></div>
    <div id="chartDivD" style="width:100%; height:250px; margin:0 auto;"></div>
    <div id="chartDivE" style="width:100%; height:250px; margin:0 auto;"></div>
    <div id="chartDivF" style="width:100%; height:250px; margin:0 auto;"></div>
</body>
<script src="https://code.jscharting.com/2.9.0/jscharting.js"></script>
<script src="js/retailrss_a.js"></script>
<script src="js/retailrss_c.js"></script>
<script src="js/retailrss_d.js"></script>
<script src="js/retailrss_e.js"></script>
<script src="js/retailrss_f.js"></script>
</html>
