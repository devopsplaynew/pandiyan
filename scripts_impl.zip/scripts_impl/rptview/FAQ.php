<html style="width:100%;height:100%;padding:0;margin:0;position:relative;text-align:center;">
<head><meta http-equiv="Content-Type" content="text/html; charset=us-ascii"></head><body style="background-color: white; position: relative; text-align: center; padding: 0; margin: 0;display: inline-block;"><div style="position: relative; text-align: center;">
<table style="background-color:#8cd98c; position: relative; text-align: center;" width="900px" cellspacing="0px" cellpadding="5px">
<tr><td colspan="7"><table style="background-color:#4d4d4d;" width="900px" cellspacing="0px" cellpadding="5px">
<tr><td width="10"></td><td width="100" align="left"></td><td width="650" align="right">
<h1 style="font-family: Courier; color:#ffc61a;text-align: center; font-size: 17px">
Frequenty Required Answers 04/28/2022 00:24:04 AM &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h1></td></tr>
</table></td></tr><tr><td colspan="8"><table style="background-color:#4d4d4d;" width="900px" cellspacing="0px" cellpadding="5px"><td colspan="8"><table style="background-color:#4d4d4d;" width="900px" cellspacing="0px" cellpadding="5px"><tr style="font-family: Courier; color: Yellow; font-size: 15px; background-color:#808080"><td align="center" width="500"></td>
<td align="center" width="275"></td></tr>
<tr style="font-family: Courier; color: #0000ff; font-size: 14px; background-color:#ffccb3">
<td td align=center width=655></td>
<td align=center width=100 ></td>
</tr>
<tr style="font-family: Courier; color: #0000ff; font-size: 14px; background-color:#ffccb3">
<td td align=center width=655>Live Data Center(CeB) </td>
<td align=center width=100 > BROWN DEER</td>
</tr>
<tr style="font-family: Courier; color: #0000ff; font-size: 14px; background-color:#ffccb3">
<td td align=center width=655>Offline Data Center(CeB)</td>
<td align=center width=100 > PHEONIX</td>
</tr>
<tr style="font-family: Courier; color: #0000ff; font-size: 14px; background-color:#ffccb3">
<td td align=center width=655>CeB BDC1_redirect </td>
<td align=center width=100 > DELTA</td>
</tr>
<tr style="font-family: Courier; color: #0000ff; font-size: 14px; background-color:#ffccb3">
<td td align=center width=655>CeB PDC2_redirect </td>
<td align=center width=100 > DELTA</td>
</tr>
<tr style="font-family: Courier; color: #0000ff; font-size: 14px; background-color:#ffccb3">
<td td align=center width=655>CeB datbase frame </td>
<td align=center width=100 > b1xlvdb4a-adm</td>
</tr>
<tr style="font-family: Courier; color: #0000ff; font-size: 14px; background-color:#ffccb3">
<td td align=center width=655>Live Data Center(OAC)</td>
<td align=center width=100 > PHEONIX</td>
</tr>
<tr style="font-family: Courier; color: #0000ff; font-size: 14px; background-color:#ffccb3">
<td td align=center width=655>Offline Data Center(OAC)</td>
<td align=center width=100 > BROWN DEER</td>
</tr>
<tr style="font-family: Courier; color: #0000ff; font-size: 14px; background-color:#ffccb3">
<td td align=center width=655>Live Data Center(VE)</td>
<td align=center width=100 > PHEONIX</td>
</tr>
<tr style="font-family: Courier; color: #0000ff; font-size: 14px; background-color:#ffccb3">
<td td align=center width=655>Offline Data Center(VE)</td>
<td align=center width=100 > BROWN DEER</td>
</tr>
<tr style="font-family: Courier; color: #0000ff; font-size: 14px; background-color:#ffccb3">
<td td align=center width=655>Live Data Center(IDS) </td>
<td align=center width=100 > BROWN DEER</td>
</tr>
<tr style="font-family: Courier; color: #0000ff; font-size: 14px; background-color:#ffccb3">
<td td align=center width=655>Offline Data Center(IDS)</td>
<td align=center width=100 > PHEONIX</td>
</tr>
<tr style="font-family: Courier; color: #0000ff; font-size: 14px; background-color:#ffccb3">
<td td align=center width=655>EG datbase frame </td>
<td align=center width=100 > b1xlvdb4b-adm</td>
</tr>
<tr style="font-family: Courier; color: #0000ff; font-size: 14px; background-color:#ffccb3">
<td td align=center width=655>OAC datbase frame </td>
<td align=center width=100 > p1xlvdb3b-adm</td>
</tr>
<tr style="font-family: Courier; color: #0000ff; font-size: 14px; background-color:#ffccb3">
<td td align=center width=655>VG datbase frame </td>
<td align=center width=100 > p1xlvdb3a-adm</td>
</tr>
</table>
