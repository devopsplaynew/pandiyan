#!/bin/bash
CONF=$1

RANDOM=$$$(date +%s)
SERVERS=(pdc2rdftcebws22 pdc2rdftcebws23 pdc2rdftcebws24 pdc2rdftcebws25 pdc2rdftcebws26 pdc2rdftcebws27 pdc2rdftcebws28 pdc2rdftcebws29 pdc2rdftcebws30 pdc2rdftcebws31 pdc2rdftcebws32)
selectedSERVERS=${SERVERS[$RANDOM % ${#SERVERS[*]}]};

/fras/script/ODSA_scripts/SET_WGET.bash ${CONF} ${selectedSERVERS}
