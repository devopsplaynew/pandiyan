#!/bin/bash

SERV=`uname -n`
DTTIME=`date +%Y%m%d_%H:%M:%S`
val1=`curl -v -k --max-time 1500 https://voltage-pp-0000.prod.local/policy/clientPolicy.xml 2>&1 | grep "Connected to voltage-pp-0000" -c`

if [ $val1 == 1 ]
then
echo On $SERV $val1 voltage connectivity successful.>>/fras/cebscr/Voltage_monitor.log
#echo Voltage connectivity looks good on all servers.
else 
echo $SERV $val1 Issue with Voltage connectivity, please check>>/fras/cebscr/Voltage_monitor.log
#echo Issue with voltage connectivity, please check.
fi
