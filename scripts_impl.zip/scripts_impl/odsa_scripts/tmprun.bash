#!/bin/bash

SERV=`uname -n`
DTTIME=`date`
LOGDIR="/fras/script/logs"

COUNT=`ls /tmp/cibadmin-tmp/ | wc -l`

echo "${SERV}     ${DTTIME}---${COUNT}" >> /fras/script/ODSA_scripts/OUTPUT/CI_runtime.txt

