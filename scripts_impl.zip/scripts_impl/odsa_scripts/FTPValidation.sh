#!/bin/ksh

today=`date +"%Y%m%d"`

ARGONE=$1

HOSTNAME=`hostname`
    echo "HOSTNAME=$HOSTNAME"
    INPUTFILENAME="ComServersListFTP.dat"

    # validating the user/password for a particular environment
    if [ ${HOSTNAME} = "VLLTCCEBAPP1" -o ${HOSTNAME} = "VLLTCCEBAPP2" ]; then   # Unit and System
       echo "$HOSTNAME Unit or System"
        INPUTFILENAME="ComServersListFTP_System.dat"
    elif [ ${HOSTNAME} = "pdc8rdftcebws03" -o ${HOSTNAME} = "pdc8rdftcebws01"  ]; then # Performance and Readiness
       echo "$HOSTNAME Performance or Readiness"
       INPUTFILENAME="ComServersListFTP_Readiness.dat"
    elif [ ${HOSTNAME} = "bdc1rdftcebws42" -o ${HOSTNAME} = "bdc1rdftcebws43" -o ${HOSTNAME} = "bdc1rdftcebws44" -o ${HOSTNAME} = "bdc1rdftcebws45" ]; then   # Production C, D and E containers.
       echo "$HOSTNAME Production BDOC Batch"
       INPUTFILENAME="/fras/script/ODSA_scripts/ComServersListFTP_Production.dat"
    elif [ ${HOSTNAME} = "pdc2rdftcebws42" -o ${HOSTNAME} = "pdc2rdftcebws43" -o ${HOSTNAME} = "pdc2rdftcebws44" -o ${HOSTNAME} = "pdc2rdftcebws45" ]; then   # Production C, D and E containers.
       echo "$HOSTNAME Production PDC2 Batch"
       INPUTFILENAME="/fras/script/ODSA_scripts/ComServersListFTP_Production.dat"
    else
       INPUTFILENAME="ComServersListFTP.dat"
    fi

ftpResults=/fras/cebscr/checkup/logs/FTPResults.log
#chmod 775 $ftpResults 
localpath=/tmp
echo "" >$ftpResults
#echo "----------------------------------------------------------------------------------------------" >>$ftpResults
#echo "Companion Name | Companion Server         | FTP User | Get or Put | FTP results               " >>$ftpResults
#echo "----------------------------------------------------------------------------------------------" >>$ftpResults

for line in $(cat $INPUTFILENAME); do

        if [ -z "$line" ]; then
              echo "line is empty"  >>$ftpResults
        else

                  CNAME=`echo $line | cut -f1 -d"|" `
                  CSNAME=`echo $line | cut -f2 -d"|" `
                  CSFTPUSER=`echo $line | cut -f3 -d"|" `
                  CSFTPFOLDER=`echo $line | cut -f4 -d"|" `
                  CSFTPACTION=`echo $line | cut -f5 -d"|" `
                  CSFTPFILE=`echo $line | cut -f6 -d"|" `
                  CSFTPFILE_TEMP=`echo $line | cut -f6 -d"|" `


                  typeset -u CSFTPFILE_TEMP
                  typeset -u CSFTPACTION
                  typeset -u ARGONE

                        if [ "$CSFTPFILE" = "DUMMY" ]; then
                                mv /tmp/CeBScript_Dummy.txt /tmp/CeBScript_Dummy.txt.old
                                echo "CeB Script testing for $CNAME on $today." > /tmp/CeBScript_Dummy.txt
                                CSFTPFILE='CeBScript_Dummy.txt'
                        fi

                        if [ "$ARGONE" = "TMP" ]; then
                                CSFTPFOLDER="/tmp"
                        fi

                        echo  > $localpath/list.sftp
                        echo "cd $CSFTPFOLDER " >> $localpath/list.sftp

                        CNAMEOUT=`echo "$CNAME" | awk -v m=14 '{printf("%-14s\n", $0)}' `
                        CSNAMEOUT=`echo "$CSNAME" | awk -v m=24 '{printf("%-24s\n", $0)}' `
                        CFTPUSEROUT=`echo "$CSFTPUSER" | awk -v m=8 '{printf("%-8s\n", $0)}' `
                        GETORPUTOUT=`echo "$CSFTPACTION" | awk -v m=10 '{printf("%-10s\n", $0)}' `



                        if [ "$CSFTPACTION" = "GET" ]; then

                                    #echo "put $CSFTPFILE" >> $localpath/list.sftp
                                    echo "lcd /tmp" >> $localpath/list.sftp
                                    echo "get $CSFTPFILE" >> $localpath/list.sftp
                                    echo "bye " >> $localpath/list.sftp

                                    sftp -o StrictHostKeyChecking=no -b $localpath/list.sftp $CSFTPUSER@$CSNAME

                        elif [ "$CSFTPACTION" = "PUT" ]; then

                                        echo "lcd /tmp" >> $localpath/list.sftp
                                    echo "put $CSFTPFILE " >> $localpath/list.sftp
                                    echo "bye " >> $localpath/list.sftp

                                    sftp -o StrictHostKeyChecking=no -b $localpath/list.sftp $CSFTPUSER@$CSNAME

                        elif [ "$CSFTPACTION" = "MGET" ]; then

                                    #echo "mput $CSFTPFILE " >> $localpath/list.sftp
                                    echo "lcd /tmp" >> $localpath/list.sftp
                                    echo "mget $CSFTPFILE " >> $localpath/list.sftp
                                    echo "bye " >> $localpath/list.sftp

                                    sftp -o StrictHostKeyChecking=no -b $localpath/list.sftp $CSFTPUSER@$CSNAME

                        elif [ "$CSFTPACTION" = "MPUT" ]; then

                                        echo "lcd /tmp" >> $localpath/list.sftp
                                    echo "put $CSFTPFILE " >> $localpath/list.sftp
                                    echo "bye " >> $localpath/list.sftp

                                    sftp -o StrictHostKeyChecking=no -b $localpath/list.sftp $CSFTPUSER@$CSNAME

                        elif [ "$CSFTPACTION" = "SCP" ]; then

                                    echo "$CSFTPUSER@$CSNAME:$CSFTPFOLDER/CBPAY_ACTION_* /tmp"

                                    scp -o StrictHostKeyChecking=no $CSFTPUSER@$CSNAME:$CSFTPFOLDER/CBPAY_ACTION_* /tmp

                        fi

                    if [ $? == "0" ]; then
                        echo "$CNAMEOUT | $CSNAMEOUT | $CFTPUSEROUT | $GETORPUTOUT |Success" >>$ftpResults
                    else
                        echo "$CNAMEOUT | $CSNAMEOUT | $CFTPUSEROUT | $GETORPUTOUT |Failed" >>$ftpResults
                    fi
        fi

done

