#!/bin/bash

SERV=`uname -n`
DTTIME=`date +%Y%m%d_%H:%M:%S`

declare -a loop_array=('BDCG2ITBGNAS1')

for LA in ${loop_array[@]}
do

        LOOPVAL=`mount | grep ${LA} |wc -l`

if [ $LOOPVAL -ge 1 ]
then
echo -e "${LA} is available in $SERV ">>/fras/cebscr/temp/nmount_avail.log
mount | grep ${LA} >>/fras/cebscr/temp/nmount_avail.log
echo "" >>/fras/cebscr/temp/nmount_avail.log
fi

done

