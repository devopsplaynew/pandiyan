#################################################################
##Desc : Slapi Cert Check
##Author : Sandeep
#################################################################

#!/bin/ksh

certcheck=/fras/cebscr/checkup/out/certcheck.out
certwarnorg=/fras/cebscr/checkup/out/certwarnorg.out
certwarn=/fras/cebscr/checkup/logs/`hostname`_certwarn.log
certalert=/fras/cebscr/temp/certmail.txt
certpath=/opt/security/ALPHA/slapi
Send_From='pandiyan.kuppan@fisglobal.com'
#Send_To='Sandeep.P3@fisglobal.com Vijin.Das@fisglobal.com Iyshwarya.L@fisglobal.com Tarun.Avula@fisglobal.com pandiyan.kuppan@fisglobal.com'
Send_To='pandiyan.kuppan@fisglobal.com'
CURDATE=`date +'%Y-%m-%d:%H:%M:%S'`
mdate=`date +'%A'`

echo "">$certcheck
echo "">$certwarn
cd $certpath

for LISTING in `ls */*pem`
do
        vfrom=`/usr/bin/openssl x509 -noout -dates -in /opt/security/ALPHA/slapi/${LISTING} |grep -i 'before' |cut -d "=" -f2 |awk '{print $1 " " $4}'`
        vthru=`/usr/bin/openssl x509 -noout -dates -in /opt/security/ALPHA/slapi/${LISTING} |grep -i 'after' |cut -d "=" -f2 |awk '{print $1 " " $4}'`
                CERT_DATE=`/usr/bin/openssl x509 -noout -dates -in /opt/security/ALPHA/slapi/${LISTING} |grep -i 'after' |cut -d "=" -f2`

                        date_s=$(date -d "${CERT_DATE}" +%s)
                        now_s=$(date -d now +%s)

                        date_diff=$(( (date_s - now_s) / 86400 ))

                        _sub="`hostname` ${LISTING} Certificate will expire within $date_diff days"

                        if [ $date_diff -le 30 ] && [ $date_diff -ge 0 ]
                        then
                                echo "CRITICAL: `hostname` : ${LISTING} Certificate will expire within $date_diff days">>$certwarn
                        elif [ $date_diff -le 0 ]
                        then
                                echo "CRITICAL: `hostname` : ${LISTING} Certificate Already Expired">>$certwarn
                        else
                                echo "GOOD:`hostname` : ${LISTING} Certificate is good for expiration date."
                        fi

echo -i "`hostname` : ${LISTING} : ${vfrom} : ${vthru} : ${date_diff}" >>$certcheck

done

if [ `hostname` = 'bdc1rdftcebws45' ];then
sleep 90 

comm -3 <(sed 's#.*//##' $certwarnorg | sort) <(sort /fras/cebscr/checkup/logs/*certwarn.log)>$certalert

certmail=`stat -c%s $certalert`

if [ $certmail -gt 2 ] && [ $mdate = 'Tuesday' ] ; then; cat $certalert | mailx -r "$Send_From" -s "Warning: Cert expiry deduction alert $CURDATE" "$Send_To";fi
. /fras/script/ODSA_scripts/certexpiry

fi

