#!/bin/bash

SERV=`uname -n`
DTTIME=`date +%Y%m%d_%H:%M:%S`
LOGDIR="/fras/script/logs"
DEST="/fras/script/ODSA_scripts/OUTPUT/"
RANDM=`echo $((1 + RANDOM % 20))`
sleep ${RANDM}

LOOPVAL=`egrep '(VirtualHost_| port=")' /opt/WebSphere/8_5/AppServerBase1/profiles/AppServerBase1/config/cells/*_Cell/virtualhosts.xml`
while read -r LPV
do
		echo "${SERV}!!!!!${LA}!!!!!${LPV}" >> ${DEST}${SERV}CI_PORTS.txt
done <<< "${LOOPVAL}"
