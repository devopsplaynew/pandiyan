#!/bin/bash
host=`hostname`
if type -p java; then
    echo found java executable in PATH
    _java=java
        echo $host >>/fras/cebscr/temp/javaver.txt
        echo "java available under $_java " >>/fras/cebscr/temp/javaver.txt
        whereis java>>/fras/cebscr/temp/javaver.txt 2>>/fras/cebscr/temp/javaver.txt
                which java>>/fras/cebscr/temp/javaver.txt 2>>/fras/cebscr/temp/javaver.txt
    echo $jav2>>/fras/cebscr/temp/javaver.txt
#echo $jav>>/fras/cebscr/temp/javaver.txt
        ls -lrtd /opt/WebSphere/8_5/AppServerBase1/java* |awk '{ print $9}'>>/fras/cebscr/temp/javaver.txt
        echo "*************************************************">>/fras/cebscr/temp/javaver.txt
elif [[ -n "$JAVA_HOME" ]] && [[ -x "$JAVA_HOME/bin/java" ]];  then
    echo found java executable in JAVA_HOME
    _java="$JAVA_HOME/bin/java"
        echo $host >>/fras/cebscr/temp/javaver.txt
        echo $_java >>/fras/cebscr/temp/javaver.txt
        whereis java>>/fras/cebscr/temp/javaver.txt 2>>/fras/cebscr/temp/javaver.txt
                which java>>/fras/cebscr/temp/javaver.txt 2>>/fras/cebscr/temp/javaver.txt 2>>/fras/cebscr/temp/javaver.txt
ls -lrtd /opt/WebSphere/8_5/AppServerBase1/java* |awk '{ print $9}'>>/fras/cebscr/temp/javaver.txt 2>>/fras/cebscr/temp/javaver.txt
        echo "*************************************************">>/fras/cebscr/temp/javaver.txt
else
    echo "no java in $host">>/fras/cebscr/temp/javaver.txt
        whereis java>>/fras/cebscr/temp/javaver.txt 2>>/fras/cebscr/temp/javaver.txt
                which java>>/fras/cebscr/temp/javaver.txt 2>>/fras/cebscr/temp/javaver.txt 2>>/fras/cebscr/temp/javaver.txt
ls -lrtd /opt/WebSphere/8_5/AppServerBase1/java* |awk '{ print $9}'>>/fras/cebscr/temp/javaver.txt 2>>/fras/cebscr/temp/javaver.txt
        echo "*************************************************">>/fras/cebscr/temp/javaver.txt
fi

