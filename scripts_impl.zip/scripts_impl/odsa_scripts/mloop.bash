#!/bin/bash

SERV=`uname -n`
DTTIME=`date +%Y%m%d_%H:%M:%S`
LOGDIR="/fras/script/logs"
DEST="/fras/script/ODSA_scripts/OUTPUT/"
RANDM=`echo $((1 + RANDOM % 20))`
sleep ${RANDM}

echo "local" > /home/ebsdadmin/log_metric/upload_method.cnf
echo "" > /home/ebsdadmin/log_metric/server_pl.cnf

`
SVR=`cat /home/ebsdadmin/log_metric/server_pl.cnf`
    echo "${SERV}      ${UPLD}" >> ${DEST}${SERV}CI_loop.txt
	echo "${SERV}      ${SVR}" >> ${DEST}${SERV}CI_loop.txt
