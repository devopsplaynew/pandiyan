#!/bin/bash
#NOTE run as cibadmin.  Creates .sem file with name of shell script to run on each server in the array list.

SCRIPT_NAME=$1

DTTIME=`date +%Y%m%d_%H:%M:%S`
LOGDIR="/fras/script/logs"
RUNNINGDIR="/fras/script/ODSA_scripts"
WORKINGDIR="/fras/script/ODSA_scripts/WORKING"
SEMFILES=`ls ${WORKINGDIR}/*sem|wc -l|awk '{print $1}'`

if [ ${SEMFILES} -ne '0' ]
then
        echo "${DTTIME} - ${SEMFILES} Semaphores already exist. Stopping." >> ${LOGDIR}/ODSA_scripts.log
        echo "${DTTIME} - ${SEMFILES} Semaphores already exist. Stopping."
        exit 1
else
        echo "${DTTIME} - creating semaphores" >> ${LOGDIR}/ODSA_scripts.log

        for SVRARRAY in `cat ${RUNNINGDIR}/server_PDC.list`
        do
                echo "${SCRIPT_NAME}" > ${WORKINGDIR}/${SVRARRAY}_ODSAscript.sem
        done

        echo "${DTTIME} - Finished creating semaphores" >> ${LOGDIR}/ODSA_scripts.log

fi
