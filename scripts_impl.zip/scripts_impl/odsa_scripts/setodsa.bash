#!/bin/bash

# echo "FileSystem BusyCpu" > ~/log_metric/server_pl.cnf

# echo "CebNG CeBngLog CebngSE" > ~/log_metric/logs_pl.cnf
#echo "local" > ~/log_metric/upload_method.cnf
echo "" > ~/log_metric/perfdatamover_pl.cnf

# mv ~/log_metric/logs_pl.cnf ~/log_metric/logs_pl.cnf.bkp
# mv ~/log_metric/logs_pl.cnfi.bkp ~/log_metric/logs_pl.cnf
