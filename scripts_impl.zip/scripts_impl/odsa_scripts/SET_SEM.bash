#!/bin/bash

CONF=$1
SERVER=$2

echo "${CONF}" > /fras/script/ODSA_scripts/WORKING/${SERVER}_ODSAscript.sem
