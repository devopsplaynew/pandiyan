#!/bin/bash

SERV=`uname -n`
DTTIME=`date +%Y%m%d_%H:%M:%S`
LOGDIR="/fras/script/logs"
DEST="/fras/script/ODSA_scripts/OUTPUT/"



echo "${SERV} ${DTTIME} - Testing Running Semaphore script." >> ${LOGDIR}/PING_test.log
        ping -c1 p01jbrpt01.metavante.com  >> ${DEST}${SERV}PING_test.txt
