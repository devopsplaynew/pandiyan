#!/bin/bash

SERV=`uname -n`
DTTIME=`date`
LOGDIR="/fras/script/logs"
VAL=`cat /home/ebsdadmin/log_metric/upload_method.cnf`
echo "${SERV}     ${VAL}" >> /fras/script/ODSA_scripts/OUTPUT/CI_updates.txt
