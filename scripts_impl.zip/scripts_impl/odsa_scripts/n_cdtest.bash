#!/bin/bash

SERV=`hostname`
DTTIME=`date +%Y%m%d_%H:%M:%S`
LOGDIR="/fras/script/logs"
DEST="/fras/script/ODSA_scripts/OUTPUT/"

	WHICHNSCD=`which nscd`

echo "${SERV}::::${DTTIME}::::${WHICHNSCD}" >> ${DEST}${SERV}NSCD.txt

	NSCDRUN=`ps -ef | grep [n]scd` 

echo "${SERV}::::${DTTIME}::::${NSCDRUN}" >> ${DEST}${SERV}NSCD.txt
