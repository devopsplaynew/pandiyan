#!/bin/bash

#declare -a loop_array=('PDC1INET')
declare -a loop_array=('_fras' '_log_archive ' '_ebsd_dr' '_cib' '_uat' '_opt_security' '_UAT' '_log_archive_OAC' '_OAC' 'oac' '_uat' 'CeB_content' 'erm')
SERV=`uname -n`
DTTIME=`date +%Y%m%d_%H:%M:%S`
RANDM=`echo $((1 + RANDOM % 20))`

LOGDIR="/fras/script/logs"
DEST="/fras/script/ODSA_scripts/OUTPUT/"

sleep ${RANDM}

for LA in ${loop_array[@]}
do

        LOOPVAL=`mount | grep ${LA}`
        while read -r LPV
        do
                echo "${SERV}     ${LA}     ${LPV}"  >> ${DEST}${SERV}CI_MOUNTS.txt
        done <<< "${LOOPVAL}"
done
