#!/bin/bash

SERV=`uname -n`
DTTIME=`date +%Y%m%d_%H:%M:%S`
LOGDIR="/fras/script/logs"
DEST="/fras/script/ODSA_scripts/OUTPUT/"

RELAYHT=`grep -e ^relayhost /etc/postfix/main.cf`
SMARTHT=`grep -e "^dnl define.*SMART_HOST" /etc/mail/sendmail.mc`
DAEMONOPT=`grep -e "^DAEMON_OPTIONS" /etc/mail/sendmail.mc`
DAEMONPORT=`grep -e "^O DaemonPortOptions" /etc/mail/sendmail.cf`
LLMAIN=`ls -l /etc/postfix/main.cf`
LLSENDMC=`ls -l /etc/mail/sendmail.mc`
LLSENDCF=`ls -l /etc/mail/sendmail.cf`

echo "${SERV}:::::RELAYHT:::::${RELAYHT}" >> /fras/script/ODSA_scripts/OUTPUT/${SERV}_sendml.txt
echo "${SERV}:::::SMARTHT:::::${SMARTHT}" >> /fras/script/ODSA_scripts/OUTPUT/${SERV}_sendml.txt
echo "${SERV}:::::DAEMONOPT:::::${DAEMONOPT}" >> /fras/script/ODSA_scripts/OUTPUT/${SERV}_sendml.txt
echo "${SERV}:::::DAEMONPORT:::::${DAEMONPORT}" >> /fras/script/ODSA_scripts/OUTPUT/${SERV}_sendml.txt
echo "${SERV}:::::LLMAIN:::::${LLMAIN}" >> /fras/script/ODSA_scripts/OUTPUT/${SERV}_sendml.txt
echo "${SERV}:::::LLSENDMC:::::${LLSENDMC}" >> /fras/script/ODSA_scripts/OUTPUT/${SERV}_sendml.txt
echo "${SERV}:::::LLSENDCF:::::${LLSENDCF}" >> /fras/script/ODSA_scripts/OUTPUT/${SERV}_sendml.txt

