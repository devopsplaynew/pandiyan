#!/bin/bash 
datime=`date "+%y-%m-%d %H:%M:%S"`
Date=`date "+%m/%d"`
host=`hostname`
cpu_critcal=/fras/cebscr/checkup/logs/bdc_server_cpu.log
disk_critcal=/fras/cebscr/checkup/logs/bdc_server_disk.log
jvm_critcal=/fras/cebscr/checkup/logs/bdc_server_jvm.log
health=/fras/cebscr/checkup/bdc_health.csv
mounts=/fras/cebscr/checkup/logs/bdc_server_mount.log
contm_critcal=/fras/cebscr/checkup/logs/bdc_server_ctm.log
gigaspace_stat=/fras/cebscr/checkup/logs/gigaservice.log
WORKDIR="/fras/script/TOOLS/SOAP"
SCRDIR="/fras/script/ODSA_scripts"
FTPVAL=/fras/cebscr/checkup/logs/ftp_results.log


ipadd=`hostname -i |awk -F " " '{print $1}'`

jvm_cnt=`grep -i $host /fras/cebscr/checkup/output.csv |grep -i 'ERROR' |wc -l`
if [ $jvm_cnt -ge 1 ]
then
jvmstatus="CRITICAL"
grep -i $host /fras/cebscr/checkup/output.csv |grep -i 'ERROR' |cut -d "," -f1 >>$jvm_critcal
else
jvmstatus="GOOD    "
fi

cpuutil=`ps aux | sort -nrk 3,3 | head -n1 |awk '{print $3}'`
cpuproc=`ps aux | sort -nrk 3,3 | head -n1 |awk '{print $11}'`
cpuutilnw=`printf '%.*f\n' 0 $cpuutil`
if [ $cpuutilnw -ge 150 ]
then
cpuustatus="CRITICAL"
echo -e "$host : $ipadd :$cpuproc : $cpuutil" >>$cpu_critcal
 
else
cpuustatus="GOOD    "
fi

diskuse=`df -Ph | awk '+$5 >=90 {print $6}'|grep -v 'oracle' |wc -l`
disk=`df -Ph | awk '+$5 >=90 {print $5":"$6}'|grep -v 'oracle'`
if [ $diskuse -ge 1 ]
then
diskstatus="CRITICAL"
echo -e "$host : $ipadd : $disk" >>$disk_critcal
else
diskstatus="GOOD    "
fi

#mount | grep 'nfs' |awk -F "type" '{print $1}' >/fras/cebscr/checkup/out/$host.mount

mount|grep 'nfs' |awk -F "type" '{print $1}'>/fras/cebscr/checkup/out/$host.newmount
grep -vf /fras/cebscr/checkup/out/$host.newmount /fras/cebscr/checkup/out/$host.mount >/fras/cebscr/checkup/out/$host.out

err_file_size=`stat -c%s /fras/cebscr/checkup/out/$host.out`

if [ $err_file_size -eq 0 ]
then
mountstats="GOOD    "
else
mountstats="CRITICAL"

echo -e "$host : $ipadd : `cat /fras/cebscr/checkup/out/$host.out`" >>$mounts
fi

#declare -a loop_array=('_fras' '_log_archive ' '_ebsd_dr' '_cib' '_opt_security' 'CeB_content' 'erm')
#declare -a loop_array=('_fras' '_log_archive ' '_ebsd_dr' '_cib' '_uat' '_opt_security' '_UAT' '_log_archive_OAC' '_OAC' 'oac' '_uat' 'CeB_content' 'erm')

#i=0
#for LA in ${loop_array[@]}
#do

#   LOOPVAL=`mount | grep ${LA} |wc -l`
#if [ $LOOPVAL -eq 0 ]
#then
#i=$((i+1))
#echo -e "$host : $ipadd : ${LA}" >>$mounts
#fi
#done
#echo $i
#if [ $i -eq 0 ]
#then
#mountstats="GOOD    "
#else
#mountstats="CRITICAL"
#fi

con_m=`ps -ef | grep 'ctma' |wc -l`

if [ $con_m -ge 1 ]
then
contstatus="GOOD    "
else
contstatus="CRITICAL"
echo -e "$host : $ipadd : $con_m" >>$contm_critcal
fi

if [ ${host} = "bdc1rdftcebap50" -o ${host} = "bdc1rdftcebap51" -o ${host} = "bdc1rdftcebap52" -o ${host} = "bdc1rdftcebap53" ];
then
#	echo "">$gigaspace_stat
	giga=`ps -ef | grep 'gigaspace' |grep -v 'grep' |wc -l`
	if [ $giga -eq 12 ]
	then
	gigaservice="RUNNING"
	echo -e "$host : $ipadd : CeB - Gigaspace : $gigaservice" >>$gigaspace_stat
	else
	gigaservice="CRITICAL"
	echo -e "$host : $ipadd : CeB - Gigaspace :$gigaservice" >>$gigaspace_stat
	fi
fi

#if [ ${host} = "bdc1rdftcebws42" -o ${host} = "bdc1rdftcebws43" -o ${host} = "bdc1rdftcebws44" -o ${host} = "bdc1rdftcebws45" ];
#INPUTFILENAME=$SCRDIR/ComServersListFTP_Production.dat
#. $SCRDIR/FTPValidation.sh >$FTPVAL
#fi

echo -e "$host : $ipadd,$jvmstatus,$cpuustatus,$diskstatus,$mountstats,$contstatus">>$health

