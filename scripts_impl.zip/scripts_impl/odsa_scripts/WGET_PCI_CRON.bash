#!/bin/bash
/fras/script/ODSA_scripts/SET_SEM.bash WGET_PCI_CARD pdc2rdftcebwb02
/fras/script/ODSA_scripts/SET_SEM.bash WGET_PCI_CEB pdc2rdftcebws22
/fras/script/ODSA_scripts/SET_SEM.bash WGET_PCI_CEB_INT pdc2rdftcebws23
/fras/script/ODSA_scripts/SET_SEM.bash WGET_PCI_CEBWS pdc2rdftcebws24
/fras/script/ODSA_scripts/SET_SEM.bash WGET_PCI_DIH pdc2rdftcebws25
/fras/script/ODSA_scripts/SET_SEM.bash WGET_PCI_IDS pdc2rdftcebws26
/fras/script/ODSA_scripts/SET_SEM.bash WGET_PCI_OAC pdc2rdftoacws01
/fras/script/ODSA_scripts/SET_SEM.bash WGET_PCI_VE pdc2rdftoacws02
