#!/bin/bash

SERV=`uname -n`
DTTIME=`date`
LOGDIR="/fras/script/logs"

echo "${SERV}     ${DTTIME}" >> /fras/script/ODSA_scripts/OUTPUT/CI_timestamps.txt
