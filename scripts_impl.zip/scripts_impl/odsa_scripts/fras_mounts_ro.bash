#!/bin/bash

SERV=`uname -n`
DTTIME=`date +%Y%m%d_%H:%M:%S`

LOGDIR="/fras/script/logs"
DEST="/fras/script/ODSA_scripts/OUTPUT/"

        MNTVAL=`mount | grep ro`
        while read -r LPV
        do
                        echo "${SERV}::::::${LPV}"  >> ${DEST}${SERV}CI_MOUNT_RO.txt
        done <<< "${MNTVAL}"
