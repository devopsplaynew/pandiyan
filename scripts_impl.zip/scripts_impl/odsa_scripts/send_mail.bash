#!/bin/bash

SERV=`uname -n`
DTTIME=`date +%Y%m%d_%H:%M:%S`
LOGDIR="/fras/script/logs"
DEST="/fras/script/ODSA_scripts/OUTPUT/"
RANDM=`echo $((1 + RANDOM % 20))`
sleep ${RANDM}

mailx -s "${SERV} sendmail" -r "eBSD.ProcessNotifications@fisglobal.com" steve.mosey@fisglobal.com,Li.W.Kuo@fisglobal.com < /fras/script/ODSA_scripts/sendmail.text


