#!/bin/bash

TARGET_PID=`ps -ef|egrep "[W]get_ping_pl" |awk '{print $2}'`
if [[ "${TARGET_PID}" = "" ]]
then
	/fras/log_metric/bin/Wget_ping_pl.ksh wget_bci_ceb_int
fi
