#!/bin/bash -x
datime=`date "+%y-%m-%d %H:%M:%S"`
Date=`date "+%m/%d"`
host=`hostname`
cpu_critcal=/fras/cebscr/checkup/logs/bdc_server_cpu.log
disk_critcal=/fras/cebscr/checkup/logs/bdc_server_disk.log
mem_critcal=/fras/cebscr/checkup/logs/bdc_server_mem.log
jvm_critcal=/fras/cebscr/checkup/logs/bdc_server_jvm.log
health=/fras/cebscr/checkup/bdc_health.csv
mounts=/fras/cebscr/checkup/logs/bdc_server_mount.log
contm_critcal=/fras/cebscr/checkup/logs/bdc_server_ctm.log
gigaspace_stat=/fras/cebscr/checkup/logs/gigaservice.log
WORKDIR="/fras/script/TOOLS/SOAP"
SCRDIR="/fras/script/ODSA_scripts"
FTPVAL=/fras/cebscr/checkup/logs/ftp_results.log


ipadd=`hostname -i |awk -F " " '{print $1}'`

jvm_cnt=`grep -i $host /fras/cebscr/checkup/output.csv |grep -i 'ERROR' |wc -l`
if [ $jvm_cnt -ge 1 ]
then
jvmstatus="Critical"
grep -i $host /fras/cebscr/checkup/output.csv |grep -i 'ERROR' |cut -d "," -f1 >>$jvm_critcal
else
jvmstatus="Good    "
fi

cpuutil=`ps aux | sort -nrk 3,3 | head -n1 |awk '{print $3}'`
cpuproc=`ps aux | sort -nrk 3,3 | head -n1 |awk '{print $11}'`
cpuutilnw=`printf '%.*f\n' 0 $cpuutil`
if [ $cpuutilnw -ge 150 ]
then
cpuustatus="Critical"
echo -e "$host : $ipadd :$cpuproc : $cpuutil" >>$cpu_critcal
 
else
cpuustatus="Good    "
fi

diskuse=`df -Ph | awk '+$5 >=90 {print $6}'|grep -v 'oracle\|snapshot' |wc -l`
disk=`df -Ph | awk '+$5 >=90 {print $5":"$6}'|grep -v 'oracle\|snapshot'`
if [ $diskuse -ge 1 ]
then
diskstatus="Critical"
echo -e "$host : $ipadd : $disk" >>$disk_critcal
else
diskstatus="Good    "
fi

#mount | grep 'nfs' |awk -F "type" '{print $1}' >/fras/cebscr/checkup/out/$host.mount

mount|grep 'nfs' |awk -F "type" '{print $1}'>/fras/cebscr/checkup/out/$host.newmount
grep -vf /fras/cebscr/checkup/out/$host.newmount /fras/cebscr/checkup/out/$host.mount >/fras/cebscr/checkup/out/$host.out

err_file_size=`stat -c%s /fras/cebscr/checkup/out/$host.out`

if [ $err_file_size -eq 0 ]
then
mountstats="Good    "
else
mountstats="Critical"

echo -e "$host : $ipadd : `cat /fras/cebscr/checkup/out/$host.out`" >>$mounts
fi


con_m=`ps -ef | grep 'ctma' |wc -l`
conm_ver=`/opt/ctma610/ctm/JRE/bin/java -version 2>&1 | head -n 1| awk -F '"'  '{print $2}'`
if [ $con_m -ge 1 ]
then
contstatus=${conm_ver}
else
contstatus="Critical"
echo -e "$host : $ipadd : $contstatus" >>$contm_critcal
fi

TOTALMEM=`free -m | head -2 | tail -1| awk '{print $2}'`
FREEMEM1=`free -m | head -2 | tail -1| awk '{print $4}'`
freemem=$(($FREEMEM1 * 100 / $TOTALMEM ))
#highmem=`ps -eo pmem,pcpu,pid,args | sort -k 1 -n -r |head -1 |awk '{print $1"%:"$2"%:"$NF}'`
highmem=`ps -eo pmem,pcpu,pid,user,args | sort -k 1 -n -r |head -1 |awk '{print $1"%:"$2"%:"$3":"$4":"$NF}'`
if [ $freemem -le 5 ]
then
memstatus="${freemem}"
echo -e "$host : $ipadd : ${highmem}" >>$mem_critcal
else
memstatus="${freemem}"
fi


if [ ${host} = "bdc1rdftcebap50" -o ${host} = "bdc1rdftcebap51" -o ${host} = "bdc1rdftcebap52" -o ${host} = "bdc1rdftcebap53" ];
then

PU1=`ps -ef | grep 'java' |grep "\PU1\b" |wc -l`
PU1_1=`ps -ef | grep 'java' |grep "\PU1_1\b" |wc -l`
PU2=`ps -ef | grep 'java' |grep "\PU2\b" |wc -l`
PU2_1=`ps -ef | grep 'java' |grep "\PU2_1\b" |wc -l`
PU3=`ps -ef | grep 'java' |grep "\PU3\b"|wc -l`
PU3_1=`ps -ef | grep 'java' |grep "\PU3_1\b" |wc -l`
PU4=`ps -ef | grep 'java' |grep "\PU4\b"|wc -l`
PU4_1=`ps -ef | grep 'java' |grep "\PU4_1\b" |wc -l`
PU5=`ps -ef | grep 'java' |grep "\PU5\b" |wc -l`
PU5_1=`ps -ef | grep 'java' |grep "\PU5_1\b" |wc -l`

if [ $PU1 -eq 1 ] || [ $PU1_1 -eq 1 ];then
        echo -e "$host : $ipadd : CeB - Gigaspace PU1-$PU1:PU1_1-$PU1_1: Running" >>$gigaspace_stat
else
        echo -e "$host : $ipadd : CeB - Gigaspace PU1-$PU1:PU1_1-$PU1_1:Critical" >>$gigaspace_stat
fi

if [ $PU2 -eq 1 ] || [ $PU2_1 -eq 1 ];then
        echo -e "$host : $ipadd : CeB - Gigaspace PU2-$PU2:PU2_1-$PU2_1: Running" >>$gigaspace_stat
else
        echo -e "$host : $ipadd : CeB - Gigaspace PU2-$PU2:PU2_1-$PU2_1:Critical" >>$gigaspace_stat
fi

if [ $PU3 -eq 1 ] || [ $PU3_1 -eq 1 ];then
        echo -e "$host : $ipadd : CeB - Gigaspace PU3-$PU3:PU3_1-$PU3_1: Running" >>$gigaspace_stat
else
        echo -e "$host : $ipadd : CeB - Gigaspace PU3-$PU3:PU3_1-$PU3_1:Critical" >>$gigaspace_stat
fi

if [ $PU4 -eq 1 ] || [ $PU4_1 -eq 1 ];then
        echo -e "$host : $ipadd : CeB - Gigaspace PU4-$PU4:PU4_1-$PU4_1: Running" >>$gigaspace_stat
else
        echo -e "$host : $ipadd : CeB - Gigaspace PU4-$PU4:PU4_1-$PU4_1:Critical" >>$gigaspace_stat
fi

if [ $PU5 -eq 1 ] || [ $PU5_1 -eq 1 ];then
        echo -e "$host : $ipadd : CeB - Gigaspace PU5-$PU5:PU5_1-$PU5_1: Running" >>$gigaspace_stat
else
        echo -e "$host : $ipadd : CeB - Gigaspace PU5-$PU5:PU5_1-$PU5_1:Critical" >>$gigaspace_stat
fi
echo -e "$host : $ipadd,$PU1,$PU1_1,$PU2,$PU2_1,$PU3,$PU3_1,$PU4,$PU4_1,$PU5,$PU5_1">>/fras/cebscr/checkup/out/giga.log
fi

if [ ${host} = "bdc1rdftcebwb02" -o ${host} = "bdc1rdftcebwb03" -o ${host} = "bdc1rdftcebwb04" -o ${host} = "bdc1rdftcebwb05" -o ${host} = "bdc1rdftoacwb01" -o ${host} = "bdc1rdftoacwb02" -o ${host} = "bdc1rdftoacwb03" -o ${host} = "bdc1rdftoacwb04" -o ${host} = "bdc1rdftcebap01" -o ${host} = "bdc1rdftcebap02" -o ${host} = "bdc1rdftidsap01" -o ${host} = "bdc1rdftidsap02" -o ${host} = "bdc1rdftcebap50" -o ${host} = "bdc1rdftcebap51" -o ${host} = "bdc1rdftcebap52" -o ${host} = "bdc1rdftcebap53" -o ${host} = "bdc1rdftoacap01" -o ${host} = "bdc1rdftoacap02" ];then
jvmstatus="NA      "
fi

if [ ${host} = "bdc1rdftcebws42" -o ${host} = "bdc1rdftcebws43" -o ${host} = "bdc1rdftcebws44" -o ${host} = "bdc1rdftcebws45" ]; then 

grep -i 'ACCEPTED' /opt/ctma610/ctm/dailylog/daily_ctmag_20220406.log |grep -i 'cebfw-eod' |awk '{print $6}' |sort >>/fras/cebscr/checkup/logs/cebeodexec.log
grep -i 'ENDED OK' /opt/ctma610/ctm/dailylog/daily_ctmag_20220406.log |grep -i 'cebfw-eod' |awk '{print $6}' |sort >>/fras/cebscr/checkup/logs/cebeodcomp.log

longrun=`ps -eo uid,pid,etime,user,args --sort=start_time | grep 'cibadmin' | egrep ' ([1-9]-)[0-9]' | awk '{print ${host} ":"$2 ":"$3":"$4 ":"$5}'`
longruncnt=`ps -eo uid,pid,etime,user,args --sort=start_time | grep 'cibadmin' |grep -v 'top\|su' | egrep ' ([1-9]-)[0-9]' | awk '{print $2 ":"$3":"$4 ":"$5}' |wc -l`
	if [ $longruncnt -gt 0 ]; then
for i in `ps -eo uid,pid,etime,user,args --sort=start_time | grep 'cibadmin' |grep -v 'top\|su' | egrep ' ([1-9]-)[0-9]' | awk '{print $2 ":"$3":"$4 ":"$5}'`;do echo -e "`hostname`:${i}">>/fras/cebscr/checkup/logs/longrun.log;done;
	fi
fi

if [ ${host} = "bdc1rdftoacws01" ]
then
telnetimslist=/fras/cebscr/input/telnetimsip.list
telnetimslog=/fras/cebscr/checkup/out/telnetims.log
telnetimssta=/fras/cebscr/checkup/logs/telnetimsstatus.log

echo "">$telnetimslog

while read hostname port bank
do
echo -e '\035\nquit' | telnet $hostname $port
if [ $? -eq 1 ]
then
echo "$hostname $port $bank - Bad">>$telnetimslog
else
echo "$hostname $port $bank - Good">>$telnetimslog
fi
done < $telnetimslist
sort -i $telnetimslog>$telnetimssta
chmod 777 $telnetimslog
chmod 777 $telnetimssta

fi
#echo -e '\035\nquit' |openssl s_client -connect voltage-pp-0000.prod.local:443 -tls1_2 >/fras/cebscr/checkup/out/$host.cert
echo -e "$host : $ipadd,$jvmstatus,$cpuustatus,$diskstatus,$mountstats,$contstatus,$memstatus">>$health
#if [ ${host} = "bdc1rdftcebap02" ];then
#sh /fras/cebscr/checkup/bin/mailalert
#fi

