#!/bin/bash

declare -a loop_array=(upload_method.cnf server_pl.cnf perfdatamover_pl.cnf filesystem_pl.cnf)

SERV=`uname -n`
DTTIME=`date +%Y%m%d_%H:%M:%S`
LOGDIR="/fras/script/logs"
DEST="/fras/script/ODSA_scripts/OUTPUT/"
RANDM=`echo $((1 + RANDOM % 10))`
sleep ${RANDM}

for LA in ${loop_array[@]}
do
        LOOPVAL=`head -10  ~/log_metric/${LA}`
        echo "${SERV}     ${LA}     ${LOOPVAL}" >> ${DEST}${SERV}CI_logmetric.txt
done
