#!/bin/bash

SERV=`uname -n`
DTTIME=`date +%Y%m%d_%H:%M:%S`
LOGDIR="/fras/script/logs"


echo "${SERV} ${DTTIME} - Testing Running Semaphore script." >> ${LOGDIR}/ODSA_test.log
        ls -l /opt/WebSphere/7/AppServerBase1/java/jre/lib/security/java.security  >> ${LOGDIR}/ODSA_test.log


#sleep 120
#echo "${SERV} ${DTTIME} - Testing Running Semaphore script." >> ${LOGDIR}/ODSA_test.log
