#!/bin/bash

SERV=`uname -n`
DTTIME=`date +%Y%m%d_%H:%M:%S`
val1=`mount  | grep 'nfs' | grep 'BDCG2' |wc -l`

if [ $val1 -ge 1 ]
then
echo $SERV>>/fras/cebscr/temp/Gen2.log
mount  | grep 'nfs' | grep 'BDCG2'>>/fras/cebscr/temp/Gen2.log
echo "">>/fras/cebscr/temp/Gen2.log
echo $SERV>>/fras/cebscr/temp/Gen1.log
mount  | grep 'nfs' | grep -v 'BDCG2' >>/fras/cebscr/temp/Gen1.log
echo "">>/fras/cebscr/temp/Gen1.log
else
echo $SERV>>/fras/cebscr/temp/Gen1.log
mount  | grep 'nfs' | grep -v 'BDCG2' >>/fras/cebscr/temp/Gen1.log
echo "">>/fras/cebscr/temp/Gen1.log
fi
