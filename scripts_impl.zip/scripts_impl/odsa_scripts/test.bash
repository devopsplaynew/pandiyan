#!/bin/bash

declare -a loop_array=('_fras' '_log_archive ' '_ebsd_dr' '_cib' '_uat' '_opt_security' '_UAT' '_log_archive_OAC' '_OAC' 'oac' '_uat' 'CeB_content' 'erm')
i=0
for LA in ${loop_array[@]}
do

   LOOPVAL=`mount | grep ${LA} |wc -l`
if [ $LOOPVAL -eq 0 ]
then
i=$((i+1))
echo -e "$host : ${LA}" >>mounts.txt
fi
done
echo $i
if [ $i -eq 0 ]
then
mountstats="GOOD    "
else
mountstats="CRITICAL"
fi

