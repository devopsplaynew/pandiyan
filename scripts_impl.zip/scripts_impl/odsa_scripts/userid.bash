#!/bin/bash

declare -a loop_array=('cebsec' 'cibadmin' 'ebsdadmin' 'gcadmin' 'controlm' 'ctma610' 'gigusr' 'harvest*' 'hvadmin' 'oracle' 'oraclmgr' 'orinle' 'sitescop' 'wasadmin' 'eg' 'EG' 'cebsftp')

SERV=`uname -n`
DTTIME=`date +%Y%m%d_%H:%M:%S`
LOGDIR="/fras/script/logs"
DEST="/fras/script/ODSA_scripts/OUTPUT/"
RANDM=`echo $((1 + RANDOM % 20))`
sleep ${RANDM}

for LA in ${loop_array[@]}
do

        LOOPVAL=`cat /etc/passwd | grep ${LA}`
        while read -r LPV
        do
                echo "${SERV}     ${LA}     ${LPV}" >> ${DEST}${SERV}CI_USERID.txt
        done <<< "${LOOPVAL}"
done

