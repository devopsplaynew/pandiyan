#!/bin/bash

SERV=`uname -n`
DTTIME=`date +%Y%m%d_%H:%M:%S`

declare -a loop_array=('/opt/security')

for LA in ${loop_array[@]}
do

        LOOPVAL=`mount | grep ${LA} |wc -l`

if [ $LOOPVAL -ge 1 ]
then
echo -e "${LA} is available in $SERV ">>/fras/cebscr/temp/mount_avail.log
else
echo -e "${LA} is not available in $SERV ">>/fras/cebscr/temp/mount_miss.log
fi

done

