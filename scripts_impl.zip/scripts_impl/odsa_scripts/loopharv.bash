#!/bin/bash

SERV=`uname -n`
DTTIME=`date +%Y%m%d_%H:%M:%S`
LOGDIR="/fras/script/logs"
DEST="/fras/script/ODSA_scripts/OUTPUT/"
RANDM=`echo $((1 + RANDOM % 20))`
sleep ${RANDM}

	LOOPVAL=`ls -l /cccharv/CEB/CEB*/staging/*/*SNAPSHOT*/*zip`
	while read -r LPV
	do
		echo "${SERV}######${LPV}" >> ${DEST}${SERV}CI_harv.txt
	done <<< "${LOOPVAL}"
