#!/bin/bash

# declare -a loop_array=('fras*' 'log_archive*' 'cib' 'CeB_content' 'opt' 'log_archive_OAC' 'www' 'GC*' 'K1' 'applogs' 'cccharv' 'oracle' '*uat' '*UAT' 'GC_content' 'weblogs' 'ceb_redirect' 'ceb_redirect/*' 'opt/ctma610/ctm/sysout' 'CeBBankMail' 'CeBBankMailTemp'  'CeB_content/PATH/*' 'CeB_content/*' 'cebAdmHelpFiles' 'ebs' 'www/content' 'eg*' 'ids*' 'erm/*')
declare -a loop_array=('oracle')

SERV=`uname -n`
DTTIME=`date +%Y%m%d_%H:%M:%S`
LOGDIR="/fras/script/logs"
DEST="/fras/script/ODSA_scripts/OUTPUT/"
RANDM=`echo $((1 + RANDOM % 20))`
sleep ${RANDM}

for LA in ${loop_array[@]}
do

        LOOPVAL=`df -h /${LA} | tail -1`
        while read -r LPV
        do
                echo "${SERV}     ${LA}     ${LPV}" >> ${DEST}${SERV}CI_FSize.txt
        done <<< "${LOOPVAL}"
done

