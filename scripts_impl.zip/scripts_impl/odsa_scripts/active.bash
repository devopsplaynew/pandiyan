#!/bin/bash

SERV=`uname -n`
DTTIME=`date +%Y%m%d_%H:%M:%S`
LOGDIR="/fras/script/ODSA_scripts/OUTPUT"


echo "${SERV} ${DTTIME} - Testing Running Semaphore script." >> ${LOGDIR}/ODSA_test.log

