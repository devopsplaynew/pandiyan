#!/bin/bash

SERV=`uname -n`
DTTIME=`date +%Y%m%d_%H:%M:%S`

declare -a loop_array=('/opt/security')

for LA in ${loop_array[@]}
do

        LOOPVAL=`mount | grep ${LA} |wc -l`

if [ $LOOPVAL -ge 1 ]
then
echo $SERV>>/fras/cebscr/temp/cmount_avail.log
ls -ld /opt/security>>/fras/cebscr/temp/cmount_avail.log
mount | grep ${LA} >>/fras/cebscr/temp/cmount_avail.log
else
echo "opt_security is not available in $SERV" >>/fras/cebscr/temp/cmount_miss.log
fi

done

