#!/bin/bash
datime=`date "+%y-%m-%d %H:%M:%S"`
#Date=`date "+%m/%d/%y"`
Date=`date --date='-1 day' "+%m/%d/%y"`

HOSTNAME=`hostname`
servr=`hostname |cut -c9-13`
testresults=/fras/validation_cebws.log

if [ ! -f "$testresults" ]
then
echo "Test Results:" >$testresults
echo "------------------------------------------------------------------------" >>$testresults
echo "HostName        | Disk     | CPU      | JVM      | Cert     | Java     |" >>$testresults
echo "------------------------------------------------------------------------" >>$testresults
fi


diskuse=`df -h|awk '1<NR&&NF>1{print $4}'|sort -nr |head -2 |grep '%' |sed "s/[^0-9]//g"`
if [ $diskuse -ge 85 ]
then
diskstatus="CRITICAL"
else
diskstatus="GOOD    "
fi

cpuutil=`ps aux | sort -nrk 3,3 | head -n1 |awk '{print $3}'`
cpuutilnw=`printf '%.*f\n' 0 $cpuutil`
if [ $cpuutilnw -ge 50 ]
then
cpuustatus="CRITICAL"
else
cpuustatus="GOOD    "
fi

if [ $servr == "cebws" ]
then
        jvmcheck=`ps -ef | grep 'java' |grep -v 'grep' |awk '{print $12}' |wc -l`
        certcheck=`grep -i 'Certificate chaining error' /applogs/*/WAS85/logs/*SystemOut*|grep $Date|wc -l`
        if [ $jvmcheck -ne 7 ]
        then
        jvmmstatus="CRITICAL"
        javastatus="CRITICAL"
        else
        jvmmstatus="GOOD    "
        javastatus="GOOD    "

        fi
                        if [ $certcheck -eq 0 ]
                        then
                        certstatus="GOOD    "
                        else
                        diskstatus="CRITICAL"
                        fi
else
jvmmstatus="NON WS  "
javastatus="NON WS  "
certstatus="NON WS  "
fi

#httpstatus="NONE    "
#gigastatus="NONE    "
mount |cut -d " " -f1 >/fras/cebscr/temp/$HOSTNAME.mount
echo -e "`hostname` | $diskstatus | $cpuustatus | $jvmmstatus | $certstatus | $javastatus |" >>$testresults

chmod 777 $testresults

