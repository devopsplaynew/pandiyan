#!/bin/bash
/fras/script/ODSA_scripts/SET_SEM.bash WGET_BCI_CARD bdc1rdftcebwb02
/fras/script/ODSA_scripts/SET_SEM.bash WGET_BCI_CEB bdc1rdftcebws22
/fras/script/ODSA_scripts/SET_SEM.bash WGET_BCI_CEB_INT bdc1rdftcebws23
/fras/script/ODSA_scripts/SET_SEM.bash WGET_BCI_CEBWS bdc1rdftcebws27
/fras/script/ODSA_scripts/SET_SEM.bash WGET_BCI_DIH bdc1rdftcebws25
/fras/script/ODSA_scripts/SET_SEM.bash WGET_BCI_IDS bdc1rdftcebws26
/fras/script/ODSA_scripts/SET_SEM.bash WGET_BCI_OAC bdc1rdftoacws01
/fras/script/ODSA_scripts/SET_SEM.bash WGET_BCI_VE bdc1rdftoacws02
