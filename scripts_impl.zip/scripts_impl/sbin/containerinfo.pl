#!/fras/perl/bin/perl

=head1 NAME

containerinfo.pl - Lists banks by container

=head1 SYNOPSIS

load_perfdata.pl [options] 

 Options:
   --container=STRING  -c     Container ID
   --datadir=STRING    -d     Data dir to read CSV files from
   --filename=STRING   -f     File name to filter contents of datadir on.
   --threshold=DOUBLE  -t     Banks are considered to be on contained if their 
                              traffic exceeds this %. Default: .02

=head1 OPTIONS

=over 12

=item B<--container> 

The container to list banks for

=item B<--datadir> 

The directory containing CSV datafiles. Default: /ebsd/opsnet/bankinfo/csvin/

=item B<--filename> 

Substring to filter the csv datafiles on. Only files matching this substring will be sorted by date. Default: Bank-Container-Logins

=item B<--threshold> 

Banks are considered to be on a container if the container carries this % or more of their total traffic. Default: .02 (2%)

=back 


=head1 DESCRIPTION 

B<containerinfo.pl> will read the previous day's bank by container CSV and list all
banks that had more than a threshold of traffic in the supplied container.

=cut


use strict;
use warnings;

use 5.014;

use Text::CSV::Slurp;
use Getopt::Long;
use Pod::Usage;
use Path::Class;
use List::Util qw/sum/;
use Data::Printer;

my $opts = { datadir => '/ebsd/opsnet/bankinfo/csvin/',
             filename => 'Bank-Container-Logins',
             threshold => .02,
           };

GetOptions ( 'container|c=s'        => \$opts->{container},
             'datadir|d=s'          => \$opts->{datadir},
             'filename|f=s'         => \$opts->{filename},
             'threshold|t=f'        => \$opts->{threshold},
             'help|?'               => \$opts->{help},
           ) or pod2usage(0);
           
pod2usage(1) if $opts->{help};
           
$opts->{container} or do {say 'Container required!' and exit 1};
-e $opts->{datadir} or do {say "No data directory $opts->{datadir} on filesystem" and exit 1};

my $dir = dir($opts->{datadir});
my ($file) = sort {$b cmp $a} grep {/$opts->{filename}/} $dir->children; ### grab the most recent file in the directory that matches the filename string set

my $data = Text::CSV::Slurp->load(file => $file);
my @output;

for my $fi (@$data) {
    my $total = sum map {$fi->{$_}} grep {exists $fi->{$_}} qw/A C D E F G H J/; 
    if ($fi->{$opts->{container}} / $total > $opts->{threshold}) {
        push (@output, $fi->{FI});
    }
}

say "Container $opts->{container} carries load for the following FIs:";
say join ', ', @output; 
