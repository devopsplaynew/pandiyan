#!/fras/perl/bin/perl
use 5.014;
use strict;
use warnings;

use Nagios::Plugin::WWW::Mechanize;
use FIS::DBI;
use DateTime::HiRes;
use DateTime::Format::Duration;
use Scalar::Util qw/blessed/;

#########################################################
### Init our nagios check object   
#########################################################

my $np = Nagios::Plugin::WWW::Mechanize->new( usage => 'Usage: %s [-v|--verbose] [-H <host>] [-t <timeout>] '  
                                                     . '[-c|--critical=<threshold>] [-w|--warning=<threshold>]'
                                                     . '[-r|rel_uri=<uri>] [-b|bank=<bank_group>] [--branch=<branch_id>]'
                                                     . '[-u|username=<username>] [-p|password=<password>]'
                                                     . '[-n|node=<node>]',
                                              license => 'Copyright FIS 2013',
                                              include_time => 0,
                                              mech => { noproxy => 0,
                                                        cookie_jar => {},
                                                        autocheck => 0,
                                                        quiet => 1,
                                                      },
                                            );
            
$np->mech->proxy(['https', 'http'], 'connect://proxy.prod.local:8080');

$np->add_arg( spec => 'host|H=s',
              help => 'HTTPS domain to test',
              default => 'cibng.ibanking-services.com',
            );
            
$np->add_arg( spec => 'rel_uri|r=s',
              help => 'Relative URI to login applet',
              default => 'eAM/Credential/Index'
            );
            
$np->add_arg( spec => 'bank|b=s',
              help => 'Bank FI_ORG id',
              default => '149',
            );        

$np->add_arg( spec => 'branch=i',
              help => 'CeB branch id',
            );             

$np->add_arg( spec => 'username|u=s',
              help => 'Username',
              required => 1,
            );           

$np->add_arg( spec => 'password|p=s',
              help => 'Password',
              #required => 1,
            );
            
$np->add_arg( spec => 'node|n=s',
              help => 'JVM Node (p01jbappnn_C_I)',
            );
            
$np->add_arg( spec => 'critical|c=i',
              help => 'Total time (s) to throw CRITICAL state',
              default => 30,
            );         
            
$np->add_arg( spec => 'warning|w=i',
              help => 'Total time (s) to throw WARNING state',
              default => 15,
            );           

$np->getopts;

### found by this on webservers:
### grep CloneID /opt/IBMHTTPD/https-CEBNG-?-Prd-7/Plugins/config/P01jbweb02-CEBNG-?-Prd-7/plugin-cfg.xml|cut -d" " -f1,8,13 | perl -lne 'chomp $_; my ($cloneid, $name) = $_ =~ /CloneID=(.*) Name=(.*)/; print $name, q/ => /, $cloneid, qq/,/'

my %node_ids = (
    "p01jbapp20_A_1" => "181unqvrf", "p01jbapp20_A_2" => "181unr2rp", "p01jbapp20_A_3" => "181unr3sh",
    "p01jbapp20_A_4" => "181unr571", "p01jbapp20_A_5" => "181unr680", "p01jbapp20_A_6" => "181unr79c",
    "p01jbapp21_A_1" => "181unr8ah", "p01jbapp21_A_2" => "181unr9di", "p01jbapp21_A_3" => "181unrafg",
    "p01jbapp21_A_4" => "181unrbgq", "p01jbapp21_A_5" => "181unrci7", "p01jbapp21_A_6" => "181unrdji",
    "p01jbapp22_C_1" => "181va8aqv", "p01jbapp22_C_2" => "181va8et0", "p01jbapp22_C_3" => "181va8g5n",
    "p01jbapp22_C_4" => "181va8hd2", "p01jbapp22_C_5" => "181va8ikc", "p01jbapp22_C_6" => "181va8k9e",
    "p01jbapp23_C_1" => "181va8lfr", "p01jbapp23_C_2" => "181va8mn6", "p01jbapp23_C_3" => "181va8nvl",
    "p01jbapp23_C_4" => "181va8p72", "p01jbapp23_C_5" => "181va8qds", "p01jbapp23_C_6" => "181va8rl2",
    "p01jbapp24_D_1" => "182bqu9ne", "p01jbapp24_D_2" => "182bqud8i", "p01jbapp24_D_3" => "182bquect",
    "p01jbapp24_D_4" => "182bqufhl", "p01jbapp24_D_5" => "182bquh2d", "p01jbapp24_D_6" => "182bqui7e",
    "p01jbapp25_D_1" => "182bqujcl", "p01jbapp25_D_2" => "182bqukku", "p01jbapp25_D_3" => "182bqulqr",
    "p01jbapp25_D_4" => "182bqun09", "p01jbapp25_D_5" => "182bquo6h", "p01jbapp25_D_6" => "182bqupcb",
    "p01jbapp26_E_1" => "182ecppgg", "p01jbapp26_E_2" => "182ecpt1n", "p01jbapp26_E_3" => "182ecpu5o",
    "p01jbapp26_E_4" => "182ecpvag", "p01jbapp26_E_5" => "182ecq0f3", "p01jbapp26_E_6" => "182ecq1qe",
    "p01jbapp27_E_1" => "182ecq301", "p01jbapp27_E_2" => "182ecq45v", "p01jbapp27_E_3" => "182ecq5l7",
    "p01jbapp27_E_4" => "182ecq6qm", "p01jbapp27_E_5" => "182ecq812", "p01jbapp27_E_6" => "182ecq974",
    "p01jbapp28_F_1" => "181ag3q0g", "p01jbapp28_F_2" => "181ag3soa", "p01jbapp28_F_3" => "181ag3tpf",
    "p01jbapp28_F_4" => "181ag3uqj", "p01jbapp28_F_5" => "181ag3vrl", "p01jbapp28_F_6" => "181ag40sf",
    "p01jbapp29_F_1" => "181ag41t8", "p01jbapp29_F_2" => "181ag42tn", "p01jbapp29_F_3" => "181ag43uq",
    "p01jbapp29_F_4" => "181ag450e", "p01jbapp29_F_5" => "181ag461k", "p01jbapp29_F_6" => "181ag4734",
    "p01jbapp30_G_2" => "181an01p2", "p01jbapp30_G_3" => "181an02q8", "p01jbapp31_G_1" => "181an0723",
    "p01jbapp31_G_2" => "181an083h", "p01jbapp31_G_3" => "181an095c", "p01jbapp30_G_1" => "181flgkbc",
    "p01jbapp32_H_1" => "182jnsc8h", "p01jbapp32_H_2" => "182jnsfaq", "p01jbapp32_H_3" => "182jnsgcj",
    "p01jbapp33_H_1" => "182jnskmh", "p01jbapp33_H_2" => "182jnslot", "p01jbapp33_H_3" => "182jnsmsn",
    "p01jbapp34_J_1" => "182ob1h5m", "p01jbapp34_J_2" => "182ob1jsu", "p01jbapp34_J_3" => "182ob1l4h",
    "p01jbapp35_J_1" => "182ob1pjk", "p01jbapp35_J_2" => "182ob1qo0", "p01jbapp35_J_3" => "182ob1rt1",
);

my $fiorg = sprintf("%03s", $np->opts->bank);

### Get FID from DB & validate BG
my $ops_dbh = FIS::DBI->new( db_name => 'ebsd_opsnet' )->get_dbh;
my $fid = $ops_dbh->selectall_arrayref( 'SELECT fiaba FROM ceburl WHERE fiorg = ?', 
                                         undef, 
                                         $fiorg,
                                      )->[0]->[0]; ## Deref -- either get 1 val or undef

unless ($fid) { 
  $np->nagios_die( "Invalid bank id $fiorg" ); 
}

### If we need it, try to get password from DB 
my $pw;
if (!$np->opts->password) {
    my $rpt_dbh = FIS::DBI->new( db_name => 'ebsd_report_data' )->get_dbh;
    $pw = $rpt_dbh->selectall_arrayref( 'SELECT password FROM credentials_ceb WHERE fi_org = ? AND username = ?', 
                                         undef, 
                                         $fiorg, $np->opts->username
                                      )->[0]->[0]; ## Deref -- either get 1 val or undef
}

unless ($pw or $np->opts->password) { 
  $np->nagios_die( "Password credentials needed" ); 
}

## Format various URI IDs as needed
my $fifid = sprintf("%09d", $fid);
my $orgid = $fiorg . '_' .$fifid;
my $brand = $orgid;
if ($np->opts->branch) {
    $brand .= '_' . sprintf("%03d", $np->opts->branch);
}

if ($np->opts->node) {
    if (!$node_ids{$np->opts->node}) {
        $np->nagios_die( 'Invalid node id ' . $np->opts->node );
    }
}

## Assemble URI
my $uri_args = "?brand=$brand&orgId=$orgid&FIFID=$fifid&appId=CeB&FIORG=$fiorg";
my $uri = 'https://' . $np->opts->host . '/' . $np->opts->rel_uri . $uri_args;
                                              
#########################################################
### Perform login procedure.          
#########################################################
                                              
### Time perfdata
my $tz = DateTime::TimeZone->new( name => 'America/Chicago' );
my $start = DateTime::HiRes->now( time_zone => $tz );
my $df = DateTime::Format::Duration->new( pattern => '%s' );

### Start by getting the login page. This sets cookies needed.
$np->get( $uri );
if (!$np->mech->success) {
    my $msg = "Can't load login page '". $np->mech->uri. "': ". $np->mech->response->status_line;
    log_debug_info($np->mech->response, $msg);
    $np->nagios_exit(CRITICAL, $msg);
}
### Check for maint redirect
if ($np->mech->content =~ /currently performing maintenance/) {
    ### Maybe check against https://cib-maintpg.ibanking-services.com/ uri instead?
    $np->nagios_exit(CRITICAL, 'Site maintenance page live')
}
$np->add_perfdata(
  label => "login_get",
  uom   => 's',
  value => $df->format_duration(DateTime::HiRes->now(time_zone => $tz) - $start),
);

### Supply username and POST it
unless ($np->mech->form_with_fields('userId')) {
    my $msg = "Response to login form GET did not contain user ID form - ". $np->mech->uri . " : ". $np->mech->response->status_line;
    log_debug_info($np->mech->response, $msg);
    $np->nagios_exit(CRITICAL, $msg);
}
$np->submit_form( with_fields => { 'userId' => $np->opts->username },
                  button      => 'signin',
                );
if (!$np->mech->success) {
    my $msg = "Can't submit username - ". $np->mech->uri . " : ". $np->mech->response->status_line;
    log_debug_info($np->mech->response, $msg);
    $np->nagios_exit(CRITICAL, $msg);
}
$np->add_perfdata(
  label => "login_post_un",
  uom   => 's',
  value => $df->format_duration(DateTime::HiRes->now(time_zone => $tz) - $start),
);
### That ends up redirecting to the password page


### Supply password and POST
unless ($np->mech->form_with_fields('secretCode')) {
    my $msg = "Response to login form username POST did not contain password form - ". $np->mech->uri . " : ". $np->mech->response->status_line;
    log_debug_info($np->mech->response, $msg);
    $np->nagios_exit(CRITICAL, $msg);
}
$np->submit_form( with_fields => { 'secretCode' => $np->opts->password || $pw },
                  button      => 'signin',
                );
if (!$np->mech->success) {
    my $msg = "Can't submit password - ". $np->mech->uri . " : ". $np->mech->response->status_line;
    log_debug_info($np->mech->response, $msg);
    $np->nagios_exit(CRITICAL, $msg);
}
$np->add_perfdata(
  label => "login_post_pw",
  uom   => 's',
  value => $df->format_duration(DateTime::HiRes->now(time_zone => $tz) - $start),
);

### That redirects to the waiting page
### The waiting page has js that appends a form method to the body via an in-content script
### with: 
### <form method="POST" 
###       action="https://cibng.ibanking-services.com/cib/CEBMainServlet/SingleSignonEAM?auth_nm=CeB&FIORG=149" 
###       id="f" name="f">
###             <input type="hidden" name="authtkn" value="...authtoken_val...">
###             <input type="hidden" name="keytkn" value="...keytoken_val...">
###             <input type="hidden" name="channel_name" value="EAM_CEB">
###             <input type="hidden" name="FIORG" value="149">
###             <input type="hidden" name="FIFID" value="007590657">
### </form>
###
### Called by jquery - $('body').append('...content...');    $('#f').submit();
###
### This script will do that in-memory by duplicating the JS functionality:
### 1) Get the appended content from the decoded_content of the HTTP::Response
# my($appended_content) = $np->content =~ /\$\('body'\)\.append\('(.*?)'/; ### Non-greedy capture of everything within single quotes
### 2) Exit if no form
# if (!$appended_content) {
#    my $msg = "EAM waiting page did not contain CeB SSO redirect form - ". $np->mech->uri . " : ". $np->mech->response->status_line;
#    log_debug_info($np->mech->response, $msg);
#    $np->nagios_exit(CRITICAL, $msg);
# }
### 3) Modify the content of the response 
# my $html = $np->mech->content;
# $html =~ s/(?=<\/body>)/$appended_content/eg; ## Substitute zero-width with a lookahead matching the closing body tag.
### 4) Replace the HTML source for the mech 'current page'
# $np->mech->update_html($html);
### 5) Submit the appended form
$np->submit_form( form_name => 'f' );
if (!$np->mech->success) {
    my $msg = "Can't submit waiting page redirect from EAM to CeB SSO - ". $np->mech->uri. " : ". $np->mech->response->status_line;
    log_debug_info($np->mech->response, $msg);
    $np->nagios_exit(CRITICAL, $msg);
}

### That redirects to a pager with the sole contents:
### <body onload="window.location.replace('PostLogin');"></body>
### GET it.
$np->get('https://' . $np->opts->host . '/cib/CEBMainServlet/PostLogin');
if (!$np->mech->success) {
    my $msg = "Can't get PostLogin page - ". $np->mech->uri. " : ". $np->mech->response->status_line;
    log_debug_info($np->mech->response, $msg);
    $np->nagios_exit(CRITICAL, $msg);
}
$np->add_perfdata(
  label => "login_postlogin",
  uom   => 's',
  value => $df->format_duration(DateTime::HiRes->now(time_zone => $tz) - $start),
);

### That sends the UA to the Splash redirect; submit it
unless ($np->mech->form_name('frmRedirect')) {
    my $msg = "Response to PostLogin servlet GET did not contain splashpage redirect form - ". $np->mech->uri . " : ". $np->mech->response->status_line;
    log_debug_info($np->mech->response, $msg);
    $np->nagios_exit(CRITICAL, $msg);
}
$np->submit_form( form_name => 'frmRedirect' );
if (!$np->mech->success) {
    my $msg = "Can't submit splash page redirect - ". $np->mech->uri. " : ". $np->mech->response->status_line;
    log_debug_info($np->mech->response, $msg);
    $np->nagios_exit(CRITICAL, $msg);
}

### That sends the UA to the AccountOverview redirect; submit it
unless ($np->mech->form_name('frmRedirect')) {
    my $msg = "Response to splashpage servlet GET did not contain AccountOverview redirect form - ". $np->mech->uri . " : ". $np->mech->response->status_line;
    log_debug_info($np->mech->response, $msg);
    $np->nagios_exit(CRITICAL, $msg);
}
$np->submit_form( form_name => 'frmRedirect' );
if (!$np->mech->success) {
    my $msg = "Can't submit AccountOverview page redirect - ". $np->mech->uri. " : ". $np->mech->response->status_line;
    log_debug_info($np->mech->response, $msg);
    $np->nagios_exit(CRITICAL, $msg);
}
$np->add_perfdata(
  label => "login_complete",
  uom   => 's',
  value => $df->format_duration(DateTime::HiRes->now(time_zone => $tz) - $start),
);

#########################################################
### Node modification
#########################################################

if ($np->opts->node) {
    $np->mech->cookie_jar->scan( sub { my ($ver, $key, $val, $path, $domain, @rest) = @_;
                                       if (     $domain eq $np->opts->host
                                            and $path eq '/'
                                            and $key eq 'JSESSIONID'
                                          ) {  ### JSESSIONID key is of form '00006_L3eyQI6lhIXveOcyOs9Xt:181va8aqv'
                                               ### Netscaler uses portion trailing colon to direct traffic to JVM node
                                               ### Re set the cookie with the JVM node we want to handle the session.
                                               my ($sess, $jvm) = split(':', $val);
                                               my $new_val = $sess . ':' . $node_ids{$np->opts->node};
                                               $np->mech->cookie_jar->set_cookie($ver, $key, $new_val, $path, $domain, @rest);
                                            }    
                                     });
}

#########################################################
### Test servlet loading. Logout one is always last.  ###
#########################################################

### servlet TxnSearch - submit 60 days - IDS transaction timeframe
### FinanceWorks? - time to https://financeworks.intuit.com/quickenweb/pages/main/home.jsf

my @servlets = (qw|AccountOverview AccountActivity DepositAccountOpen 
                    DownloadTxns StatementList BillPaymentEnroll 
                    XferInternalMergeAddNew CustomerServiceLaunch
                   |, 'Logout');
my $serv_count = 0;
for my $servlet (@servlets) {
    my $start = DateTime::HiRes->now( time_zone => $tz );
    $np->mech->get( "https://".$np->opts->host."/cib/CEBMainServlet/$servlet" );
    my $value;
    if (!$np->mech->success) {
        #say $np->mech->content;
        $np->add_message( CRITICAL, "Can't GET $servlet - ". $np->mech->uri. " : ". $np->mech->response->status_line);
        $value = 999;
    }
    else {
        $serv_count++;
        $value = $df->format_duration(DateTime::HiRes->now(time_zone => $tz) - $start);
    }
    ### Add the response time as perfdata
    $np->add_perfdata(
      label => lc($servlet) . '_get',
      uom   => 's',
      value => $value,
    );
    ### Add the response size as perfdata
    {
        use bytes;
        $np->add_perfdata(
          label => lc($servlet) . '_size',
          uom   => 'KB',
          value => sprintf( '%.2f', length($np->content) / 1024),
        );
    }
}




#########################################################
### Exit
#########################################################

my $tot_time = DateTime::HiRes->now(time_zone => $tz) - $start;
$np->add_perfdata(
  label => 'time',
  uom   => 's',
  value => $df->format_duration($tot_time),
);

if ($tot_time->seconds >= $np->opts->warning) {
    $np->add_message( WARNING,
                      "CeB took " . $df->format_duration($tot_time) . "s to perform transaction suite."
                    );
}
if ($tot_time->seconds >= $np->opts->critical) {
    $np->add_message( CRITICAL,
                      "CeB took " . $df->format_duration($tot_time) . "s to perform transaction suite."
                    );
}

$np->add_message( OK,
                  "CeB responsive. $serv_count/".scalar @servlets." servlets loaded."
                );
   

$np->nagios_exit( $np->check_messages );

sub log_debug_info {
    my ($response, $message) = @_;
    
    ### Ensure a HTTP response was passed
    unless( blessed($response) and $response->isa('HTTP::Response') )  {
        return;
    }
    
    if (!defined $message) {
        $message = '';
    }
    
    ### Open log for append
    open (my $log, '>>', '/fras/var/log/check_http_ceb_login.debug') or return;
    #open (my $log, '>>', 'C:\Users\LC31387\Documents\Code\pl\oneoff\ceb_login\check_http_ceb_login.debug') or return;
    
    ### Create log line & write it to log
    eval {
        my $time = DateTime->now(time_zone => 'America/Chicago');
        my $req_string = $response->request->as_string;
        my $res_string = $response->status_line . "\n" . $response->headers->as_string . $response->decoded_content;
        my $log_line = <<"EOF";
=======================================================================
$time: check_http_ceb_login.pl debug information
Error: $message
Request:
$req_string
Response:
$res_string
EOF
        print $log $log_line;
    };
    
    return;
}
