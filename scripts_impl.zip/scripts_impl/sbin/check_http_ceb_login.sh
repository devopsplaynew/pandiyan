#!/usr/bin/ksh
#
# check_http_ceb_login - Launcher harness script for Sitescope to run check_http_ceb_login.pl
#
# History:
# Date        ID         Email                  Notes
# 2014/01/23  LC31387    matthew.c.rose@        Initial script
# 2014/02/14  LC31387    matthew.c.rose@        Updated to run perl script from /home/sitescop/scripts

### ENVIORNMENT DECLARATION
LD_LIBRARY_PATH="/usr/local/ssl/lib" # Required for LWP::protocol::https
SCRIPTDIR="/home/sitescop/scripts"
SCRIPTNAME="check_http_ceb_login.pl"

### MAIN  
COMMAND="${SCRIPTDIR}/${SCRIPTNAME} $*"

output=`$COMMAND`
exitcode=$?

echo $output
exit $exitcode

