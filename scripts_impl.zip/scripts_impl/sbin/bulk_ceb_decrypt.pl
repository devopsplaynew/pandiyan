#!/fras/perl/bin/perl

use Path::Class;

my @files = map {file($_)} @ARGV;

for my $file (@files) {
    my $newfile = file($file->stringify =~ s/\.enc$//r); 
    my $file_abs = $file->absolute->stringify;
    my $newfile_abs = $newfile->absolute->stringify;
    `/cib/datasecurity/bin/voltagecl -a access -e prod -m file -w /opt/security/cib/voltage/voltage_credentials.properties   -ts /opt/security/cib/voltage/trustStore -y CeB_Standard -i $file_abs -o $newfile_abs` 
}
