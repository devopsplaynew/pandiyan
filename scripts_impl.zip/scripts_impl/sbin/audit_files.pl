#!/fras/perl/bin/perl

=head1 NAME

audit_files.pl - Creates a CSV of file statistics for given directory.

=head1 SYNOPSIS

audit_files.pl [options] 

 Options:
   --path=DIR         -p     Path to scan
   --output=FILE      -o     Output file path
   --time_zone=STRING        Time zone of output timestamps
   --help             -h -?  Usage

=head1 OPTIONS

=over 12

=item B<--path> 

The path to scan. Required. Multiple paths can be scanned by providing multiple arguments.

=item B<--output> 

The output file name to write. If not provided, the CSV will be generated to stdout.

=item B<--time_zone> 

The Olson DB time zone name (i.e. 'America/Chicago') to output the last modified timestamps as. If not provided, defaults to the local time zone.

=back 


=head1 DESCRIPTION 

B<audit_files.pl> will scan a directory, recursing into child directories, and ceate a CSV of file statistics for all contents of the provided paths. This CSV will contain: hostname, filename, abs path, uid, gid, modify time, size (bytes), md5 hash of contents.



=cut


use strict;
use warnings;
use 5.014;

use autodie;
use Getopt::Long;
use Pod::Usage;
use Path::Class;
use Text::CSV::Slurp;
use Digest::MD5;
use Data::Printer;
use DateTime;
use Sys::Hostname;

my $opts = { path => [],
             out_fh => *STDOUT,
             tz => 'local',
           };
           
GetOptions( 'help|?'            => \$opts->{help},
            'output|o=s'        => \$opts->{output},
            'path|p=s@'         => \$opts->{path},
            'debug|d'           => \$opts->{debug},
            'time_zone'         => \$opts->{tz},
          ) or pod2usage(0);
           
pod2usage(1) if $opts->{help};

@{$opts->{path}} or pod2usage(0);
          
          

if ($opts->{output}) {
    $opts->{out_fh} = file($opts->output)->openw;
}

my $tz = DateTime::TimeZone->new( name => $opts->{tz} );

my $results = scan_paths(map {dir($_)} @{$opts->{path}});
spew_data($results, $opts->{out_fh});


sub spew_data {
    my ($data, $fh) = @_;
    
    my $csv = Text::CSV::Slurp->create( input => $data, 
                                        field_order => [qw/ host filename absolute uid gid mtime size md5/],
                                      );             
    print $fh $csv;
}

sub scan_paths {
    my (@paths) = @_;  
    
    my $data;
    for my $path (@paths) {
        $path->recurse(callback => sub { 
                        my $file = shift;
                        if (!$file->is_dir and $file->basename ne '.harvest.sig') {
                            push @$data, file_info($file);
                        }
                    } );
    }
    
    return $data;
}

sub file_info {
    my ($file) = @_;
    
    ### call stat()
    my $stat = $file->stat;
    
    ### Hash the file
    my $ctx = Digest::MD5->new;
    $ctx->addfile($file->openr());
    my $hash = $ctx->b64digest;
    
    return { host => hostname(),
             absolute => $file->absolute->stringify,
             filename => $file->basename,
             uid => (getpwuid($stat->uid))[0],
             gid => (getgrgid($stat->gid))[0],
             mtime => DateTime->from_epoch( epoch => $stat->mtime, time_zone => $tz)->datetime,
             size => $stat->size,
             md5 => $hash,
           };
}



