#!/fras/perl/bin/perl

=head1 NAME

cebeiixmlfix - fix invalid characters in EII XML inputs

=head1 SYNOPSIS

cebeiixmlfix.pl --file=filetocorrect

 Options:
   --file=filename      -f      File to fix
   --backup=filename    -o      Backup filename 
   --help               -h -?   Usage
   --logconf            -l      Log4j-style log config
   
=head1 OPTIONS

=over 12

=item B<--file>

File to correct

=back

=item B<--backup>

Location to backup 

=item B<--logconf> 

Location of a log4j-style configuration file defining logging 
configuation. 

Default: '/fras/perfdata/bin/logging.conf' 

=back

12F_EIIActivityLog_06072017_01.xml:18441: parser error : PCDATA invalid Char value 2
774_EIIActivityLog_06032017_01.xml:13293: parser error : PCDATA invalid Char value 25
774_EIIActivityLog_06032017_01.xml:20277: parser error : PCDATA invalid Char value 19
/cib/eii/data/160_EIIActivityLog_05312017_01.xml:1989: parser error : PCDATA invalid Char value 16
774_EIIActivityLog_05252017_01.xml:38943: parser error : PCDATA invalid Char value 3

cibadmin@p01jbapp24 [/home/cibadmin]
# head -3 /fras/tmp/373_EIIActivityLog_06142017_01.xml
<?xml version = "1.0" encoding="UTF-8"?>
<logRecordSummary>
  <logRecord>

  
https://en.wikipedia.org/wiki/Valid_characters_in_XML  
  
  XML 1.0

Unicode code points in the following ranges are valid in XML 1.0 documents:[1]

    U+0009, U+000A, U+000D: these are the only C0 controls accepted in XML 1.0;
    U+0020–U+D7FF, U+E000–U+FFFD: this excludes some (not all) non-characters in the BMP (all surrogates, U+FFFE and U+FFFF are forbidden);
    U+10000–U+10FFFF: this includes all code points in supplementary planes, including non-characters.

The preceding code points ranges contain the following controls which are only valid in certain contexts in XML 1.0 documents, and whose usage is restricted and highly discouraged:

    U+007F–U+0084, U+0086–U+009F: this includes a C0 control character and all but one C1 control.

    
    09 - tab
    0a - lf
    0d - cr

=cut

use strict;
use warnings;

use 5.014;

use Data::Printer;
use Getopt::Long;
use Path::Class;
use Pod::Usage;
use Log::Log4perl qw/:easy/;
use FindBin;

###########################
### Init
###########################

### Option parsing
my $opts = { debug              => 0,
             logconf => '/fras/perfdata/bin/logging.conf',
           };
           

GetOptions ( 'help|?'               => \$opts->{help},
             'file=s'               => \$opts->{inputfile},
             'backup=s'             => \$opts->{copyfile},
             'logconf|l=s'          => \$opts->{logconf},
             'verbose|v+'           => \$opts->{debug},  ### debug levels - 0 = off (default), 1 = error, 2 = warn, 3 = info, 4 = debug.
                                                        ### Ignored if a logconf is provided.
           )
  or pod2usage(0);

pod2usage(1) if $opts->{help};

# Validate input file exists 
-e $opts->{inputfile} or pod2usage(0);

#inflate to Path::Class::file
$opts->{inputfile} = Path::Class::File->new($opts->{inputfile}); 
if ($opts->{outputfile}) {
    $opts->{outputfile} = Path::Class::File->new($opts->{outputfile}); 
}

### Initialize logging subsystem
init_logger();

logger()->debug(p(@ARGV));
logger()->debug(p($opts));

###########################
### Main app
###########################

# Replace all control chars except:
# U+0009, U+000A, U+000D: these are the only C0 controls accepted in XML 1.0;

my $contents =  $opts->{inputfile}->slurp();
if ($opts->{outputfile}) {
    logger()->info("$opts->{inputfile} backed up to $opts->{inputfile}.");
    $opts->{outputfile}->spew($contents);
}
my $count = $contents =~ s/([\N{U+00}-\N{U+08}\N{U+0b}\N{U+0c}\N{U+0e}-\N{U+1f}])/"%".sprintf("%02d", ord($1))/ge;
if ($count) {
    logger()->info("$opts->{inputfile} corrected, $count substitution(s) made.");
    $opts->{inputfile}->spew($contents);
}
else {
    logger()->info("$opts->{inputfile} reviewed, no substitutions needed.");
}




### Initialize logging system
sub init_logger {
    ### If a log configuration is found, and debug was not set, use it
    if (        $opts->{logconf} 
         and -e $opts->{logconf}
         and  ! $opts->{debug}
       ) {
        Log::Log4perl->init($opts->{logconf});
    }
    ### Otherwise fall through to easy_init a screen logger based on the verboseness level
    ### Logging off if no config found and no verboseness set
    else {
        my ($min, $max) = ( 0, 4 );
        my %levels;
        @levels{$min .. $max} = ( $OFF, $ERROR, $WARN, $INFO, $DEBUG );
        my $log_level = $opts->{debug};
        if ($log_level < $min) {
            $log_level = $min;
        }
        elsif ($log_level > $max) {
            $log_level = $max;
        }
        Log::Log4perl->easy_init($levels{$log_level});
    }
}

### Shorthand shim sub to get a logger
### Always returns a Log::Log4perl logger object
sub logger {
    my ($category) = @_;
    if ($category) {
        return Log::Log4perl->get_logger('fis.ebsd.app.ceb_eiixmlfix.' . $category);
    }
    return Log::Log4perl->get_logger('fis.ebsd.app.ceb_eiixmlfix');
}


