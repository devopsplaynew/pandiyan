#!/fras/perl/bin/perl
use strict;
use warnings;
use Data::Printer;

use 5.014;

my $debug = 1;

while (<>) {
    chomp;
    if ( $_ =~ /<--/ ) {
        my ($header, $data) = split /<--/, $_;
        say $header;
        say join "\t", qw/Length Element Value/;
        while ($data) {
            my ($len, $elem, $val, $remainder) = parse_data($data);
            $data = $remainder;
            say join "\t", $len, $elem, $val;
            if ($elem eq '000002') {
                while ($val) {
                    my ($sublen, $subelem, $subval, $subremainder) = parse_data($val);
                    $val = $subremainder;
                    say join "\t", $sublen, $subelem, $subval;
                }
            }        }
    }
    else {
        say $_;
    }
    
}

sub parse_data {
    my ($data) = @_;
    #p($data);
    my($len, $remainder) = unpack ('A5A*', $data);
    $len = $len + 0; ## cast to numeric
    #p($len);
    #p($remainder);
    my $vallen = $len - 11; ## 6 chars for element, 5 for length, remainder is value
    my ($element, $value, $rest) = unpack ('A6A' . $vallen . 'A*', $remainder);
    return ($len, $element, $value, $rest);
}
