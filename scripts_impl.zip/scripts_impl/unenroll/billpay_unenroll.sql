set verify off
set serveroutput on size 300000 format wrapped
set feedback off
set linesize 4500
set trimout on
set tab off

declare
  v_userid varchar2(32):='USERID1';
  v_fiorg  varchar2(3):='BANKNO1';
  vacc1 varchar2(20):='';
  v_tkt varchar2(15):='Ticket';
  v_errmsg varchar2(2000);
  v_custinfo varchar2(2000);
  v_date varchar2(40):=substr(systimestamp,1,18);
  v_row number;
  status1 varchar2(2);
  status2 varchar2(2);
  status3 varchar2(2);
  v_cnt number;
v_msg varchar2(400);

begin
v_msg :='<br><a href="https://cases.fnfis.com/wfForms/wfMain.aspx?CaseID='||v_tkt||'">'||v_tkt||'</a>';

select count(*) into v_cnt from ceb000.customeruser where userid = v_userid and bankuid = (select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg);
if v_cnt=0
then
dbms_output.put_line(v_msg||': No_Data available to Billpay Unenroll for the userid - '||v_userid||'. please check user input.');
end if;

  begin

  dbms_output.put_line(v_date||' Unenrollement started for customer table');

    update ceb000.customer
      set updateinfo = to_char(sysdate, 'dd-mon-yy hh24:mi:ss'),billpaysubscriberid = null,billpaymemberid= null, enrolledforbillpay  = 'N'
    where custid in (select custid
        from ceb000.customeruser
       where userid = v_userid
         and bankuid = (select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg));

  v_row:=sql%rowcount;
        dbms_output.put_line(v_date||' No Of Rows affected - '||v_row);
        
		if v_row = 0 then
      status1:='0';
        else
      status1:='1';
        end if;
  dbms_output.put_line('Unenrollment status for customer - '||status1);

    exception
    when no_data_found then
    dbms_output.put_line('No Data available to Billpay Unenroll in customer table for the userid - '||v_userid);
    when others then
    v_errmsg := substr(sqlerrm,1,100);
    dbms_output.put_line('error while update in customer table for the userid - '||v_userid||'-'||v_errmsg);
  end;

if vacc1 is null
then

  begin
--  dbms_output.put_line('');

  dbms_output.put_line(v_date||' Unenrollement started for CustomerAccounts table');

    update ceb000.customeraccounts set bpsvcstatus='AVAIL',bpregisterid = null, billingaccountflag= null
    where alphacustid in (select custid from ceb000.customeruser where userid =v_userid)
    and bankuid in (select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg);

  v_row:=sql%rowcount;
        dbms_output.put_line(v_date||' No Of Rows affected - '||v_row);

        if v_row = 0 then
      status2:='0';
        else
      status2:='1';
        end if;
   dbms_output.put_line('Unenrollment status for CustomerAccounts - '||status2);

    exception
    when no_data_found then
    dbms_output.put_line('No Data available to Billpay Unenroll in CustomerAccounts table for the userid - '||v_userid);
    when others then
    v_errmsg := substr(sqlerrm,1,100);
    dbms_output.put_line('error while update in CustomerAccounts table for the userid - '||v_userid||'-'||v_errmsg);
  end;

  begin
 -- dbms_output.put_line('');

  dbms_output.put_line(v_date||' Unenrollement started for Account table');

     update ceb000.account set updateinfo=to_char(sysdate,'dd-mon-yy hh24:mi:ss'),
    bpsrc = 'N' where custid in (select custid from ceb000.customeruser where userid =v_userid)
    and bankuid in (select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg);

  v_row:=sql%rowcount;
        dbms_output.put_line(v_date||' No Of Rows affected - '||v_row);

        if v_row = 0 then
      status3:='0';
        else
      status3:='1';
        end if;
   dbms_output.put_line('Unenrollment status for Account - '||status3);

    exception
    when no_data_found then
    dbms_output.put_line('No Data available to Billpay Unenroll in Account table for the userid - '||v_userid);
    when others then
    v_errmsg := substr(sqlerrm,1,100);
    dbms_output.put_line('error while update in Account table for the userid - '||v_userid||'-'||v_errmsg);
  end;

else

 begin
  --dbms_output.put_line('');

  dbms_output.put_line(v_date||' Unenrollement started for CustomerAccounts table');

    update ceb000.customeraccounts set bpsvcstatus='AVAIL',bpregisterid = null, billingaccountflag= null
    where acctuid in(select acctuid from ceb000.account where custid in (select custid from ceb000.customeruser where userid =v_userid
    and bankuid in (select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg)) and acctnum=vacc1);

  v_row:=sql%rowcount;
        dbms_output.put_line(v_date||' No Of Rows affected - '||v_row);

        if v_row = 0 then
      status2:='0';
        else
      status2:='1';
        end if;
   dbms_output.put_line('Unenrollment status for CustomerAccounts - '||status2);

    exception
    when no_data_found then
    dbms_output.put_line('No Data available to Billpay Unenroll in CustomerAccounts table for the userid - '||v_userid);
    when others then
    v_errmsg := substr(sqlerrm,1,100);
    dbms_output.put_line('error while update in CustomerAccounts table for the userid - '||v_userid||'-'||v_errmsg);
  end;

  begin
  --dbms_output.put_line('');

  dbms_output.put_line(v_date||' Unenrollement started for Account table');

     update ceb000.account set updateinfo=to_char(sysdate,'dd-mon-yy hh24:mi:ss'),
    bpsrc = 'N' where custid in (select custid from ceb000.customeruser where userid =v_userid)
    and bankuid in (select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg) and acctnum=vacc1 ;

  v_row:=sql%rowcount;
        dbms_output.put_line(v_date||' No Of Rows affected - '||v_row);

        if v_row = 0 then
      status3:='0';
        else
      status3:='1';
        end if;
   dbms_output.put_line('Unenrollment status for Account - '||status3);

    exception
    when no_data_found then
    dbms_output.put_line('No Data available to Billpay Unenroll in Account table for the userid - '||v_userid);
    when others then
    v_errmsg := substr(sqlerrm,1,100);
    dbms_output.put_line('error while update in Account table for the userid - '||v_userid||'-'||v_errmsg);
  end;
  
end if;
 --dbms_output.put_line('');
 dbms_output.put_line('************************************************************************');
  if (status1>0) then
  dbms_output.put_line(v_msg||': Billpay Unenrollment Successfull for User - '||v_userid);
  else
  dbms_output.put_line(v_msg||': Billpay Unenrollment Failed for User - '||v_userid||'. please check user input.');
  end if;
   dbms_output.put_line('************************************************************************');

 end;

/

