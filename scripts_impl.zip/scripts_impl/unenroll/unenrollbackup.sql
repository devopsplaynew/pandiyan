set verify off
SET SERVEROUTPUT ON SIZE 300000 FORMAT WRAPPED
set feedback off
set linesize 4500
set trimout on
set tab off

declare
  r_customer ceb000.account%rowtype;
  r_cust ceb000.customeraccountservices%rowtype;
  vusrid varchar2(32):='USERID1';
  forg varchar2(3):='BANKNO1';
  v_errmsg varchar2(2000);
  v_custinfo varchar2(2000);
  v_date varchar2(40):=substr(systimestamp,1,18);
  v_row number;
  status1 varchar2(2);
  status2 varchar2(2);
  status3 varchar2(2);
  status4 varchar2(2);
  status5 varchar2(2);
  status6 varchar2(2);
  
begin
  dbms_output.put_line('************************************************************************');

  begin
  dbms_output.put_line(v_date||' backup started for customerservices table');
  dbms_output.put_line('customerservices table:');

   for l_counter in (select distinct serviceid from ceb000.customerservices  where custid in
  (select custid from ceb000.customeruser where userid=vusrid and bankuid =(select bankuid from ceb000.ofxbankinfo where fi_org =forg)))
  loop
  select deactivation_ts||'-'||update_ts||'-'||servicedata_n01||'-'||servicedata_n02||'-'||servicedata_s01||'-'||servicedata_s02||'-'||servicedata_t01||'-'||
  servicedata_t02||'-'||custsvcuid||'-'||custid||'-'||serviceid||'-'||available||'-'||status||'-'||status_reason||'-'||activation_ts  
  into v_custinfo from ceb000.customerservices
  where custid in (select custid from ceb000.customeruser where userid =vusrid and bankuid =(select bankuid from ceb000.ofxbankinfo where fi_org =forg) )
  and serviceid=l_counter.serviceid;
  dbms_output.put_line(v_date||': '||v_custinfo);
  v_row:=nvl(sql%rowcount,0);
  v_row:=v_row+1;
  end loop;
  if v_row >0 then
  status1:='1';
  else
  status1:='0';
  end if;
  end;


  begin
    dbms_output.put_line(v_date||' backup started for customeraccountservices table');
    dbms_output.put_line('customeraccountservices table:');

    for l_counter in (select distinct acctuid from ceb000.customeraccountservices where alphacustid in (select custid from ceb000.customeruser where userid =vusrid) and bankuid in (select bankuid from ceb000.ofxbankinfo where fi_org = forg) and serviceid='PPLPAY')
  
    loop
    select servicedata_t01||'-'||servicedata_s02||'-'||servicedata_s01||'-'||servicedata_n02||'-'||servicedata_n01||'-'||update_ts||'-'||deactivation_ts||'-'||activation_ts||'-'||status_reason||'-'||status||'-'||available||'-'||serviceid||'-'||acctuid||'-'||alphacustid||'-'||servicedata_t02||'-'||custacctsvcuid||'-'||bankuid 
    into v_custinfo from ceb000.customeraccountservices
    where alphacustid in
    (select custid from ceb000.customeruser where userid =vusrid)
    and bankuid in
    (select bankuid from ceb000.ofxbankinfo where fi_org = forg) and acctuid=l_counter.acctuid and serviceid='PPLPAY';
    dbms_output.put_line(v_date||': '||v_custinfo);
      v_row:=nvl(sql%rowcount,0);
  v_row:=v_row+1;
  end loop;
  if v_row >0 then
  status2:='1';
  else
  status2:='0';
  end if;
  end;
    
  begin
  dbms_output.put_line(v_date||' backup started for customeraccounts table');
    dbms_output.put_line('customeraccounts table:');

     for l_counter in (select distinct alphacustid,acctuid from ceb000.customeraccounts where alphacustid in (select custid from ceb000.customeruser where userid =vusrid) and bankuid in (select bankuid from ceb000.ofxbankinfo where fi_org = forg))

    loop
    select bpregisterid||'-'||itemid||'-'||holder||'-'||reason||'-'||alternatedescription||'-'||bankreason||'-'||bpreason||'-'||bpsvcstatus||'-'||banksvcstatus||'-'||alphacustid||'-'||bankuid||'-'||acctuid||'-'||b2k_cardtype||'-'||cardprimaryowner||'-'||remotedepositcapture_ind||'-'||acctitemid||'-'||visibleflag||'-'||billingaccountflag||'-'||espsvcstatus||'-'||external_acct_id||'-'||estatement_consent||'-'||memberpayeeid||'-'||ordering  into v_custinfo from ceb000.customeraccounts
    where alphacustid in
    (select custid from ceb000.customeruser where userid =vusrid)
    and bankuid in
    (select bankuid from ceb000.ofxbankinfo where fi_org = forg) and acctuid=l_counter.acctuid and alphacustid=l_counter.alphacustid;
    dbms_output.put_line(v_date||': '||v_custinfo);
  v_row:=nvl(sql%rowcount,0);
  v_row:=v_row+1;
    end loop;
  if v_row >0 then
    status3:='1';
else
  status3:='0';
end if;
  end;
  
  begin
    dbms_output.put_line(v_date||' backup started for accounts table');
    dbms_output.put_line('accounts table:');

  for l_counter in (select distinct acctuid from ceb000.account where custid in (select custid from ceb000.customeruser where userid =vusrid) and bankuid in (select bankuid from ceb000.ofxbankinfo where fi_org = forg))

  loop
    select custid||'-'||acctnum||'-'||accounttype||'-'||accountname||'-'||currencycode||'-'||banksideid||'-'||addr1||'-'||addr2||'-'||addr3||'-'||city||'-'||stateprov||'-'||postalcode||'-'||note_type||'-'||bill_type||'-'||loan_post_tran_status||'-'||protected||'-'||funding_account_date||'-'||reg_pay_amt||'-'||past_due_amt||'-'||total_due_loan_amt||'-'||current_escrow_bal||'-'||current_fee_bal||'-'||current_escrow_acct_ind||'-'||loan_past_due_days||'-'||validated||'-'||update_ts||'-'||avail_balamt||'-'||avail_dtasof||'-'||delta_balamt||'-'||delta_dtasof||'-'||mktginfo||'-'||suptxdl||'-'||xfersrc||'-'||xferdest||'-'||bpsrc||'-'||description||'-'||phone||'-'||dtacctup||'-'||dtcreated||'-'||bankid||'-'||state||'-'||statement_cycle_code||'-'||internal_accttype1||'-'||updateinfo||'-'||deleted||'-'||deletedate||'-'||external||'-'||dataretentionscd||'-'||dataretentionspd||'-'||dataretentiondpd||'-'||dataretentiondcd||'-'||sweepaccount||'-'||sellingbankuid||'-'||ledger_balamt||'-'||ledger_dtasof||'-'||internal_accttype2||'-'||internal_accttype3||'-'||internal_accttype4||'-'||externalacct||'-'||costcenter||'-'||cctransbanknum||'-'||current_balamt||'-'||current_dtasof||'-'||paperf||'-'||electf||'-'||comb_acct_ind||'-'||espsrc||'-'||card||'-'||prastatus||'-'||praindicator||'-'||misc_acct_info1||'-'||aggr_acct_type||'-'||defini_ind||'-'||product_type_code||'-'||transvolavg||'-'||transvolevaldate||'-'||transvoloverride||'-'||accountsubtype||'-'||spectr||'-'||openind||'-'||dormant||'-'||genextnum||'-'||fullacctnum||'-'||subacctnum||'-'||category||'-'||paidind||'-'||subacctstatus||'-'||loan_send_nobill_ind||'-'||acct_bill_ind||'-'||accessible_balamt||'-'||accessible_dtasof||'-'||todays_activity_balamt||'-'||holds_balamt||'-'||float_balamt||'-'||online_float_balamt||'-'||pra_balamt||'-'||esp_balamt||'-'||related_avail_balamt||'-'||overdraft_protection||'-'||cardprefixind||'-'||cardsrcacctnum||'-'||cardforeignaddrind||'-'||acctuid||'-'||bankuid  into v_custinfo from ceb000.account
    where custid in
    (select custid from ceb000.customeruser where userid =vusrid)
    and bankuid in
    (select bankuid from ceb000.ofxbankinfo where fi_org = forg) and acctuid=l_counter.acctuid;
  dbms_output.put_line(v_date||': '||v_custinfo);
    v_row:=nvl(sql%rowcount,0);
    v_row:=v_row+1;
  end loop;
    if v_row >0 then
    status4:='1';
  else
    status4:='0';
  end if;
  end;

  begin
  dbms_output.put_line(v_date||' backup started for customer table');
  dbms_output.put_line('customer table:');

   for l_counter in (select distinct custid from ceb000.customer  where custid in
  (select custid from ceb000.customeruser where userid=vusrid and bankuid =(select bankuid from ceb000.ofxbankinfo where fi_org =forg)))
  loop
  select ENROLLEDFORBILLPAY||'-'||BILLPAYSUBSCRIBERID||'-'||CIBCUSTOMERTYPE||'-'||ESTATEMENT_CONSENT||'-'||TRHST||'-'||TRHSTDATE||'-'||TRHSTUNENROLLDATE||'-'||TRHSTNUMBER||'-'||BRANCH||'-'||MISCDEMO1||'-'||CUSTNAME||'-'||PRESENTMENT_STATUS||'-'||LWRCASE_NAME||'-'||EXTXFERACTIVATED||'-'||EMAIL2||'-'||PRICINGPLANUID||'-'||CUSTPROFUID||'-'||OLDUSERPASS||'-'||TEMPPASS_DROP2015R3||'-'||DTEXPIRE||'-'||LOCKREASON||'-'||LASTPWDRESET||'-'||PPASSIGNEDDATE||'-'||BILLPAYMEMBERID||'-'||ESIGNINDICATOR||'-'||INITIATOR||'-'||FIRSTNAME||'-'||EMAIL3||'-'||PENDING_OWNER_VERIFY_REQUESTS||'-'||STMT_ACCT_LVL_TS||'-'||ESIGNDATE||'-'||SEGMENT_ID||'-'||CISNUMBER||'-'||UPDATE_TS||'-'||TAXIDIND||'-'||CUSTID||'-'||BANKUID||'-'||ALPHACUSTID||'-'||NAME||'-'||CURRENCYCODE||'-'||COUNTRYCODE||'-'||SECURITYOFFICER||'-'||ACCOUNTOFFICER||'-'||PHONENUM||'-'||TIMEZONEID||'-'||LANGABBREV||'-'||EMAIL||'-'||ADDR1||'-'||ADDR2||'-'||ADDR3||'-'||CITY||'-'||STATEPROV||'-'||POSTALCODE||'-'||ACTIVE||'-'||DATEACTIVE||'-'||PASSWORD_DROP2015R3||'-'||PWDCHANGE||'-'||PWDPENDINGRESET||'-'||UPDATEINFO||'-'||DELETED||'-'||DELETEDATE||'-'||BILLING_ACCOUNT||'-'||PWDRETENTION||'-'||BILLINGACCOUNTBANK||'-'||BILLINGGROUP||'-'||CUSTTYPE||'-'||BILLINGINFO1||'-'||BILLINGINFO2||'-'||BILLINGINFO3||'-'||DTCREATED||'-'||MIDDLENAME||'-'||EVEPHONENUM||'-'||PREASSIGNEDUSERID||'-'||TAXID||'-'||SECURITYNAME||'-'||DATEBIRTH||'-'||BUSINESSNAME||'-'||CANBILLPAY  
  into v_custinfo from ceb000.customer
  where custid in (select custid from ceb000.customeruser where userid =vusrid and bankuid =(select bankuid from ceb000.ofxbankinfo where fi_org =forg) )
  and custid=l_counter.custid;
  dbms_output.put_line(v_date||': '||v_custinfo);
  v_row:=nvl(sql%rowcount,0);
  v_row:=v_row+1;
  end loop;
  if v_row >0 then
  status5:='1';
  else
  status5:='0';
  end if;
  end;
  
  begin
  dbms_output.put_line(v_date||' backup started for customeruser table');
  dbms_output.put_line('customeruser table:');

   for l_counter in (select custid from ceb000.customeruser where userid=vusrid and bankuid =(select bankuid from ceb000.ofxbankinfo where fi_org =forg))
  loop
  select DELETED||'-'||DELETEDATE||'-'||PWDRETENTION||'-'||PWDCHANGE||'-'||NUMPUNCT||'-'||CURRENCYFORMAT||'-'||NUMLOGINATTEMPTS||'-'||AUTHORIZEDCALLER||'-'||MOTHERMAIDENNAME||'-'||DATEOFBIRTH||'-'||EMPLOYER||'-'||BANKUID||'-'||ENROLLEDFORFPS||'-'||ENROLLEDFORFPSDATE||'-'||FPSSTATUS||'-'||FPSFAILEDATTEMPTS||'-'||FPSLOCKDATE||'-'||FPS_ENROLL_GRACE_PERIOD||'-'||TRANLINESPERPAGE||'-'||AUTH_SETUP_STATUS||'-'||AUTH_SETUP_DATE||'-'||AUTH_CHALLENGE_QUESTION||'-'||AUTH_CHALLENGE_ANSWER||'-'||AUTHTYPE||'-'||ALIASID||'-'||ESTATEMENT_STATUS||'-'||PREFERRED_LOCALE||'-'||REMOTEDEPOSITCAPTURE_IND||'-'||CHG_USERID_COUNT||'-'||CHG_USERID_UPDATED_TS||'-'||PWD_ALGORITHM||'-'||SALT||'-'||OLD_PWD_ALGORITHM||'-'||OLD_SALT||'-'||UPDATE_TS||'-'||LASTLOGINATTEMPT||'-'||USERTYPE||'-'||DTCREATED||'-'||OLDUSERPASS||'-'||TEMPPASS_DROP2015R3||'-'||DTEXPIRE||'-'||LOCKED||'-'||LOCKREASON||'-'||FAILEDATTEMPTS||'-'||LOGINS||'-'||LASTLOGIN||'-'||ISOPERATOR||'-'||CUSTUSERUID||'-'||USERID||'-'||NAME||'-'||CUSTID||'-'||COUNTRYCODE||'-'||LANGABBREV||'-'||TIMEZONEID||'-'||PHONENUM||'-'||EMAIL||'-'||SECURE||'-'||ADDR1||'-'||ADDR2||'-'||ADDR3||'-'||CITY||'-'||STATEPROV||'-'||POSTALCODE||'-'||STARTTIME||'-'||STOPTIME||'-'||ACTIVE||'-'||DATEACTIVE||'-'||PASSWORD||'-'||LASTPWDRESET||'-'||PWDPENDINGRESET||'-'||UPDATEINFO
  into v_custinfo from ceb000.customeruser
  where userid =vusrid and bankuid =(select bankuid from ceb000.ofxbankinfo where fi_org =forg)
  and custid=l_counter.custid;
  dbms_output.put_line(v_date||': '||v_custinfo);
  v_row:=nvl(sql%rowcount,0);
  v_row:=v_row+1;
  end loop;
  if v_row >0 then
  status6:='1';
  else
  status6:='0';
  end if;
  end;
  
 dbms_output.put_line('status : success-1 / failed-0');
 dbms_output.put_line('');
 
  dbms_output.put_line('back up status for customerservices - '||status1);
  dbms_output.put_line('back up status for customeraccountservices - '||status2);
  dbms_output.put_line('back up status for customeraccounts - '||status3);
  dbms_output.put_line('back up status for accounts - '||status4);
  dbms_output.put_line('back up status for customer - '||status5);
  dbms_output.put_line('back up status for customeruser - '||status6);

  dbms_output.put_line('************************************************************************');

end;
/
