set verify off
SET SERVEROUTPUT ON SIZE 300000 FORMAT WRAPPED
set feedback off
set linesize 4500
set trimout on
set tab off


declare
   v_userid ceb000.customeruser.userid%type := 'USERID1'; --varchar2
   v_fiorg  ceb000.ofxbankinfo.fi_org%type := 'BANKNO1';  --varchar2
   v_bpmemberid ceb000.customer.billpaymemberid%type := ''; -- number
   v_acctnbr ceb000.account.acctnum%type := 'account1';   --varchar2
   v_testonly char(1) := 'N';

   v_custstr varchar2(400);
   v_acctstr varchar2(400);
   v_cbmem_str varchar2(400);
   v_cbpaym_str varchar2(400);
   v_upd_cust_cnt integer;
   v_upd_acct_cnt integer;
   v_upd_custacct_cnt integer;

   v_bpsvcstatus ceb000.customeraccounts.bpsvcstatus%type; -- varchar2
   v_bpregisterid ceb000.customeraccounts.bpregisterid%type; -- number
   v_acctuid ceb000.customeraccounts.acctuid%type; -- number(12)
   v_billpaymemberid ceb000.customer.billpaymemberid%type;
   v_pmid csp_bp.cbpayment_method.pm_id%type; -- number(12)

   -- cursors
   cursor c1 is
     select a.acctnum||':'|| a.bpsrc||':'|| ca.acctuid||':'|| ca.banksvcstatus||':'|| ca.bpsvcstatus||':'|| ca.alternatedescription||':'||
           ca.bpregisterid||':'|| ca.visibleflag||':'|| ca.billingaccountflag||':'|| ca.holder
     into v_acctstr
     from ceb000.customeraccounts ca,ceb000.account a
    where ca.alphacustid in (   select custid
         from ceb000.customeruser
        where userid = v_userid
          and bankuid = (select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg)  )
      and ca.bankuid in(select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg)
      and ca.acctuid = a.acctuid and a.acctnum = v_acctnbr;

    cursor c2 is
      select a.acctnum||':'|| a.bpsrc||':'|| ca.acctuid||':'|| ca.banksvcstatus||':'|| ca.bpsvcstatus||':'|| ca.alternatedescription||':'||
             ca.bpregisterid||':'|| ca.visibleflag||':'|| ca.billingaccountflag||':'|| ca.holder
       into v_acctstr
       from ceb000.customeraccounts ca,ceb000.account a
      where ca.alphacustid in (   select custid
           from ceb000.customeruser
          where userid = v_userid
            and bankuid = (select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg)  )
        and ca.bankuid in(select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg)
        and ca.acctuid = a.acctuid;

  -------------  FUNCTIONS -------------

  --11/30/09 v0.2 function
  function getCsvFld(in_csv in varchar2, in_fldnbr in integer) return varchar2 is

    INVALID_FLDPOS exception;

    v_foo varchar2(400) := in_csv;
    v_fldpos int := in_fldnbr;
    v_strpos int;
    v_endpos int;
    v_lpos int; -- last position use to compare
    v_val varchar2(20);

  begin

    select
      case
          when v_fldpos > 1 then instr(v_foo, ':', 1, v_fldpos - 1) +1
          else 1
      end "spos", -- delimiter before N field
      instr(v_foo, ':', 1, v_fldpos) "epos",
      instr(v_foo, ':', -1,1) "lpos" -- position of last delimiter
    into v_strpos, v_endpos, v_lpos
    from dual;

    --dbms_output.put_line(v_strpos ||':'|| v_endpos ||':'|| nvl(v_val,'no_val') ||':'|| v_lpos);

    -- check if spos or epos is valid
    if v_strpos > 0 and v_endpos > 0 then
      -- determine the start and end positions
      if v_endpos <= v_lpos then
        --dbms_output.put_line(v_endpos ||'<='|| v_lpos ||':'|| 'OK');

        select
        trim(substr(v_foo, v_strpos, (v_endpos - v_strpos))) -- get value in N field
        into v_val
        from dual;

        if v_val is null or length(v_val) = 0 then
           return null;
        else
           return v_val;
        end if;
        --dbms_output.put_line(v_strpos ||':'|| v_endpos ||':'|| v_val ||':'|| v_lpos);

      else
        dbms_output.put_line('BAD');
      end if;
    else
      -- for last field
      if v_strpos >0 then -- v_endpos = 0 or less?
        select
        trim(substr(v_foo, v_strpos - length(v_foo) -1)) -- substring in reverse
        into v_val
        from dual;

        if v_val is null or length(v_val) = 0 then
           return null;
        else
           return v_val;
        end if;
        --dbms_output.put_line(v_strpos ||':'|| v_endpos ||':'|| v_val ||':'|| v_lpos);
      else
        dbms_output.put_line('REAL BAD');
      end if;

    end if;
  end;

begin

  select custid ||':'||  bankuid ||':'||  name||'/'|| firstname ||':'||  email ||':'||  canbillpay ||':'||  enrolledforbillpay ||':'||  billpaysubscriberid ||':'||  billpaymemberid ||':'||  pricingplanuid ||':'|| taxid ||':'|| custprofuid
    into v_custstr
    from ceb000.customer
   where custid =
   (
     select custid
       from ceb000.customeruser
      where userid = v_userid
        and bankuid = (select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg)
   );


  if v_acctnbr is not null or v_acctnbr <> '' then
    open c1;
    fetch c1 into v_acctstr;
    close c1;

  --TODO: split up this join since customeraccounts may NOT exist but account DOES
  begin
  select ca.bpsvcstatus, ca.bpregisterid, ca.acctuid
   into v_bpsvcstatus, v_bpregisterid, v_acctuid
   from ceb000.customeraccounts ca,ceb000.account a
  where ca.alphacustid in (   select custid
       from ceb000.customeruser
      where userid = v_userid
        and bankuid = (select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg) )
    and ca.bankuid in(select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg)
    and ca.acctuid = a.acctuid and a.acctnum = v_acctnbr;
      exception
        when NO_DATA_FOUND then dbms_output.put_line('No records in account and customeraccounts table for the account '||v_acctnbr);
    when OTHERS then dbms_output.put_line('Error mesaage: Exception occured when extract records in account and customeraccounts table');
  end;
  else
    open c2;
    fetch c2 into v_acctstr;
    close c2;

  end if;

  -- set variable for use in csp_bp queries
  v_billpaymemberid := getCsvFld(v_custstr, 8);

  --select mem_id, br_id, memsta_id, mem_first_name, mem_last_name, mem_create_date, mem_cancel_date from csp_bp.cbmember
  select mem_id||':'|| br_id||':'|| memsta_id||':'|| mem_first_name||':'|| mem_last_name||':'|| mem_create_date||':'|| mem_cancel_date
    into v_cbmem_str
    from csp_bp.cbmember me
   where me.mem_id = v_billpaymemberid;

  begin
    --select pm_id, mem_id, pmtyp_id, pm_acct_no, pm_default, pmsta_id from csp_bp.cbpayment_method
    select pm_id||':'|| mem_id||':'|| pmtyp_id||':'|| pm_acct_no||':'|| pm_default||':'|| pmsta_id
      into v_cbpaym_str
      from csp_bp.cbpayment_method
     where mem_id = v_billpaymemberid
     and pm_acct_no = v_acctnbr
     and pmsta_id = 1;
    v_pmid := getCsvFld(v_cbpaym_str,1);
  exception
    when NO_DATA_FOUND then
      begin
        -- attempt with other PMSTA_ID values
        select pm_id||':'|| mem_id||':'|| pmtyp_id||':'|| pm_acct_no||':'|| pm_default||':'|| pmsta_id
          into v_cbpaym_str
          from csp_bp.cbpayment_method
         where mem_id = v_billpaymemberid
         and pm_acct_no = v_acctnbr
         and (pmsta_id <> 1 or pmsta_id is null);

        v_pmid := getCsvFld(v_cbpaym_str,1);
        dbms_output.put_line('v_pmid =>' || v_pmid);
      exception
        when NO_DATA_FOUND then dbms_output.put_line('No records in csp_bp.cbpayment_method table for the account '||v_acctnbr);
    when OTHERS then dbms_output.put_line('Error mesaage: Exception occured when extract records in csp_bp.cbpayment_method table');
  end;
end;
  if v_acctstr is not null then
    -- 2. UPDATE
    v_acctuid := getCsvFld(v_acctstr, 3);
    v_bpsvcstatus := getCsvFld(v_acctstr,5);
    v_bpregisterid := getCsvFld(v_acctstr,7);


    if
          v_testonly = 'N'

      and v_bpregisterid is null
      and v_pmid is not null
    then

      update ceb000.customeraccounts
        set bpsvcstatus='ACTIVE',
            bpregisterid = v_pmid
      where alphacustid in (   select custid
         from ceb000.customeruser
        where userid = v_userid
          and bankuid = (select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg)  )
        and bankuid in (select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg)
        and acctuid = v_acctuid; --- TODO: MUST RETRIEVE AND VERIFY ACCTUID BASED ON INPUT/QUERY???
        v_upd_custacct_cnt := sql%rowcount;
    else
      -- set pm_id when bpsvcstatus <> ACTIVE and bpregisterid = mem_id (which indicates past auto-close)
      if
            v_testonly = 'N'
        -- and v_bpsvcstatus <> 'ACTIVE' /* IGNORE bpsvcstatus */
        and v_bpregisterid is not null
        and v_pmid is not null
      then
        update ceb000.customeraccounts
          set bpsvcstatus='ACTIVE',
              bpregisterid = v_pmid
        where alphacustid in (   select custid
           from ceb000.customeruser
          where userid = v_userid
            and bankuid = (select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg)  )
          and bankuid in (select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg)
          and acctuid = v_acctuid; --- TODO: MUST RETRIEVE AND VERIFY ACCTUID BASED ON INPUT/QUERY???
          v_upd_custacct_cnt := sql%rowcount;
      else -- handle sync of pm_id for cases when bpregisterid was set to mem_id (workaround to app defect?)
        if    v_testonly = 'N'
          -- and v_bpsvcstatus = 'ACTIVE' /* 01.25.13 IGNORE bpsvcstatus */
          and v_bpregisterid is not null -- usually set to mem_id (app defect?)
          and v_pmid <>  v_bpregisterid  -- relying on cbpayment_method.pm_id
        then
          update ceb000.customeraccounts
             set bpregisterid = v_pmid
           where alphacustid in (   select custid
                 from ceb000.customeruser
                 where userid = v_userid
                 and bankuid = (select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg)  )
             and bankuid in (select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg)
             and acctuid = v_acctuid;
          v_upd_custacct_cnt := sql%rowcount;
        end if;
      end if;
    end if;

    dbms_output.put_line('No of Rows affected :' || v_upd_custacct_cnt);

    -- 3. AFTER UPDATE
    if v_upd_custacct_cnt > 0 then

      select a.acctnum||':'|| a.bpsrc||':'|| ca.acctuid||':'|| ca.banksvcstatus||':'|| ca.bpsvcstatus||':'|| ca.alternatedescription||':'||
             ca.bpregisterid||':'|| ca.visibleflag||':'|| ca.billingaccountflag||':'|| ca.holder
       into v_acctstr
       from ceb000.customeraccounts ca,ceb000.account a
      where ca.alphacustid in (   select custid
           from ceb000.customeruser
          where userid = v_userid
            and bankuid = (select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg) )
        and ca.bankuid in(select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg)
        and ca.acctuid = v_acctuid
        and ca.acctuid = a.acctuid;

        dbms_output.put_line('AFTER UPDATE - CUSTOMERACCOUNTS AND ACCOUNT:');
        dbms_output.put_line('acctnum,bpsrc,acctuid,banksvcstatus,bpsvcstatus,alternatedescription,bpregisterid,visibleflag,billingaccountflag,holder');
        dbms_output.put_line(v_acctstr);
        dbms_output.put_line('***************************************************************');
        dbms_output.put_line('Billpay Sync has been Completed for the user '||v_userid||' and Account :'||v_acctnbr);
        dbms_output.put_line('***************************************************************');

    else
      dbms_output.put_line('Billpay Sync failed for the user '||v_userid||'- Check Parameters');
    end if;
  else
    dbms_output.put_line('Billpay Sync failed for the user due to account not found error '||v_acctnbr);
  end if; -- account info exists
        exception
        when NO_DATA_FOUND then dbms_output.put_line('Billpay Sync failed : No records in customer table for the user '||v_userid);
    when OTHERS then dbms_output.put_line('Error mesaage: Exception occured when extract records in customer table');

end;
/

