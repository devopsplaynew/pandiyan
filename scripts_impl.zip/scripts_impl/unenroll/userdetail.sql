set verify off
set serveroutput on
set feedback off
set colsep ,
#set pagesize 0
set linesize 4500
set trimout on
set tab off

declare

v_cnt number;
v_custid varchar2(30);
v_custinfo varchar2(2000);
vusrid varchar2(55):= 'userid1';
forg  varchar2(3):= trim('bankno1'); 
cu_deleted  varchar2(30);
c_deleted varchar2(30);
cu_phonenum varchar2(30);
c_phonenum  varchar2(30);
c_addr1 varchar2(100);
c_addr2 varchar2(100);
a_acctnum  varchar2(30);
c_acctuid  varchar2(50);
a_external  varchar2(5);
a_genextnum  varchar2(50);
c_estatement_consent  varchar2(30);
c_espsvcstatus  varchar2(30);
c_aldeslen  number;
a_deslen  number;
a_paperf  varchar2(5);
a_electf  varchar2(5);
c_alphacustid varchar2(30);
c_name varchar2(30);
s_cnt number;
t_cnt number;
vusrid1 varchar2(50); 
cursor updatecur is select custid from ceb000.customeruser where userid=vusrid and bankuid in (select bankuid from ceb000.ofxbankinfo where fi_org=forg);

begin

open updatecur;

loop

fetch updatecur into v_custid;

if updatecur%notfound then
--dbms_output.put_line('no records for the userid - '||vusrid);
exit;
end if;

    begin

    select count(*) into v_cnt from ceb000.customeruser where userid=vusrid and bankuid in (select bankuid from ceb000.ofxbankinfo where fi_org=forg);

    if v_cnt>=1

    then

    select cu.deleted,c.deleted,cu.phonenum,c.phonenum,c.addr1,c.addr2,c.name
    into cu_deleted,c_deleted,cu_phonenum,c_phonenum,c_addr1,c_addr2,c_name from ceb000.customer c,ceb000.customeruser cu
    where cu.userid =vusrid
    and c.bankuid = cu.bankuid and c.custid=v_custid and cu.bankuid in (select bankuid from ceb000.ofxbankinfo where fi_org=forg);

select count(*) into s_cnt from ceb000.customeruser a
where custid=v_custid and a.bankuid in (select bankuid from ceb000.ofxbankinfo where fi_org = forg) and REGEXP_LIKE (c_name, '[^A-Za-z0-9, ]');

select count(*) into t_cnt from ceb000.customeruser a
where custid=v_custid and a.bankuid in (select bankuid from ceb000.ofxbankinfo where fi_org = forg) and REGEXP_LIKE (c_addr1, '[^A-Za-z0-9, ]');
vusrid1:=CONCAT (SUBSTR(vusrid,1,3),LPAD(SUBSTR(vusrid,-3),LENGTH(vusrid)-1,'*'));


    dbms_output.put_line('*****************************USER STATUS IN CUSTOMER/CUSTOMERUSER********************************');
    
      if (cu_DELETED='Y' and C_DELETED='Y')
      then
      dbms_output.put_line(vusrid1||'   : DELETED STATUS.');
      else
      dbms_output.put_line(vusrid1||'   : ACTIVE STATUS.');
      end if;
      
      if s_cnt>0
      then
      dbms_output.put_line(vusrid1||'   : SPECIAL CHARACTER IN NAME.');
      else
      dbms_output.put_line(vusrid1||'   : NO SPECIAL CHARACTER IN NAME.');
      end if;

      if t_cnt>0
      then
      dbms_output.put_line(vusrid1||'   : SPECIAL CHARACTER IN ADDRESS.');
      else
      dbms_output.put_line(vusrid1||'   : NO SPECIAL CHARACTER IN ADDRESS.');
      end if;
      
      if (CU_PHONENUM is not null or C_PHONENUM is not null)
      then
      dbms_output.put_line(vusrid1||'   : HAS PHONENUM.');
      else
      dbms_output.put_line(vusrid1||'   : PHONENUM NOT AVAILABLE IN CEB.');
      end if;

      if (C_ADDR1 is not null or C_ADDR2 is not null)
      then
      dbms_output.put_line(vusrid1||'   : HAS ADDRESS.');
      else
      dbms_output.put_line(vusrid1||'   : ADDRESS NOT AVAILABLE IN CEB.');
      end if;

    else

    dbms_output.put_line('No records in customeruser table');

    end if;
    end;

  begin

  select count(*) into v_cnt from ceb000.customeruser where userid=vusrid and bankuid in (select bankuid from ceb000.ofxbankinfo where fi_org=forg);

  if v_cnt>=1

  then
    dbms_output.put_line('****************************USER STATUS IN ACCOUNT/CUSTOMERACCOUNTS******************************');

  for l_counter in (select distinct acctuid FROM CEB000.CUSTOMERACCOUNTS WHERE ALPHACUSTID in 
  (SELECT CUSTID FROM CEB000.CUSTOMERUSER WHERE USERID =vusrid) AND BANKUID IN 
  (SELECT BANKUID FROM CEB000.OFXBANKINFO WHERE FI_ORG = forg))

  loop
  select 
  a.acctnum,c.acctuid,a.external,a.genextnum,c.estatement_consent,c.espsvcstatus,length(c.alternatedescription) aldeslen,length(a.description) deslen,a.paperf,a.electf,c.alphacustid
  into a_acctnum,c_acctuid,a_external,a_genextnum,c_estatement_consent,c_espsvcstatus,c_aldeslen,a_deslen,a_paperf,a_electf,c_alphacustid
  from ceb000.account a ,ceb000.customeraccounts c
  where a.acctuid = c.acctuid and a.custid=v_custid and c.acctuid=l_counter.acctuid 
  and c.bankuid in (select bankuid from ceb000.ofxbankinfo where fi_org = forg);
a_acctnum:=CONCAT (SUBSTR(a_acctnum,1,3),LPAD(SUBSTR(a_acctnum,-3),LENGTH(a_acctnum)-1,'*'));
  if (a_external='Y' and a_genextnum is not null)
  then
  dbms_output.put_line(a_acctnum||'   : HAS ENROLLED AS EXTERNAL ACCOUNT.');
  elsif (a_external='N' and a_genextnum is null )
  then
  dbms_output.put_line(a_acctnum||'   : NOT ENROLLED AS EXTERNAL ACCOUNT.');
  else
  dbms_output.put_line(a_acctnum||'   : PARTIALLAY ENROLLED AS EXTERNAL ACCOUNT.');
  end if;
 
  if (c_aldeslen>=32 or a_deslen>=32 )
  then
  dbms_output.put_line(a_acctnum||'   : DESCRYPTION/ALTERNATEDESCRYPTION COLUMN HAS MORETHAN 32 CHARACTERS.');
  else
  dbms_output.put_line(a_acctnum||'   : DESCRYPTION/ALTERNATEDESCRYPTION AS EXPECTED.');
  end if;
  
  if (a_paperf='N' and a_electf='Y' )
  then
  dbms_output.put_line(a_acctnum||'   : ENABLED FOR E-STATMENTS AND DISABLED FOR PAPER.');
  elsif (a_paperf='Y' and a_electf='N' )
  then
  dbms_output.put_line(a_acctnum||'   : ENABLED FOR PAPER AND DISABLED FOR E-STATMENTS.');
  elsif (a_paperf is null and a_electf is null )
  then
  dbms_output.put_line(a_acctnum||'   : NULL VALUE FOR PAPER E-STATMENTS.');
  else
  dbms_output.put_line(a_acctnum||'   : ENABLED FOR PAPER AND E-STATMENTS.');
  end if;
  dbms_output.put_line('');
 end loop;

  else

  dbms_output.put_line('No records in customeruser table');

  end if;
  end;
END LOOP;
    dbms_output.put_line('*************************************************************************************************');

CLOSE updatecur;
end;

/
