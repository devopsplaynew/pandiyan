set verify off
set serveroutput on size 300000 format wrapped
set feedback off
set linesize 4500
set trimout on
set tab off

declare
  v_userid varchar2(32):='USERID1';
  v_fiorg  varchar2(3):='BANKNO1';
  vacc1 varchar2(20):='';
  v_tkt varchar2(15):='Ticket';
  v_errmsg varchar2(2000);
  v_custinfo varchar2(2000);
  v_date varchar2(40):=substr(systimestamp,1,18);
  v_row number;
  status1 varchar2(2);
  status2 varchar2(2);
  status3 varchar2(2);
  v_cnt number;
v_msg varchar2(400);


begin
v_msg :='<br><a href="https://cases.fnfis.com/wfForms/wfMain.aspx?CaseID='||v_tkt||'">'||v_tkt||'</a>';

select count(*) into v_cnt from ceb000.customeruser where userid = v_userid and bankuid = (select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg);
if v_cnt=0
then
dbms_output.put_line(v_msg||': No_Data available in CeB for the userid - '||v_userid||'. please check user input.');
end if;

  begin
dbms_output.put_line(v_date||':External transfers Unenrollement started for customerservices table');

    update ceb000.customerservices set status = 'UNENROLL', status_reason = 'UNENROLL' , available = 'Y',
    activation_ts = null , update_ts = sysdate, servicedata_n01 = null where custid in
    (select custid from ceb000.customeruser where userid =v_userid and  bankuid in (select bankuid from ceb000.ofxbankinfo where fi_org = v_fiorg))
    and serviceid in('EPPTRANSFERS');

  v_row:=sql%rowcount;
        if v_row = 0 then
      status1:='0';
        else
      dbms_output.put_line(v_date||': No Of Rows affected in customerservices- '||v_row);
      status1:='1';
        end if;
  dbms_output.put_line(v_date||': External transfers Unenrollment status for customerservices - '||status1);

    exception
    when no_data_found then
    dbms_output.put_line(v_date||': Data not available to External transfers Unenroll in customerservices table for the userid - '||v_userid);
    when others then
    v_errmsg := substr(sqlerrm,1,100);
    dbms_output.put_line(v_date||': error while update in customerservices table for the userid - '||v_userid||'-'||v_errmsg);
  end;

    begin

    dbms_output.put_line(v_date||':External transfers Unenrollement started for customeraccountservices table');
    update ceb000.customeraccountservices set status = 'UNENROLL', status_reason = 'UNENROLL' , available = 'Y',
    activation_ts = null , update_ts = sysdate, servicedata_n01 = null where alphacustid in
    (select custid from ceb000.customeruser where userid=v_userid)
    and serviceid in('EPPTRANSFERS') and bankuid in (select bankuid from ceb000.ofxbankinfo where fi_org=v_fiorg);

    v_row:=sql%rowcount;
    dbms_output.put_line(v_date||': No Of Rows affected in customeraccountservices- '||v_row);
    if v_row = 0 then
    status2:='0';
    else
    status2:='1';
    end if;
    dbms_output.put_line(v_date||':External transfers Unenrollment status for customeraccountservices - '||status2);

    exception
    when no_data_found then
    dbms_output.put_line('Data not available to External transfers Unenroll in customeraccountservices table for the userid - '||v_userid);
    when others then
    v_errmsg := substr(sqlerrm,1,100);
    dbms_output.put_line('error while update in customeraccountservices table for the userid - '||v_userid||'-'||v_errmsg);
    end;


  dbms_output.put_line('************************************************************************');
  if ((status1>0 and status2>0) or (status1>0 and status2=0))then
  dbms_output.put_line(v_msg||': External transfers Unenrollment Successfull for User - '||v_userid);
  
else
  dbms_output.put_line(v_msg||': External transfers Unenrollment Failed for User - '||v_userid||'. please check user input.');

  end if;
  dbms_output.put_line('************************************************************************');


 end;

/
