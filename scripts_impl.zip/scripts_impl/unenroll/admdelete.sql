set verify off
set serveroutput on size 300000 format wrapped
set feedback off
set linesize 4500
set trimout on
set tab off


declare
  v_userid varchar2(32):='USERID1';
  v_tkt varchar2(15):='Ticket';
  v_errmsg varchar2(2000);
  v_custinfo varchar2(2000);
  v_date varchar2(40);
  v_row number;
  status1 varchar2(2);
  status2 varchar2(2);
  delusrid varchar2(35);
  v_cnt number;
  v_msg varchar2(400);

begin

select to_char(sysdate,'MMDDYY') into v_date from dual;

v_msg :='<br><a href="https://cases.fnfis.com/wfForms/wfMain.aspx?CaseID='||v_tkt||'">'||v_tkt||'</a>';

select count(*) into v_cnt from ceb000.adminuser  where userid =v_userid;

if v_cnt=0

then

  dbms_output.put_line(v_msg||': Admin user logical deletion Failed for User - '||v_userid||'. please check user input.');

else

select userid into v_userid from ceb000.adminuser  where userid =v_userid;

dbms_output.put_line(v_userid);

delusrid := v_userid||'_'||v_date||'_Deleted';

dbms_output.put_line(delusrid);

update ceb000.adminuser set deleted='Y',deletedate=sysdate, active='N', USERID=delusrid where userid = v_userid;

  v_row:=sql%rowcount;

  dbms_output.put_line(v_date||' No Of Rows affected - '||v_row);

  if v_row = 0 then

    dbms_output.put_line(v_msg||': Admin user logical deletion Failed for User - '||v_userid||'. please check user input.');

  else

  dbms_output.put_line(v_msg||': Admin user logical Unenrollment Successfull for User - '||v_userid);
  
  end if;
 
 end if;
 
 end;
 /
