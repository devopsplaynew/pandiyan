## to print the reserved keywords in python
"""
import keyword
print(keyword.kwlist);
"""

## get the string input 
"""
name=input("enter the name: ")
print(type(name));
print(name);
"""

## get the numeric input 
"""
val1=int(input("enter the value 1"));
val2=int(input("enter the value 2"));
finval=float(val1+val2)
print(type(finval));
print(id(finval));
print("the final value is :", finval);
"""

#to get the multiple inputs at same time using split function ,if you want to split by any delimter you can mention as split(":")
"""
fname,mname,lname=input("Enter The Full Name :").split()
print("Firstname :",fname);
print("MiddleName :",mname);
print("Lastname :",lname);
"""

# to get the paragraph input from user until break the condition using append and join funtions.
"""
para=[]
print("Enter the para :");

while True:
    line=input()
    if line:
        para.append(line)
    else:
        break
print(para);
output='\n'.join(para)
print(output);

"""

# to print the numeric values with string using type casting(converting one type to another type)
"""
a=int(input("enter the value 1"));
b=int(input("enter the value 2"));
c=a+b;
print("total value is : "+ str(c))
"""

##String important functions
"""
s="pandiyan kuppan"
print(s);
print("upper of string :",s.upper());
print("lower of string :",s.lower());
print("capitalize of string :",s.capitalize());
print("title of string :",s.title());
print("count of n :",s.count("n"));
print("is ends with P?:",s.endswith("P"));
print("find the char D position :",s.find("d"));
print("replace the char i to I :",s.replace("i","I"));
print("given string is upper case? ",s.isupper());
print("given string is lower case? ",s.islower());
print("given string is alphanumeric? ",s.isalnum());
print("given string is alpha? ",s.isalpha());
a="maddula\numa\nmaheswari"
print(a);
a="Maddula,Uma,Umaheswari"
print(a.split(","));
b="   kanishya    "
print(len(b));
print(len(b.strip()));
print(len(b.lstrip()));
print(len(b.rstrip()));
c="12-DEC-2022"
print(c.partition("-"));
"""

##String slicing
"""
var="Pandiyan"
print(var[0:5])
print(var[:7])
print(var[-2])
print(var[-3:-1])
print(var[::-1])
"""

##arithmatic operations
""" 
a=123
b=10
print(a+b); ##sum
print(a-b); ##sub
print(a*b); ##mul
print(a/b); ##div
print(a//b); ##floor will display round number of division
print(a%b); ##modulus will display reminder value of division
print(2**3); ##exponentions
"""

#Arithmatic assignement operators
"""
a=125
print(a);
a+=5;
print(a);
a-=10;
print(a);
a*=10;
print(a)
a/=10;
print(a);
a%=9;
print(a);
"""

##comparision operators
""" 
a=int(input("enter the value a :"))
b=int(input("enter the value b :"))
print(a);
print(b);
print(a == b )
print(a != b )
print(a < b )
print(a > b )
print( a <= b)
print( a >= b)
"""

## Logical operators
"""
a=25
print(a>=10 and a<=20)
print(a>=10 or a<=20)
print(not(a>=10 and a<=20))
"""

#bitwise operators
"""
a=25
b=45
print(a&b) ##and gates(0+0=0,0+1=0)
print(a|b) ##or gates(0+0=0,0+1=1)
print(a^b) ##xor gates (if both digits same then value would be 0, different digits then value would be 1)
print(~a)  ##not gates
print(a<<2) ##shifting 2 digits leftside in binary
print(a>>2) ##shifting 2 digits rightside in binary
"""

##if else condition
"""  
name=input("enter your name")
age=int(input("enter your age"))

if age >= 18:
    print("elligible for vote")
elif (age >= 16 and age <= 17):
    print("ready for vote in few years")
else:
    print("not elligible for volte")
"""

# Nested If Statement in Python
"""
m1=int(input("Enter the mark 1 :"))
m2=int(input("Enter the mark 2 :"))
m3=int(input("Enter the mark 3 :"))

total=m1+m2+m3
avg=total/3.0

print(total)
print(avg)
if m1>=35 and m2>=35 and m3>=35:
    print("Result:Pass")
    
    if avg>=90:
        print("A - Grade")
    elif avg>=80 and avg<=89:
        print("B- Grade")
    elif avg>=70 and avg<=79:
        print("C- Grade")
    else:
        print("D- Grade")            
else:
    print("Result:Fail")
"""

#print the odd number values using while loop
""" 
i=1
while i <= 20:
    if i%2!=0:
        print(i)
    i += 1  ## if we keep 2 will print even numbers
"""

# Break Statement
"""
i = 1
while i <= 20:
  if i==7:
    break
  print(i)
  i += 1
"""
##print range
"""
print(list(range(5)))
print(list(range(2,5)))
print(list(range(0,21,2)))
print(list(range(1,21,3)))
"""

##for loop with range 
"""
for i in range(2,21,2):
    print(i)
"""

##nested for loop with range   
"""
for i in range(5):
    for j in range(i):
        print("*",end="")
    print(" ")
for i in range(5,0,-1):   ##reverse the order
    for j in range(i):
        print("*",end="")
    print(" ")

##A-Z => 65-90
##a-z=> 97-122
    
for i in range(65,70,1):
    for j in range(65,70,1):
        print(chr(j),end="")
    print("")
"""

# List in Python
"""
Sequence Type
Mutable
a[5]
a={1,2,3,4,5}
a[0]
"""

#list operations using functions
"""
a = [1, 2, 3, 4, 5]
print(a)
print(type(a))
a[0] = 100  ##change value based on index number
print(a)
print(a[1]) ##print the value of 1st index
print(a[-1]) ##print the value of last index
print(a[0:3]) ##print the values between 0 to 2nd index(3rd index value will not be included)
print(a[2:]) ##starting from 2nd to last index
print(a[:3]) ##starting from 0 to 2nd index(3rd index value will not be included)
print("-----------------------------")

##specific field type can be get it using below ones.
a = [1, True, 'Ram', 2.5, [1, 2, 3, 4]]
print(a)
print(type(a))
print(a[0], " type is ", type(a[0]))
print(a[1], " type is ", type(a[1]))
print(a[2], " type is ", type(a[2]))
print(a[3], " type is ", type(a[3]))
print(a[4], " type is ", type(a[4]))
print(a[4][1])
print("-----------------------------")

a = [10, 25, 35, 45]
print(a)
a.clear() ##to clear the values in list
print(a)
a = [10, 25, 35, 45]
b = a.copy() ##copy the list values to another variable
print(b)
a = [10, 25, 35, 45, 25, 4, 25]
print(a.count(25)) ##number of occurance
print(a.index(25)) ##to find the index position
print(len(a)) ##length of list values
print(max(a)) ##max value in list
print(min(a)) ##min value in list
print(a)
a.pop(0)  # remove Element using index
print(a)
a = [10, 25, 35, 45, 25, 4, 25]
a.remove(25)  #remove the element using Values
print(a)
print("-----------------------------")
names = ["Ram"]
print(names)
names.append("Sam") ##append the values to existing list
names.append("Ravi")
names.append("Kumar")
print(names)
name2 = ["Sara", "Anitha"]
names.extend(name2) ##join the two list values
print(names)
names.insert(0,"Suriya") ##insert the values to specific index
print(names)
print("-----------------------------")
print(list(range(5)))
print(list("Tutorjoes"))
a=[10,50,100,25,85]
print(a)
a.sort() ##to sort the values in asc
print(a)
a.sort(reverse=True) ##to sort the values in desc
print(a)
a=["Orange","Apple","Zebra"]
a.sort()
print(a)
a.sort(reverse=True)
print(a)
a=["Orange","Apple","Zebra"]
a.sort(key=len) ##sort the values using length of values
print(a)
"""

# Tuple in Python
"""
# Immutable
# Surrounded by Round Brackets (1,1,5)

a = (1, 2.5, True, "Ram")
print(a)
print(type(a))
print(a[1])
print(a[-1])
print(a[0:2])
b = list(a)
print(b)
b.append("Raja")
print(b)
print(type(b))
a = tuple(b)
print(a)
print(type(a))

for i in a:
    print(i)

if "Raj" in a:
    print("Raja is Found")
else:
    print("Not Found")
print(len(a))

a = (1,)
print(type(a))
del a
a = (1, 2, 7, 4)
b = (5, 6, 7, 8)
c = a + b
print(c)
print(c.count(7))

a = (1, 2, 7, 4)
b = (5, 6, 7, 8)
c = (a, b)
print(c)
print(c[0])
print(c[1])
print(c[0][1])
x = ('Joes',) * 10
print(x)

a = (1, 2, 7, 4)
b = (5, 6, 7, 8)
print(min(a))
print(max(a))
"""
##set methods operations
"""
names={'Ram','Sam','Ravi'}
print(names)
print(type(names))
# Access Values Using For loop
for name in names:
    print(name)
# Adding New Element
names.add('Sara')
print(names)
# Update Another Set of Data
a={'Kumar','Sundar','Suresh'}
names.update(a)
print(names)
names.remove('Sara')
print(names)
names.discard('Suresh')
print(names)
names.pop()
print(names)
names.clear()
print(names)
del names
names={'Ram','Ram','Sam','Ravi','Kumar','Sundar','Suresh'}
print(names)
a = {1, 2, 3, 4}
b = {'a', 'b', 'c', 'd'}
c=a.union(b)
print(c)
a.update(b)
print(a)
a = {1, 2, 3, 4, 5}
b = {5, 6, 7, 8, 9}
c=a.intersection(b)
print(c)
a.intersection_update(b)
print(a)
c=a.symmetric_difference(b)
print(c)
a.symmetric_difference_update(b)
print(a)
a = {5,6,7}
b = {5, 6, 7}
c=a.isdisjoint(b)
print(c)
c=a.issubset(b)
print(c)
c=a.issuperset(b)
print(c)
"""

#dictionary operations
"""
user = {
    "name": "Ram",
    "age": 25,
    "isMarried": True
}
print(user)
print(type(user))
print(user["name"])
print(user.get('age'))
print(user.keys())
print(user.values())
print(user.items())
for x in user:
    print(x," ",user[x])
for x in user.values():
    print(x)
for x in user.keys():
    print(x)
for x,y in user.items():
    print(x,y)
if "gender" in user:
    print("Present")
# Changing Values
user.update({"gender":"male"})
print(user)
user["age"]=35
print(user)
user.pop("age")
print(user)
user.clear()
print(user)
users={
    "user1": {
        "name": "Ram",
        "age": 25,
        "isMarried": True
    },
"user2": {
        "name": "SAm",
        "age": 35,
        "isMarried": False
    }
}
print(users)
for user in users:
    print(user["name"])
"""